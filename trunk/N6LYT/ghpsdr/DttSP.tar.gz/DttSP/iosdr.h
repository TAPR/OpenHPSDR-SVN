extern int write (int, void *, unsigned int);
