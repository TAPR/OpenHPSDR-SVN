//
//
// Cheap DSP dsPICradio board Rotary Encoder routines
//
//
//  Juha Niinikoski OH2NLT 30.08.2005
//

// wery quick (and dirty) way to read IQ rotary encoder
// this routine requires sharp and clean pulse edges for phase ENQ_A


// rotary encoder
static int enc_accu;			// ancoder pulse accumulator
bit	enc_event;			// encoder event happened

// Encoder IRQ routines
void interrupt encoder_int(void) @ INT4_VCTR
	{
	INT4IF = 0;
	enc_event = 1;
	if(ENQ_B)			// very quick IQ encoder handler
		enc_accu++;
	else
		enc_accu--;

	LD3 = ENQ_B;	// test
	}
// Rotary Encoder system init
void encoder_init(void)
	{
//	ICP9 = 0x0010;		// set priority to 1, default = 4
	INT4IF = 0;
	INT4IE = 1;			
	}

int encoder_get(void)
	{
	int x;
	x = enc_accu;
	enc_accu = 0;
	enc_event = 0;
	return(x);
	}
