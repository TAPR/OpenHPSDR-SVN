//
// Board specifc definitions for
// Cheap DSP dsPIC30 radio board test
// Juha Niinikoski OH2NLT 25.08.2005
//
// Hi-Tech dsPICC_9.50 compiler, MPLAB 7.00
// 
//

// Port A Switches, CREF, PTT input

#define INIT_TRISA 0xFF7F			// PortA switch inputs
#define INIT_PORTA 0x0000

#define PTT	RA6						// MIC PTT switch
#define SW2	RA12					// on board push button switches
#define SW3	RA13
#define ENQ_B RA14					// rotary encoder
#define ENQ_A RA15


// Port B ADC inputs, General I/O, TX_EN, RX_EN

#define INIT_TRISB 0xC003			// PortB ADC and IDC pins = inputs
#define INIT_PORTB 0x0000

#define TX_EN		LATB11			// TX mixer enable
#define RX_EN		LATB12			// RX mixer enable

#define TX_RLY		LATB2			// antenna relay
#define MHZ7		LATB3			// 7MHZ filter switch relay

// Port C Sideband select & switches

#define INIT_TRISC 0x9FFF			// Sideband sel, CLKOUT = output
#define INIT_PORTC 0x0000			//

#define	USB_LSB	LATC13				// sideband select
#define ENQ_SW	RC4					// encoder push button switch

// Port D LCD, Status LEDs

#define INIT_TRISD 0x0000			// LCD & LED I/O, all outputs
#define INIT_PORTD 0x0000			//

// status LEDs
#define	LD1	LATD13
#define	LD2	LATD12
#define	LD3	LATD15
#define	LD4 LATD14


// LCD signals
#define LCD_E		LATD10			// LCD E signal
#define LCD_RW		LATD9			// LCD R/W signal
#define LCD_RS		LATD8			// LCD RS signal
#define LCD_BL		LATD11			// LCD backlight

#define LCD_DATA	LATD			// LCD 8-bit data bus out register
#define LCD_BUS		PORTD			// LCD 8-bit data bus state
#define LCD_TRIS	TRISD			// LCD data direction 

#define LCD_MASK	0x00FF			// LCD data lines at port




// PORT F DDS controls

#define INIT_TRISF 0xFFFC			// RG0, RG1 = outputs
#define INIT_PORTF 0x0000

#define INIT_TRISG 0xFFFC			// RF0, RF1 = outputs
#define INIT_PORTG 0x0000

#define	COFS_PIN	RG15			// codec COFS signal

// AD9850 DDS signals

#define DDS_RESET	LATG0		/* AD9850 DDS Reset */
#define DDS_FQ_UD	LATG1		/* AD9850 DDS FQ_UD */
#define DDS_W_CLK	LATF0		/* AD9850 DDS W_CLK */
#define DDS_SER		LATF1		/* AD9850 DDS D7/SER */


// codec spi controla

#define	ML	LATF7					// CS / latch
#define	MC	LATF6					// clock
#define	MD	LATF8					// data
#define	MLDIR TRISF7				// direction bits
#define	MCDIR TRISF6
#define	MDDIR TRISF8
