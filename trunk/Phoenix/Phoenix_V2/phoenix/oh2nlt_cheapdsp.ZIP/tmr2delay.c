//
// Delays with dsPIC30 TMR2
// Juha Niinikoski, OH2NLT 26.08.2005
//
// Hi-Tech dsPICC_9.50 compiler, MPLAB 7.00
// 
//

// delay routines with TMR2

// microsecond delay
// max delay 2000us @ 120mHZ sysclock
void us_delay( unsigned int dly )
	{
	TMR2 = 0;					// reset timer
	PR2 = dly * DLYCONST;		// calculate delay
	T2IF = 0;					// clear flags
	T2ON = 1;					// start delay

	while(T2IF == 0);			// wait here, do nothing
	
	T2ON = 0;					// timer off and leave
	}

// millisecond delay
// max delay 65535ms
void ms_delay( unsigned int dly )
	{
	unsigned int x;
	for(x=0; x<dly; x++)
		{
		us_delay(1000);			// 1ms delay
		}
	}
