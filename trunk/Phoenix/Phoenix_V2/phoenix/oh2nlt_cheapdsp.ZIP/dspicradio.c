//
// Cheap DSP dsPIC30 radio board test
// Juha Niinikoski, OH2NLT 24.08.2005
//
// Hi-Tech dsPICC_9.50 compiler, MPLAB 7.00
// 
//
// Codec working 05.09.2005
// VU-meter test 07.09.2005
// Volume controls 08.09.2005
// IIR filter for Microphone equalization added 18.09.2005
// first RX ALC tests 18.09.2005
// tuning step addjust added 28.09.2005
// over load indicator, filter select, decade tuning steps 22.10.2005

// include headers


#include <dspic.h>

// processor config

__CONFIG(FOSC, XTPLL8 & POSC & CLKSWDIS); // 7,3728MHz*8=58,9824MHz clock, 14,7456MHz cycle
//__CONFIG(FOSC, XTPLL16 & POSC & CLKSWDIS); // 7,3728MHz*16=117,9648MHz clock, 29,4912MHz cycle
__CONFIG(FWDT, WDTDIS);
__CONFIG(FBORPOR, BOREN & BORV27 & MCLREN);
__CONFIG(FGS, GCPU & GWRU);


// I = 120ma @ 30MHz cycle
// I = 75mA  @ 15MHz cycle

// uart setup according clock config
#define BAUD 9600
//#define FCY  1000000	// 4MHz XTAL
//#define FCY  8000000	// 4MHz XTAL x8 PLL = 32MHz
//#define FCY  16000000	// 4MHz XTAL x16 PLL = 64MHz

// clock constants
#define FCY  14745600UL	// 7,3728MHz XTAL x8 PLL = 58,9824MHz
//#define FCY  29491200UL	// 7,3728MHz XTAL x16 PLL = 117,9648MHz

#define DLYCONST (FCY/1000000UL)	// constant for timer delay routines
//#define DLYCONST 15
// Global variabbles

// DDS constants
//#define AD9851						// define this if fast DDS chip
#define MIN_DDS 0						// DDS limits
//#define MAX_DDS 1374389535			// 40 MHz upper limit
//#define MAX_DDS 1717986918			// 50 MHz upper limit

// 125MHz ref osc, step = 0.0291Hz
// 180MHz ref osc, step = 0.0419Hz

#ifdef AD9851
#define CLKIN 180000000					// oscilator 180 MHz AD9851
#define MAX_DDS 1766109700				// 74MHz upper limit, Nyquist frequency = 90MHz
#define DEFAULT_FREQ 353046314			// "factory default" 4 * 3.699 MHz
#else
//#define CLKIN 125000000					// oscilator 125 MHz AD9850
#define CLKIN 124996863					// proto board oscillator frequency, no calibration routine yet
#define MAX_DDS 2130303779				// 62MHz upper limit, Nyquist frequency = 62,5MHz
#define DEFAULT_FREQ 508386689			// "factory default" 4 * 3.699 MHz
#endif

// tuning
#define STEPS 6

// raw tuning steps
//const long f_steps[STEPS] = {1, 100, 1000,  10000, 100000, 1000000};	// increment / decrement steps

// frequency decade steps
const long f_steps[STEPS] = {137, 1374, 13744, 137439, 1374389, 13743895};	// 1, 10, 100,  1000, 10000, 100000 Hz

int step_idx;					// step table index

#define	FILTER_7MHZ	549755814	// 7MHz filter change, done at 4 MHz

// global DDS variables
	struct dds_regs
	{
	long dds_freq;
	unsigned char dds_config;
	};

	union						// AD9850 frequency & config data, index 0 = LSB
	{
	struct dds_regs dds_regs;
	unsigned char ad9850[5];
	} dds;


int fcy;						// clock / kHz
int apu;

int dci_mode;					// dci interrupt task selector
bit ptt;						// ptt switch state machine

// soft DDS test
float phase;					// for soft DDS init calculations
int dds_table[256];				// dds waweform
unsigned int 	ph_acc;			// phase accumulator
unsigned int 	ph_adder;		// phase adder
unsigned int	dds_i;
unsigned int	dds_q;			// soft audio dds outputs
unsigned int 	ramp;			// ramp test

// audio power meter
bit	pwr_rdy;					// 256 samples accumulated
int pwr;						// audio power
unsigned int pwr_accu;			// sample accu
int	pwr_ctr;					// mod 256 sample counter
int peak_pwr;					// peak audio power
bit rx_alc;						// receiver ALC
#define ATTN_START 5000			// start decrease gain
#define ATTN_SLOPE 256			// decay slope
#define PH_RELEASE	50			// peak hold release rate

// volume control
int hp_vol;						// headphone volume #0 - 127 = -73 to 6 dB
int li_vol;						// line input volume #0 -   = -34,5 to 12 dB
bit audio_monitor;				// monitor audio while TX 

// other
bit	sync_codec;					// codec output buffer sysnc
bit mic_filter;					// microphone IIR filter on / off

//
bit lcd_update;					// write / update LCD
int	lcd_mode;					// lcd display mode

// include programs
#include "filters.c"			// filter definitions & init, fir.as does the job
#include "tmr2delay.c"
#include "dspicradio.h"			// board specific definitions
#include "dspicradiovmul.c"
#include "uart.c"
#include "lcddsradio.c"
#include "adc12.c"
#include "ad9850dsradio.c"
#include "encdsradio.c"
#include "tlv320aic23b.h"		// codec definitions
#include "tlv320aic23b.c"		// codec interface
#define HEXUPCASE				// %x options
#define HEXLOWCASE
#include "doprnt.c"				// printf fix
#include "traps.c"				// dsPIC30F6012 trap handler
//#include "math.h"



// helper routines

void print_dds(void)
	{
	unsigned int fhi, flo;
	flo = dds.dds_regs.dds_freq & 0xFFFF;
	fhi = dds.dds_regs.dds_freq >> 16;
	printf("DDS = 0x%x%x\n\r", fhi, flo);
	}


// main
void main(void)
	{
	int x, z;
	unsigned int y;
	unsigned char c;
	int *p;
	unsigned char lcdpbuff[20];		// test

// set general I/O
	TRISA = INIT_TRISA;				// SWITCHES, PTT
	PORTA = INIT_PORTA;

	TRISB = INIT_TRISB;				// ADC inputs, TXEN, RXEN, General I/O
	PORTB = INIT_PORTB;

	TRISC = INIT_TRISC;				// sideband select & switches
	PORTC = INIT_PORTC;

	TRISD = INIT_TRISD;				// LEDs & LCD pins = output
	PORTD = INIT_PORTD;

	TRISF = INIT_TRISF;				// DDS controls
	PORTF = INIT_PORTF;

	TRISG = INIT_TRISG;				// DDS controls, EEPROM, DScard signals
	PORTG = INIT_PORTG;

	LD4 = 1;						// RUN LED

	fcy = FCY/1000;					// clock freq (kHz)
	apu = DLYCONST;


// init UART
	InitUSART1();					// wake up serial interface

	printf("\n\rJuha Niinikoski, OH2NLT Cheap DSP Radio v0.01 / 22.10.2005\n\r");
	printf("System Clock = %i kHz\n\r", fcy);

	initlcd();						// init LCD
	set_chgen();					// load bar graph fonts

	lcd_putst("Cheap DSP OH2NLT");	// say hello
	set_cur_lcd(LINE2);
	lcd_putst("  22.10.2005");

	init_adc12();					// setup A/D converter

	dds_init();						// start DDS
	dds.dds_regs.dds_freq = DEFAULT_FREQ;		// set initial frequency
	dds_load();						// load initial value
	dds_load();						// need two loads after reset ???

	encoder_init();					// init encoder, enable INT4
	step_idx = 2;					// set default step


// Init DDS waweform table. 256 samples Sin
	ph_acc = 0;
	ramp = 0;
	phase = 0.0;

#define ddsstep	0.024543692		// 2pi/256
	for(x=0; x<256; x++)
		{
		dds_table[x] = (sin(phase)) * 32767;
		phase = phase + ddsstep;
		}
	printf("DDS table initialized\n\r");

// set test freq
// ph_adder = fout / ( fs / 65536 )

	ph_adder = 8193;				// 1000 Hz, fs = 8kHz
//	ph_adder = 1000;

// init filter variables
	init_fir();						// set fir.as variables ready for run
	printf("Filters loaded\n\r");

// Init codec system
	init_codec_spi();				// init codec control port
	dci_mode = 0;
	init_dci();						// init dsPIC30F6014 DCI port
	DCIIF = 0;
	DCIIE = 1;						// enable DCI IRQ
	init_tlv320();					// init codec control registers
	printf("Codec & DCI initialized, 8000Hz sample rate\n\r");

// set PTT switxh state
	ptt = PTT;
	TX_EN = 1;						// TX mixer off
	RX_EN = 0;						// RX on
	TX_RLY = 0;						// antenna relay RX position
	USB_LSB = 0;					// ??? sideband

// sync codec
	sync_codec = 1;					// sync codec chanels

// display mode etc
	lcd_update = 1;					// force update
	lcd_mode = 0;					// default display

// set volume
	ms_delay(500);					// mute codec start buzz
	hp_vol = 0x0079;				// head phone amp = 0dB
	li_vol = 0x0017;				// line input amp = 0dB
	audio_monitor = 0;				// audio off when TX
	mic_filter = 0;					// IIR mic filter off
	rx_alc = 0;						// RX alc off
	printf("Mode bits, Volume etc. set. Ready to Run\n\r");
	ms_delay(1000);					// keep version text on LCD for a while

// Main forever loop

	for(;;)
		{
// volume controls
		
	if(PTT == 0 && audio_monitor == 0)				// TX mode & audio monitor off
		hp_vol = 0;									// mute phones
	else
		hp_vol = (convert_adc12_15() >> 5) & 0x007F;	// measure CH15 pot & set hp volume

	tlv_lchvc = (tlv_lchvc & 0xFF80) | hp_vol;		// set headphone volume
	tlv_rchvc = (tlv_rchvc & 0xFF80) | hp_vol;
	write_spi(tlv_lchvc);
	write_spi(tlv_rchvc);

// RX ALC 31 1,5dB steps = 46,5dB dynamic range
// TLV320AIC23B range is from -34,5 to +12 dB
	if(rx_alc)										// calculate RX ALC
		{
		if(peak_pwr < ATTN_START)
			li_vol = 31;							// max gain
		else
			{
			x = (peak_pwr - ATTN_START) >> 8;		// div 256 slope after treshold
			if(x > 31)
				x = 31;								// saturate
			li_vol = 31 - x;						// test ALC value
			}
		}
	else
		{
	li_vol = (convert_adc12_14() >> 7) & 0x001F;	// measure CH14 pot & set line-in volume
		}
	tlv_llicvc = (tlv_llicvc & 0xFFE0) | li_vol;	// set line input volume
	tlv_rlicvc = (tlv_rlicvc & 0xFFE0) | li_vol;
	write_spi(tlv_llicvc);
	write_spi(tlv_rlicvc);


// update dds & display frequency

// PTT logic
		LD1 = !PTT;				// PTT switch test

		if(PTT == 0)			// PTT pressed, TX mode
			{
			if(ptt == 0)
				{
				LD1 = 1;		// PTT on transition
				ptt = 1;

				printf("MIC Input active\n\r");
				tlv_aapc = TLV_AAPC | ( TLV_DAC | TLV_INSEL | TLV_MICB);		// select MIC, +20dB
				write_spi(tlv_aapc);

				printf("TX on\n\r");
				RX_EN = 1;
				TX_EN = 0;
				TX_RLY = 1;
				dci_mode = 2;	// TX filters
				}
			}
		else					// PTT released
			{
			if(ptt == 1)
				{
				LD1 = 0;		// PTT off transition
				ptt = 0;

				printf("LINE Input (RX mixer) selected\n\r");
				tlv_aapc = TLV_AAPC | ( TLV_DAC | TLV_MICM );		// select LINE L/R
				write_spi(tlv_aapc);

				printf("RX on\n\r");
				TX_EN = 1;
				RX_EN = 0;
				TX_RLY = 0;
				dci_mode = 3;	// RX filters
				}

			}


// process push button switches switches
		if(SW3 == 0)			// LSB / USB select
			{
			USB_LSB = !USB_LSB;	// negate current selection
			lcd_update = 1;		// force update
			ms_delay(300);		// debounce
			}

		if(SW2 == 0)			// LCD display mode
			{
			lcd_mode++;
			if(lcd_mode > 1)
				lcd_mode = 0;

			lcd_update = 1;		// force update
			ms_delay(300);		// debounce
			}


// addjust tuning step
		if(ENQ_SW == 0)
			{
			clear_lcd();
			sprintf(lcdpbuff, "Step=%i ",step_idx);
			lcd_putst(lcdpbuff);

			while(ENQ_SW == 0)		// addjust tuning step
				{
				if((enc_accu > 10) ||  (enc_accu < -10))	// make encoder feel coarse
					{
					if(enc_accu > 10)	// step up
						step_idx++;
					else				// step down
						step_idx--;

					if(step_idx < 0)	// check limits
						step_idx = 0;
					if(step_idx > (STEPS-1))
						step_idx = (STEPS-1);

					clear_lcd();		// display new setting
					sprintf(lcdpbuff, "Step=%i ",step_idx);
					lcd_putst(lcdpbuff);

					enc_accu = 0;		// clear encoder
					enc_event = 0;
					}

				if(SW2 == 0)			// ALC on/off
					{
					rx_alc = !rx_alc;
					clear_lcd();		// display new setting
					if(rx_alc)
						{
						sprintf(lcdpbuff, "ALC On");
						printf("ALC On\n\r");
						lcd_mode = 1;		// select power meter display
						lcd_update = 1;		// force update
						}
					else
						{
						sprintf(lcdpbuff, "ALC Off");
						printf("ALC Off\n\r");
						lcd_update = 1;		// force update
						}
					lcd_putst(lcdpbuff);
					ms_delay(300);		// debounce
					}

				if(SW3 == 0)			// Test TX sin generator on
					{
					dci_mode = 1;
					clear_lcd();
					sprintf(lcdpbuff, "I/Q audio on");
					lcd_putst(lcdpbuff);
					printf("DCI mode = 1, Soft I/Q DDS\n\r");
					ms_delay(300);		// debounce
					}

				}
			lcd_update = 1;	
			}

// Handle encoder
		if(enc_event)
			{
			dds.dds_regs.dds_freq = dds.dds_regs.dds_freq + (encoder_get() * f_steps[step_idx]);	// get encoder +/- value

			if(dds.dds_regs.dds_freq > MAX_DDS)			// check tuning limits
				dds.dds_regs.dds_freq = MAX_DDS;
			if(dds.dds_regs.dds_freq < MIN_DDS)
				dds.dds_regs.dds_freq = MIN_DDS;

			dds_load();									// load DDS
			lcd_update = 1;								// force LCD update
			}

// Filter switch
		if(dds.dds_regs.dds_freq > FILTER_7MHZ)
			MHZ7 = 1;								// 7MHz filter select relay drive
		else
			MHZ7 = 0;

// LCD display 
		if(lcd_update)
			{
		switch(lcd_mode)							// select what to display
			{

// display RX/TX frequency
			case 0: default:

				m1.m1l = dds.dds_regs.dds_freq;	  			// calculate display frequency
				m2.m2l = CLKIN; 							// f = (pw_data*osc_freq)/2^32
				vlmul();			  						// do JNi 32*32 multiplication
				clear_lcd();
				disp_freq((prod.prodlng.prodhi >> 2));  	// use hi-part = divided 2^32 / 4
				lcd_putst(" Hz ");

				set_cur_lcd(LINE2);
//			disp_long( dds.dds_regs.dds_freq, 0 );
		
// print volume control data
				for(y=0; y<20; y++)
					{
					lcdpbuff[y] = 0;
					}

				sprintf(lcdpbuff, " HP=%i LI=%i ",hp_vol, li_vol);
				lcd_putst(lcdpbuff);

				if(USB_LSB == 0)
					sprintf(lcdpbuff, "L");
				else
					sprintf(lcdpbuff, "U");

				lcd_putst(lcdpbuff);
				lcd_update = 0;								// done
				break;

// draw power meter
			case 1:
					if(pwr_rdy == 1);
						{
						pwr_rdy = 0;
//						clear_lcd();
						set_cur_lcd(LINE1);
						sprintf(lcdpbuff, "%d %d %d       ", li_vol, peak_pwr, pwr);
						lcd_putst(lcdpbuff);

						set_cur_lcd(LINE2);
						draw_bar((pwr >> 8), 0);
//						draw_s_meter(x);
						}
				break;
			}		// switch end
			
			}		// if end		


		if(kbhit())
			{
			c = getch();
			switch(c)
				{

// Sideband select
				case 'L':
					printf("USB_LSB = 0\n\r");
					USB_LSB = 0;				// LSB
					break;

				case 'U':
					printf("USB_LSB = 1\n\r");
					USB_LSB = 1;				// USB
					break;

// audio monitor on / off
				case 'M':
					printf("TX audio monitor ");
					audio_monitor = !audio_monitor;
					if(audio_monitor)
						printf("On\n\r");
					else
						printf("Off\n\r");
					break;


// Mic filter on / off
				case 'F':
					printf("Mic illter ");
					mic_filter = !mic_filter;
					if(mic_filter)
						printf("On\n\r");
					else
						printf("Off\n\r");
					break;


// Receiver ALC on / off
				case 'A':
					printf("Receiver ALC ");
					rx_alc = !rx_alc;
					if(rx_alc)
						{
						printf("On\n\r");
						lcd_mode = 1;		// select power meter display
						lcd_update = 1;		// force update
						}
					else
						printf("Off\n\r");
					break;

// DDS test
				case '+':
					dds.dds_regs.dds_freq = dds.dds_regs.dds_freq + 1000000;		// set initial frequency
					dds_load();						// load initial value
					printf("DDSup\n\r");
					print_dds();
					lcd_update = 1;
					break;

				case '-':
					dds.dds_regs.dds_freq = dds.dds_regs.dds_freq - 1000000;		// set initial frequency
					dds_load();						// load initial value
					printf("DDSdown\n\r");
					print_dds();
					lcd_update = 1;
					break;

// Mic / Line test
				case 'm':
					printf("MIC Input\n\r");
					tlv_aapc = TLV_AAPC | ( TLV_DAC | TLV_INSEL | TLV_MICB);		// select MIC, +20dB
					write_spi(tlv_aapc);
					break;

				case 'l':
					printf("LINE Input\n\r");
					tlv_aapc = TLV_AAPC | ( TLV_DAC | TLV_MICM );		// select LINE L/R
					write_spi(tlv_aapc);
					break;


// ADC test
				case 'a':
					x = convert_adc12_14();
					printf("ADC CH14 = %i\n\r",x);

					x = convert_adc12_15();
					printf("ADC CH15 = %i\n\r",x);
				
					clear_lcd();
					for(y=0; y<20; y++)
						{
						lcdpbuff[y] = 0;
						}

					sprintf(lcdpbuff, "CH15 = %i",x);
					lcd_putst(lcdpbuff);
					break;

				case 's':
				for(;;)
					{
					x = convert_adc12_14() >> 5;
					printf("Bar 0 = %i\n\r",x);

					z = convert_adc12_15() >> 5;
					printf("Bar 1 = %i\n\r",z);
				
					clear_lcd();
					draw_bar(x, 0);

					set_cur_lcd(LINE2);

					if(SW2 == 1)
						{
						draw_bar(z, 1);
						}
					else
						{
						draw_s_meter(x);
						}

					ms_delay(50);
					}
					break;

// DCI IRQ tests
				case '0':
					printf("DCI mode = 0, Audio Input, no filters\n\r");
					dci_mode = 0;
					break;

				case '1':
					printf("DCI mode = 1, Soft I/Q DDS\n\r");
					dci_mode = 1;
					break;

				case '2':
					printf("Mode = 2, Hilbert TX test\n\r");
					dci_mode = 2;
					break;

				case '3':
					printf("Mode = 3, SSB RX test\n\r");
					dci_mode = 3;
					break;

				case '4':
					printf("Mode = 4, USB & LSB RX test\n\r");
					dci_mode = 4;
					break;

				case '5':
					printf("Mode = 5, audio BPF left to l/r out\n\r");
					dci_mode = 5;
					break;

				case '6':
					printf("Mode = 6, Soft DDS test\n\r");
					dci_mode = 6;
					break;

				case '7':
					printf("Mode = 7, RXBUF0 to both outputs\n\r");
					dci_mode = 7;
					break;

				case '8':
					printf("Mode = 8, RXBUF0 to TXBUF0, TXBUF1 = 0\n\r");
					dci_mode = 8;
					break;

				case '9':
					printf("Mode = 9, IIR filter test\n\r");


//					printf("MIC Input active\n\r");
//					tlv_aapc = TLV_AAPC | ( TLV_DAC | TLV_INSEL | TLV_MICB);		// select MIC, +20dB
//					write_spi(tlv_aapc);
					dci_mode = 9;

					printf("IIR coefficients\n\r");
					for(x=0; x<10; x++)
						{
						printf("%i ",mic_iir_coef[x]);
						}

					printf("\n\rIIR delay lines\n\r");
					for(x=0; x<10; x++)
						{
						printf("%i ",mic_iir_dly[x]);
						}

					break;

				case '=':
					printf("Sync\n\r");
					sync_codec = 1;		// sysnc DCI with codec L/R ch test
					break;

				case 't':
					printf("Sin table\n\r");
					for(x=0; x<256;x++)
						{
						printf("  %x\n\r", dds_table[x]);
						}
					break;


// LCD tests
				case 'w':
					printf("LCD write\n\r");
					while(c != 0x1B)
						{
						while(kbhit() == 0);
						c = getch();
					printf("char = %x\n\r", c);
						lcd_putch(c);
						}
					break;

				case 'c':
					printf("Clear LCD\n\r");
					clear_lcd();
					break;

				case 'b':
					printf("bar graph test\n\r");
					
					for(;;)
					{
	
					for(x=0; x<96; x++)
						{
						clear_lcd();
						draw_s_meter(x);
						ms_delay(50);
						}
					}

					break;


				case 'p':
					printf("Audio Power meter test\n\r");
					
					for(;;)
					{
					while(pwr_rdy == 0);

					LD1 = !LD1;
					pwr_rdy = 0;
					clear_lcd();
					for(y=0; y<20; y++)
						{
						lcdpbuff[y] = 0;
						}


					sprintf(lcdpbuff, "PWR = %d", pwr);
					lcd_putst(lcdpbuff);

					set_cur_lcd(LINE2);
					draw_bar((pwr >> 8), 0);
//					draw_s_meter(x);
					}

					break;


				default:
					printf("Key is: %d\n\r", c);
					printf("Try: Valid commands\n\r");
				}
			}


		}	// end for(;;)
	}		// end main
