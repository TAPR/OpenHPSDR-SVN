//
// 
// Juha Niinikoski OH2NLT 2004
//
//


//****************************************
// Clumsy but working 32*32 multiply JNi
// elemantary school scheme but with
// base 256 numbers.
//****************************************

// bank2 variables, problems with RAM space

	union					// 32-bit term 1
	{
	unsigned long m1l;
	unsigned char m1b[4];
	}m1;

	union					// 32-bit term 2
	{
	unsigned long m2l;
	unsigned char m2b[4];
	}m2;

	struct prodlng
	{
	unsigned long prodlo;
	unsigned long prodhi;
	};

	union					// 64-bit product register
	{
	struct prodlng prodlng;
	unsigned char pb[8];
	}prod;


	union					// digit sum register
	{
	unsigned int dsi;
	unsigned char dsc[2];
	}ds;

	union					// product sum register
	{
	unsigned int psi;
	unsigned char psc[2];
	}ps;



void add_prod(char idx, unsigned char d)			// 8-bit to product array idx position
		{
		ps.psi = prod.pb[idx] + d;			// sum digit
		prod.pb[idx] = ps.psc[0];
		while((ps.psc[1] != 0) || idx < 8)		// continue adding if carry
			{
			idx++;
			ps.psi = prod.pb[idx] + ps.psc[1];
			prod.pb[idx] = ps.psc[0];
			}	
		}


void clear_prod(void)						// clear product array
	{
	char x;
	for(x=0; x<8; x++)
		{
		prod.pb[x] = 0;
		}
	}	


void vlmul(void)						// 32*32 multiply. prod = m1*m2
	{
	char d1, d2;
	clear_prod();

	for(d2=0; d2<4; d2++)
		{
		for(d1=0; d1<4; d1++)
			{
			ds.dsi = m1.m1b[d1] * m2.m2b[d2];	// multiply digit
			add_prod((d1+d2), ds.dsc[0]);		// add to product
			if(ds.dsc[1] != 0)
				add_prod((d2+d1+1), ds.dsc[1]);	// add carry number
			
			}
		}
	}

