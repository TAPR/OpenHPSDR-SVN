//
// TLV320AIC23B Codec driver
//
// Juha Niinikoski, OH2NLT 31.08.2005
//
// Codec mode set & tested 05.09.2005
// DCI sync added 13.09.2005
//


// local copy of codec control registers
static unsigned int tlv_llicvc;
static unsigned int	tlv_rlicvc;
static unsigned int	tlv_lchvc;
static unsigned int	tlv_rchvc;
static unsigned int	tlv_aapc;
static unsigned int	tlv_dapc;
static unsigned int	tlv_pdc;
static unsigned int	tlv_daif;
static unsigned int	tlv_src;
static unsigned int	tlv_dia;


// init values for TLV320 codec control registers
#define TLV_LIVC_INIT	(0x0017)					// 0dB, mute off

#define	TLV_HVC_INIT	(0x0000 | TLV_LZC)			// mute, zero cross detect on
//#define	TLV_HVC_INIT	(0x0079 | TLV_LZC)		// 0dB, zero cross detect on
//#define	TLV_HVC_INIT	(0x007F | TLV_LZC)		// +12dB, zero cross detect on

//#define	TLV_AAPC_INIT	(TLV_STA2 | TLV_STE | TLV_DAC | TLV_BYP)	// test config
#define	TLV_AAPC_INIT	( TLV_DAC | TLV_MICM )	// run config

#define TLV_DAPC_INIT	(0)						// ADC hp filter on, de emphasis off, mute off

#define	TLV_PDC_INIT	(0)						// power on all modules

#define	TLV_DAIF_INIT	(TLV_I2S | TLV_16_BIT | TLV_MS)	// I2S mode, 16 bit, MSB first, master mode

#define TLV_SRC_INIT	(0x000C)				// 1/1 clocks, oversampling 256 FS, normal, 8kHz

#define TLV_DIA_INIT	(TLV_ACT)				// activate digital interface

// SPI control interface
// software implementation

// Init SPI pins
void init_codec_spi(void)
	{
	ML = 1;
	MC = 0;
	MLDIR = 0;			// change pins to output
	MCDIR = 0;
	MDDIR = 0;
	}

// Send 16bits MSB first to codec spi
void write_spi(unsigned int data)
	{
	char x;

	MC = 0;
	ML = 0;					// start write cycle
	for(x=0; x<16; x++)
		{
		if(data & 0x8000)	// set data
			MD = 1;
		else
			MD = 0;

		data = data << 1;	// addjust data

		MC = 1;				// generate clock
		asm("nop");
		MC = 0;
		}
	asm("nop");
	ML = 1;					// latch
	}


// tlv320 codec init
void init_tlv320(void)
	{
	write_spi(TLV_RR);				// reset codec
	us_delay(100);

	tlv_llicvc = TLV_LIVC_INIT | TLV_LLICVC;	// set line input volume
	tlv_rlicvc = TLV_LIVC_INIT | TLV_RLICVC;
	write_spi(tlv_llicvc);
	write_spi(tlv_rlicvc);

	tlv_lchvc = TLV_HVC_INIT | TLV_LCHVC;		// set headphone volume
	tlv_rchvc = TLV_HVC_INIT | TLV_RCHVC;
	write_spi(tlv_lchvc);
	write_spi(tlv_rchvc);

	tlv_aapc = TLV_AAPC | TLV_AAPC_INIT;		// audio path control
	write_spi(tlv_aapc);

	tlv_dapc = TLV_DAPC | TLV_DAPC_INIT;		// digital audio path control
	write_spi(tlv_dapc);

	tlv_pdc = TLV_PDC | TLV_PDC_INIT;			// codec power control
	write_spi(tlv_pdc);	

	tlv_daif = TLV_DAIF | TLV_DAIF_INIT;		// audio interface data format
	write_spi(tlv_daif);

	tlv_src = TLV_SRC | TLV_SRC_INIT;			// sample rate control
	write_spi(tlv_src);

	tlv_dia = TLV_DIA | TLV_DIA_INIT;			// digital interface activation
	write_spi(tlv_dia);
	}
//
// PCM3002 Codec / dsPIC30F6012 DCI driver &
// DCI interrupt handler. All filters are
// calculated here.
//
// Juha Niinikoski 18.05.2005
//


// dsPIC30F6012 DCI interface init

void init_dci(void)
	{
	DCICON1 = 0x0000;		// stop DCI if running

	TXBUF0 = 0;				// clear fuffers
	TXBUF1 = 0;
	TXBUF2 = 0;
	TXBUF3 = 0;

// init DCI codec interface for TLV3020 16-bit mode
	DCICON2 = 0x040F;		//2 word buff, 1 word frame, 16-bits
//	DCICON2 = 0x042F;		//2 word buff, 2 word frame, 16-bits
	RSCON = 0x0001;			// select active slots, only 1
	TSCON = 0x0001;
	DCICON1 = 0x8701;		// no left justify
//	DCICON1 = 0x8721;		// enable DCI, csclk=in, data change on falling edge, cofs=in, 
							// tx 0 on underrun, csdo=0 during disabled slots, left justify, I2S mode
	}

//
// DCI IRQ handler
//
// COFS = 0, Left CH, from TXBUF0
// COFS = 1, Right CH, from TXBUF1
//
void interrupt dci_int(void) @ DCI_VCTR
	{
	int temp;

	DCIIF = 0;
	LD4 = 1;	// IRQ indicator

	if(sync_codec)						// sync COFS signal & Buffers
			{
			sync_codec = 0;				// one shot

			if(COFS_PIN == 0)			// test COFS for out of sync
				{
				DCIEN = 0;				// stop & reset DCI
				TXBUF0 = 0;
				TXBUF1 = 0;
				while(COFS_PIN == 0);	// wait for COFS = 1
				while(COFS_PIN == 1);	// wait for COFS = 0
				DCIEN = 1;				// then restart DCI
				DCIIF = 0;
				goto exit_dci;			// exit interrupt routine
				}
			}

	switch(dci_mode)			// select different tests
			{
			case 0: default:	// 1:1 feed through
			TXBUF0 = RXBUF0;	// direct out Left
			TXBUF1 = RXBUF1;	// Right
			break;

			case 1:
			TXBUF0 = dds_i;		// Left = I
			TXBUF1 = dds_q;		// Right = q
			temp = RXBUF0;
			temp = RXBUF0;
			break;

			case 2:
			TXBUF0 = firr_out;		// Hilbert pair TX filters
			TXBUF1 = firl_out;		// this order match RX LSB / USB selection

			if(mic_filter == 0)
				{
				firl_in = RXBUF0;		// filter input from same CH
				firr_in = RXBUF0;
				}
			else
				{
				mic_iir_in = RXBUF0;		// new sample to Mic filter
				firl_in = mic_iir_out;		// mic IIR output to Hilbert filters 
				firr_in = mic_iir_out;
				}

			temp = RXBUF1;			// dummy
			fir();					// calculate filters
			break;

			case 3:					// Hilbert pair RX test, SSB RX
			firp_in = firl_out + firr_out; // set band pass filter input

			TXBUF0 = firp_out;		// after band pass filter	
			TXBUF1 = firp_out;		// same signal to both channels

			firl_in = RXBUF0;		// signal from mixer I
			firr_in = RXBUF1;		// signal from mixer Q

			fir();					// calculate filters
			break;

			case 4:
			TXBUF0 = firl_out + firr_out;	
			TXBUF1 = firl_out - firr_out;	
			firl_in = RXBUF0;		// signal from mixer I
			firr_in = RXBUF1;		// signal from mixer Q
			fir();					// calculate filters
			break;

			case 5:
			TXBUF0 = firp_out;		// BPF test
			TXBUF1 = firp_out;		//
			firp_in = RXBUF0;
			temp = RXBUF1;
			fir();					// calculate filters
			break;

			case 6:
			TXBUF0 = dds_i;			// soft DDS test	
			TXBUF1 = ph_acc;
			break;

			case 7:
			temp = RXBUF0;
			TXBUF0 = temp;			// phase test 1	
			TXBUF1 = temp;
			break;

			case 8:
			temp = RXBUF0;
			TXBUF0 = temp;			// phase test 2	
			TXBUF1 = 0;
			break;

			case 9:					// IIR filter test
			TXBUF0 = RXBUF0;
			
			mic_iir_in = RXBUF1;	// right to filter 
			TXBUF0 = RXBUF0;		// left straight out
			TXBUF1 = mic_iir_out;
			fir();					// calculate filters
			break;
			};

// overload indicator
	temp = RXBUF0;						// get sample from mixer I signal
	if(temp < 0)
		temp = 0 - temp;				// rectify
	if(temp > 20000)			// test value
		LD2 = 1;
	else
		LD2 = 0;

// audio power meter test
	temp = firp_out;					// get sample from audio output
	if(temp < 0)
		temp = 0 - temp;				// rectify

	pwr_accu = pwr_accu + (temp >> 8);	// add rectified sample

	pwr_ctr = ( pwr_ctr + 1 ) & 0x00FF;	// mod 256 loop counter, integrate 256 * 125uS = 32ms(31,25Hz)
	if(pwr_ctr == 0)
		{
		if(pwr_accu < 32768)
			pwr = pwr_accu;
		else
			pwr = 32767;				// saturate to int max
		pwr_accu = 0;
		pwr_rdy = 1;

// peak-hold & decay

		if(pwr > peak_pwr)
			peak_pwr = pwr;					// new peak value

		if(peak_pwr > PH_RELEASE)
			peak_pwr = peak_pwr - PH_RELEASE; // decay rate 31,25Hz
		}



exit_dci:
// run DDS
//
// ph_adder = fout / ( fs / 65536 )
//
// fout = ph_adder * fs / 65536
//
	ph_acc = ph_acc + ph_adder;				// Test fs = 8 kHz
	temp = ph_acc >> 8;
	dds_i = dds_table[(temp&0x00FF)];		// I wave from dds
	dds_q = dds_table[(temp+64)&0x00FF];	// Q wave from dds, +90deg

//	dds_q = dds_table[(temp+128)&0x00FF];	// +180deg from dds, test

	ramp = ramp + 1000;						// test ramp wave

	LD4 = 0;
	}
