//
// Simple UART interface for dsPIC30F6012
// Juha Niinikoski, OH2NLT 18.05.2005
//
// Below is the code to initialize the USART
// 8 bits, 1 start and 1 stop, no error handling
// kbhit and getch added 22.05.2005
// getche aded 02.06.2005unsigned char
// overrun error handling added 29.08.2005


#include <dspic.h>
#include <conio.h>
#include <stdio.h>

//#define BAUD 9600
//#define FCY  1000000	// 4MHz XTAL
//#define FCY  8000000	// 4MHz XTAL x8 PLL = 32MHz
//#define FCY  16000000	// 4MHz XTAL x16 PLL = 64MHz
//#define FCY  29491200	// 7,3728MHz XTAL x16 PLL = 117,9648MHz


void InitUSART1(void)
{
 U1BRG = ((FCY/16)/BAUD) - 1;	// set baud rate

 U1MODE = 0x0000;
 U1STA = 0x0000;

 U1_UARTEN = 1;					// enable uart
 U1_UTXEN = 1;					// enable transmitter
 U1RXIF = 0;					// clear possible pending irq
}

// print character
void putch(char c)
	{
	while(U1_UTXBF == 1)		// wait here if tx fifo full
		{
		}
	U1TXREG = (int)c &0x00FF;	// Tx reg is 16-bit long
	}

// check if key perssed
// Not pressed = 0, Pressed = 1
int kbhit(void)
	{
	if(U1RXIF)
		return 1;
	else
		return 0;
	}

// receive character
char getch(void)
	{
	while(U1RXIF == 0)		// wait for character
		{
		}
// printf("U1STA = 0x%x\n\r", U1STA); // debug
	U1RXIF = 0;				// reset irq flag
	if(U1_OERR == 1)			// OERR is blocking uart
		U1_OERR = 0;		// reset overrun error if occured
	return U1RXREG;			// return with character
	}

// receive character with echo
char getche(void)
	{
	unsigned char c;
	putch(c = getch());
	return c;
	}
