/*

 Cheap DSP dsPICradio board LCD routines
 This is polling driver with 8-bit interface

 Juha Niinikoski OH2NLT 26.08.2005

*/

/* 2 * 16 LCD display memory layout */

#define LINE1     0x00         /* line 1 start address */
#define LINE2     0x40         /* line 2 start address */


#define CURSET     0x80         /* set memory cursor */
#define	CLEAR	   0x01			/* clear display */
#define ADRSET	   0x40			/* set cgram address */


void	clk_lcd(unsigned char ldata)		// set data & clock both lcd controllers
	{
	LCD_DATA = (LCD_DATA & ~LCD_MASK) | (ldata & LCD_MASK);	// set LCD data lines
	us_delay(1);				// extra delay for filter board latch wires
	LCD_E = 1;
	us_delay(2);
	LCD_E = 0;
	}


void	wait_lcd_rdy(void)			// wait until lcd module is ready
	{
	unsigned char BF_AC;			// BF flag & address counter

	BF_AC = 0x80;					// set busy for first round
	LCD_TRIS = LCD_TRIS | LCD_MASK;			// make data port input, LCD bus direction bits = 1
	LCD_RW = 1;				// read
	LCD_RS = 0;				// command mode
	while(BF_AC & 0x80)	
		{
		us_delay(1);;				// 18.01.2004 for slow display
		LCD_E = 1;
		us_delay(3);
		BF_AC = LCD_BUS & LCD_MASK;	// read from port pins
		LCD_E = 0;
		}
	LCD_RW = 0;
	LCD_RS = 1;
	LCD_TRIS = LCD_TRIS & (~LCD_MASK);			// return to write mode
	}

void set_cur_lcd(unsigned char cur)		// set cursor position at selected display
	{
	wait_lcd_rdy( );
	LCD_RS = 0;				// switch command mode		
	clk_lcd(cur | CURSET);			// set cursor command + cursor position
	LCD_RS = 1;				// back to data mode
	}

void clear_lcd(void)				// clear selected display
	{
	wait_lcd_rdy( );
	LCD_RS = 0;				// switch command mode		
	clk_lcd(CLEAR);				// clear display. Display going to be busy 1,6 mS
	LCD_RS = 1;				// back to data mode
	}

void initlcd(void)		// init selected LCD controller
	{
	LCD_RS = 0;			// set command mode
	LCD_RW = 0;
	ms_delay(15);		// start delay
	clk_lcd(0x38);		// write init data with delays
	ms_delay(5);
	clk_lcd(0x38);
	ms_delay(1);
	clk_lcd(0x38);		//8-bit, 2 rows, 5x7 matrix, display on
	ms_delay(1);		//cursor off, no blink
	clk_lcd(0x0C);
	ms_delay(1);
	clk_lcd(0x01);
	ms_delay(2);	
	clk_lcd(0x06);		// increment, no display shift
	ms_delay(1);
	LCD_RS = 1;		// set data mode
	}

void lcdoutch( unsigned char lcd_char )	// output character to selected display
	{
	wait_lcd_rdy();
	clk_lcd(lcd_char);	
	}

/* HD44780 character generator routines */
/* modified for SOLOMON LM1125SYLU1 display */

const char Blockslr[6] = {0x20, 0x00, 0x00, 0x01, 0x01, 0x02};	// blocks for L to R bar graph
const char Blocksrl[6] = {0x20, 0x03, 0x03, 0x04, 0x04, 0x02};	// R to L

void set_cgram(unsigned char adr, unsigned char dta)	// set cgram address & data
	{
	wait_lcd_rdy( );
	LCD_RS = 0;				// switch command mode		
	adr = adr & 0x3F;
	clk_lcd(adr | ADRSET);			// set cgram address command + address
	LCD_RS = 1;				// back to data mode
	wait_lcd_rdy();
	clk_lcd(dta);
	clear_lcd();				// back to normal mode (clear LCD)	
	}


void set_ch_bits(char dta, char cnt)		// set chgen bits. Data, number of sets
	{
	char x;
	for(x=0; x<cnt; x++)
		{
		wait_lcd_rdy();
		clk_lcd(dta);
		}
	}	

void set_chgen(void)				// write bar symbols to HD44780 RAM chgen
	{
	wait_lcd_rdy( );
	LCD_RS = 0;				// switch command mode		
	clk_lcd(0 | ADRSET);			// set cgram address command + address
	LCD_RS = 1;				// back to data mode

	set_ch_bits(0, 1);
	set_ch_bits(0x10, 5);			// CGRAM 00 Blocks L > R
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x14, 5);			// CGRAM 01
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x15, 5);			// CGRAM 02 "Full block"
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x01, 5);			// CGRAM 03 Blocks R > L
	set_ch_bits(0, 2);

	set_ch_bits(0, 1);
	set_ch_bits(0x05, 5);			// CGRAM 04
	set_ch_bits(0, 2);
							
	set_ch_bits(0x08, 7);			// CGRAM 05 spare
	set_ch_bits(0, 1);

	set_ch_bits(0, 3);			// CGRAM 06 S-meter scale dot
	set_ch_bits(0x10, 1);
	set_ch_bits(0, 4);

	set_ch_bits(0, 2);			// CGRAM 07 S-meter scale bar
	set_ch_bits(0x10, 3);
	set_ch_bits(0, 3);

	clear_lcd();				// back to normal mode (clear LCD)
	}

// Meter constants

#define DISP_LEN 16					// display lemgth (char)
#define FONT_W 6					// font width
#define MAX_GRAPH (DISP_LEN * FONT_W)			// graph length in pixels (5*16 = 80)

const char scale_dots[16] = {6,32,6,32,6,32,6,32,7,32,7,32,7,32,7,32};

// draw S-meter, scale = 0...96 (48 visible steps)
// buffer is used to avoid LCD flicker

void draw_s_meter(char len)
	{
	char x;
	char whole;
	char part;
	char idx;
	char bar_buffer[DISP_LEN];			// display buffer
	
	if(len > MAX_GRAPH)				// cut to max
		len = MAX_GRAPH;

	whole = len / FONT_W;				// calculate graph
	part = len % FONT_W;

	idx = 0;
	for(x=0; x<DISP_LEN; x++)			// copy scale dots to buffer
		{
		bar_buffer[idx] = scale_dots[x];
		idx++;
		}

	idx = 0;					// draw graph to buffer	
	while(whole > 0)			
		{
		bar_buffer[idx] = 0x02;			// draw full blocks
		idx++;	
		whole--;
		}

	if(part > 0)
		bar_buffer[idx] = Blockslr[part]; 	// draw partial block to buffer

	for(x=0; x<DISP_LEN; x++)			// print meter buffer to LCD
		{
		lcdoutch(bar_buffer[x]);
		}
	}


// draw graph
// 0 = left to rigth, 1 = rigth to left

void draw_bar(char len, char dir)			// draw bar graph
	{
	char x;
	char whole;
	char part;
	char l;
	char idx;
	char bar_buffer[DISP_LEN];			// display buffer

	if(len > MAX_GRAPH)				// cut to max
		len = MAX_GRAPH;

	l =  DISP_LEN;
	whole = len / FONT_W;				// calculate graph
	part = len % FONT_W;

	if(dir == 0)					// L to R
		{
		idx = 0;

		while(whole > 0)			
			{
			bar_buffer[idx] = 0x02;		// draw full blocks
			idx++;	
			whole--;
			l--;
			}
	
		if(part > 0)
			{
			bar_buffer[idx] = Blockslr[part]; // draw partial block
			idx ++;
			l--;
			}	

		for(x=0; x<l; x++)			// clear rest of the line
			{
			bar_buffer[idx] = 0x20;
			idx++;
			}

		}
	else						// draw from R to L
		{
		idx = DISP_LEN - 1;
		while(whole > 0)			
			{
			bar_buffer[idx] = 0x02;		// draw full blocks
			idx--;	
			whole--;
			l--;
			}
	
		if(part > 0)
			{
			bar_buffer[idx] = Blocksrl[part]; // draw partial block
			idx --;
			l--;
			}	

		for(x=0; x<l; x++)			// clear rest of the line
			{
			bar_buffer[idx] = 0x20;
			idx--;
			}
		}

	for(x=0; x<DISP_LEN; x++)			// print buffer
		{
		lcdoutch(bar_buffer[x]);
		}
	}


/* General I/O functions */

void lcd_putch(unsigned char c)
	{
	lcdoutch(c);
	}

void lcd_putst(register const char *str)
	{
	while((*str)!=0)
		{
		lcdoutch(*str);
    	if (*str==13) lcdoutch(10);
    	if (*str==10) lcdoutch(13);
		str++;
		}
	}

/* put long in decimal format */
/* if mode !=0 do "short" frequency display */

void disp_long( long x, char mode )
	{
	if(mode == 0)			// full display
		{
		//giga
		lcdoutch((x/1000000000)+'0');
		x-=(x/1000000000)*1000000000;


		lcdoutch('.');

		//100_million
		lcdoutch((x/100000000)+'0');
		x-=(x/100000000)*100000000;
		}
	
	//10_million
	if(mode !=0 && x/10000000 == 0)
		lcdoutch(' ');		// leadign zero blanc for frequency display
	else
		lcdoutch((x/10000000)+'0');

	x-=(x/10000000)*10000000;

	//million
	lcdoutch((x/1000000)+'0');
	x-=(x/1000000)*1000000;


	lcdoutch('.');

	//100_thousands
	lcdoutch((x/100000)+'0');
	x-=(x/100000)*100000;

	//10_thousands
	lcdoutch((x/10000)+'0');
	x-=(x/10000)*10000;

	//thousands
	lcdoutch((x/1000)+'0');
	x-=(x/1000)*1000;


	lcdoutch('.');

	//hundreds
	lcdoutch((x/100)+'0');
	x-=(x/100)*100;

	//tens
	lcdoutch((x/10)+'0');
	x-=(x/10)*10;

	//ones
	lcdoutch((x/1)+'0');

	}


// display frequency
void disp_freq(long x)
	{
	disp_long( x, 1 );
	}
