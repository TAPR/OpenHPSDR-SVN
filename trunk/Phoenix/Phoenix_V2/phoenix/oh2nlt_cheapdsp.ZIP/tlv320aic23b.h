//
// TLV320AIC23B Codec definitions
//
// Juha Niinikoski, OH2NLT 31.08.2005
//


// TLV320AIC23B Register Address Definitions
// B[15:9] = register address, B[8:0] = control bits
#define TLV_LLICVC	0			// Left line input channel volume control
#define TLV_RLICVC	(1<<9)		// Right line input channel volume control
#define	TLV_LCHVC	(2<<9)		// Left channel headphone volume control
#define	TLV_RCHVC	(3<<9)		// Right channel headphone volume control
#define	TLV_AAPC	(4<<9)		// Analog audio path control
#define	TLV_DAPC	(5<<9)		// Digital audio path control
#define	TLV_PDC		(6<<9)		// Power down control
#define	TLV_DAIF	(7<<9)		// Digital audio interface format
#define TLV_SRC		(8<<9)		// Sample rate control
#define TLV_DIA		(9<<9)		// Digital interface activation
#define	TLV_RR		(15<<9)		// Register reset


// Left / Right line input channel volume control bits
// 0x00 = -34,5 dB, 0x17 = 0 dB, 0x1F = +12 dB. 1,5 dB steps
#define	TLV_IVMASK	(0x001F)	// Left / right input volume control bits
#define	TLV_LIM		(1<<7)		// Left input mute
#define	TLV_RIM		(1<<7)		// Right input mute
#define TLV_LRS		(1<<8)		// Left / right simultaneous volume/mute update
#define TLV_RLS		(1<<8)		// Right /left


// Headphone volume control
// 0x7F = +6 dB, 0x30 = -73dB(mute), under 0x30 mute
#define TLV_HVMASK	(0x007F)	// left / right headphone volume control bits
#define TLV_LZC		(1<<7)		// Left ch zero-cross detect
#define TLV_RZC		(1<<7)		// Right ch zero-cross detect
// LRS, RLS same as for input chanels


// Analog audio path control
#define	TLV_MICB	(1<<0)		// Microphone boost, 1 = +20 dB
#define	TLV_MICM	(1<<1)		// Microphone mute, 1 = mute
#define	TLV_INSEL	(1<<2)		// Input select, 0 = line, 1 = microphone
#define	TLV_BYP		(1<<3)		// Bypass, 1 = bypass on
#define	TLV_DAC		(1<<4)		// DAC select, 1 = on
#define	TLV_STE		(1<<5)		// Side tone enable
#define	TLV_STA0	(1<<6)		// Side tone bits
#define	TLV_STA1	(1<<7)
#define	TLV_STA2	(1<<8)
#define TLV_STAMASK	0x01C0		// Side tone level bits


// Digital audio path control
#define	TLV_ADCHP	(1<<0)		// ADC high-pass filter, 0 = enabled, 1 = disabled
#define	TLV_DEEMP0	(1<<1)		// 00 = disabled, 01 = 32kHz, 10 = 44,1kHz, 11=48kHz
#define	TLV_DEEMP1	(1<<2)		// 
#define	TLV_DACM	(1<<3)		// DAC soft mute, 1 = mute


// Power down control
#define	TLV_LINE_PWR	(1<<0)		// Line input, 0 = on, 1 = off
#define	TLV_MIC_PWR		(1<<1)		// Microphone input
#define	TLV_ADC_PWR		(1<<2)		// ADC
#define	TLV_DAC_PWR		(1<<3)		// DAC
#define	TLV_OUT_PWR		(1<<4)		// Outputs
#define	TLV_OSC_PWR		(1<<5)		// Oscillator
#define	TLV_CLK_PWR		(1<<6)		// Clock
#define	TLV_OFF_PWR		(1<<7)		// Device power


// Audio interface format
#define	TLV_FOR0	(1<<0)		// Data format, 00 = MSB first right aligned, 01 = MSB first left aligned
#define	TLV_FOR1	(1<<1)		// 10 = I2S format, MSB first, left-1 aligned, 11 = DSP format
#define TLV_RALIN	0x0000		// MSB first right aligned
#define TLV_LALIN	0x0001		// MSB first left aligned
#define TLV_I2S		0x0002		// I2S format, MSB first, left-1 aligned
#define TLV_DSP		0x0003		// DSP format
#define	TLV_IWL0	(1<<2)		//
#define	TLV_IWL1	(1<<3)		// Input length, 00=16bit, 01=20bit, 10=24bit, 11=32bit
#define TLV_16_BIT	0x0000		// 16-bit format
#define TLV_20_BIT	0x0004		// 20-bit format
#define TLV_24_BIT	0x0008		// 24-bit format
#define TLV_32_BIT	0x000C		// 32-bit format
#define	TLV_LRP		(1<<4)		// left right phase, 1 = right ch on LRCIN low
#define	TLV_LRSWAP	(1<<5)		// left <> right swap, 1 = enabled
#define	TLV_MS		(1<<6)		// Master / Slave mode, 1 = master


// Sample rate control
#define	TLV_USBNORMAL	(1<<0)		// USB mode = 1
#define	TLV_BOSR	(1<<1)		// Base oversampling rate, USB mode 250/272, normal 256,384, 1 = 384
#define TLV_SRMASK	0x003C		// sampling rate control bits, see table
#define	TLV_CLKIN	(1<<6)		// Clock input divider, 1 = MCLK/2
#define	TLV_CLKOUT	(1<<7)		// Clock output divider, 1 = MCLK/2


// Digital interface activation
#define	TLV_ACT	(1<<0)			// Activate interface, 1 = active

// Reset Register
#define TLV_RES		0			// Soft reset = write 0 to reset register




