/*

 Cheap DSP dsPICradio board ADC12 routines


 Juha Niinikoski OH2NLT 27.08.2005

*/


// init ADC system for dsPICradio board
// only CH14 and CH15 are used
// remember to set ADC pins as port input
// Reference from VCC

void init_adc12(void)
	{
	ADCSSL = 0x0000;					// scan select
	ADPCFG = 0x3FFF;					// AN14 and AN15 in use
	ADCHS = 0x000F;						// select CH15, Vref- for MUXA
	ADCON3 = 0x0080;					// internal RC clock
	ADCON2 = 0x0000;					// use MUXA, do not scan inputs
//	ADCON1 = 0x8004;					// ADON, format = integer, manual sampling, auto start
	ADCON1 = 0x8000;					// ADON, format = integer, manual sampling, manual start		
	}


// convert channell #14

int convert_adc12_14(void)
	{
	ADCHS = 0x000E;						// select CH14, Vref- for MUXA
	SAMP = 1;							// start sampling
	us_delay(500);
	SAMP = 0;							// start conversion

	while(DONE == 0);					// wait for ready

	return(ADCBUF0);					// return with buff#0
	}

// convert channell #15

int convert_adc12_15(void)
	{
	ADCHS = 0x000F;						// select CH15, Vref- for MUXA
	SAMP = 1;							// start sampling
	us_delay(500);
	SAMP = 0;							// start conversion

	while(DONE == 0);					// wait for ready

	return(ADCBUF0);					// return with buff#0
	}
