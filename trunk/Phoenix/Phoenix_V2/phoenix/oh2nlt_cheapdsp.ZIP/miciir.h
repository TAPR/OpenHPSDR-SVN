/*

 Cheap DSP dsPICradio board IIR Microphone filter
 
 Juha Niinikoski OH2NLT 18.09.2005

*/

// Microphone test BPF filter
// fs = 8000 Hz
// f1 = 1300 Hz
// f2 = 1800 Hz
// pass band riple 1dB

#if 0
const int mic_coef[10] = {
// first IIR
        5348,	// a0
           0,	// a1
       -5348,	// a2
      10393,	// -b0
       -26124,	// -b1
// second IIR
       6939,
           0,
       -6939,
      30261,
       -26877
};
#endif

// Microphone test LPF filter
// fs = 8000 Hz
// f1 = 2100 Hz
// pass band riple 0,3dB
// designed with Toshio Iwata DFALZ1 program
/*
a0 =       15723
a1 =       31447
a2 =       15723
b1 =        7747
b2 =       22379

a0 =        6398
a1 =       12796
a2 =        6398
b1 =      -12827
b2 =        5651
*/
const int mic_coef[10] = {
// first IIR
		15723,	// a0
		31447,	// a1
		15723,	// a2
		-7747,	// -b0
		-22379,	// -b1
// second IIR
		6398,
		12796,
		6398,
		12827,
		-5651
};
