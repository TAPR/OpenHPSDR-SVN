/*

 AD9850 DDS chip driver

 Si-Tecno Juha Niinikoski 02.04.2004

 AD9851 test code added 26.08.2004

*/


/* AD9850 data transfer */

void dds_send_one( unsigned char dta )		// send one byte LSB first
	{
	char x;
	for(x=0; x<8; x++)			// do all bits
		{
		if(dta & 1)
			DDS_SER = 1;
		else
			DDS_SER = 0;

		DDS_W_CLK = 1;			// generate clock pulse
		dta = dta >> 1;			// move next bit
		DDS_W_CLK = 0;	
		}
	}

void dds_load(void)				// load AD9850 from buffer			
	{
	char x;
	for(x=0; x<5; x++)
		{
		dds_send_one(dds.ad9850[x]);	// send 40 bits
		}

	DDS_FQ_UD = 1;				// generate update pulse
	DDS_FQ_UD = 0;
	}

/* Init AD9850 interface */

void dds_init(void)
	{
	DDS_RESET = 1;				// reset AD9850
	DDS_SER = 0;
	DDS_RESET = 0;

	DDS_FQ_UD = 1;				// generate update pulse
	DDS_FQ_UD = 0;				// set serial mode

#ifdef AD9851	
	dds.dds_regs.dds_config = 0x01;		// control & phase bits = 0x01, 6xmultiplier enabled
#else
	dds.dds_regs.dds_config = 0;		// control & phase bits = 0
#endif

	}

