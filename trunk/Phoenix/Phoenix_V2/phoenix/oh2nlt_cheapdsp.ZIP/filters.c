/*

 Cheap DSP dsPICradio board filter routines
 filters are calculated at fir.as module
 on every 8 kHz interrupt.

 Juha Niinikoski OH2NLT 11.09.2005

 IIR filter for Microphone input added 18.09.2005

*/

//*************************************************************************
// filter coefficients

#include "hilbert69.h"			// 69-tap Hilbert pair
#include "bpf.h"				// 101-tap band pass filter
#include "miciir.h"				// Microphone filter

//**************************************************************************

#define BL	256					// buffer  reservation

// FIR filter data

// Left
extern int firl_taps[BL];		// filter taps
extern int firl_taps_end;		// last members address
extern int firl_n;				// N, Number of taps

extern int firl_dly[BL];		// filter delay line
extern int firl_dly_end;		// last address of ring buffer
extern int firl_dly_ptr;		// ring buffer insert pointer
extern int firl_in;				// left filter input
extern int firl_mul;			// left multiplier
extern int firl_out;			// left filter output
extern int firl_mix;			// left mixer

// Right
extern int firr_taps[BL];		// filter taps
extern int firr_taps_end;		// last members address
extern int firr_n;				// N, Number of taps

extern int firr_dly[BL];		// filter delay line
extern int firr_dly_end;		// last address of ring buffer
extern int firr_dly_ptr;		// ring buffer insert pointer
extern int firr_in;				// right filter input
extern int firr_mul;			// right multiplier
extern int firr_out;			// right filter output
extern int firr_mix;			// right mixer

// Post filter
extern int firp_taps[BL];		// filter taps
extern int firp_taps_end;		// last members address
extern int firp_n;				// N, Number of taps

extern int firp_dly[BL];		// filter delay line
extern int firp_dly_end;		// last address of ring buffer
extern int firp_dly_ptr;		// ring buffer insert pointer
extern int firp_in;				// right filter input
extern int firp_out;			// right filter output


// IIR filter data

// Microphone filter
extern int mic_iir_coef[5];		// filter coefficients, 0,1,2 = A0,A1,A2  3,4 = B1,B2
extern int mic_iir_dly[5];		// filter delay line
extern int mic_iir_in;			// Mic filter input
extern int mic_iir_out;			// Mic filter output

//****************************************************************************************

// init FIR filters & delay line

void init_fir(void)
	{
	int x;

// Left
	firl_n = N;
	firl_dly_ptr = (int)firl_dly;
	firl_dly_end = firl_dly_ptr + ((2*N)-1);		// end address(last byte) for modulo ring

	firl_taps_end = ((int)firl_taps) + ((2*N)-2);	// end address(last word) for tap vector

// Right
	firr_n = N;
	firr_dly_ptr = (int)firr_dly;
	firr_dly_end = firr_dly_ptr + ((2*N)-1);		// end address(last byte) for modulo ring

	firr_taps_end = ((int)firr_taps) + ((2*N)-2);	// end address(last word) for tap vector

// copy taps
	for(x=0; x<N; x++)
		{
		firl_dly[x] = 0;
		firl_taps[x] = l_taps[x];					// set left ch filter taps

		firr_dly[x] = 0;
		firr_taps[x] = r_taps[x];					// set right ch taps
		}

// Post Filter
	firp_n = post_N;
	firp_dly_ptr = (int)firp_dly;
	firp_dly_end = firp_dly_ptr + ((2*post_N)-1);		// end address(last byte) for modulo ring

	firp_taps_end = ((int)firp_taps) + ((2*post_N)-2);	// end address(last word) for tap vector

// copy post filter taps
	for(x=0; x<post_N; x++)
		{
		firp_dly[x] = 0;
		firp_taps[x] = bpf_taps[x];						// set band pass filter taps
		}

// set input multipliers
		firl_mul = 0x7FFF;
		firr_mul = 0x7FFF;

// software mixers
		firl_mix = 0x7FFF;
		firr_mix = 0x7FFF;

// Mic filter
	for(x=0; x<10; x++)
		{
		mic_iir_dly[x] = 0;
		mic_iir_coef[x] = mic_coef[x];					// set mic filter coefficients
		}

	}

