This is a four (4) layer board.  
FR4
.062" thick


The following files are included:

Readme.txt	This file
atlasL1.pho	Top layer
atlasL2.pho	Signal layer 2
atlasL3.pho	Power layer
atlasL4.pho	Bottom layer
atlasDDG.pho	Drill drawing
atlasTSK.pho	Top silkscreen
atlasTSM.pho	Top soldermask
atlasBSM.pho	Bottom soldermask
atlasASY.pho	Top assembly drawing w/ board outline
atlasNCD.drl	NC drill file

Stack order:

Top silkscreen
Top solder mask
Top layer
Signal layer 2
Power layer
Bottom layer
Bottom solder mask

[end of file]

