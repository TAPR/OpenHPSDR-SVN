OZY_REVA

June 14, 2006
The Ohio State University
Department of Astronomy
Imaging Sciences Lab
4055 McPherson Laboratory
140 West 18th Avenue
Columbus, OH 43210-1173, USA

Contact: Phil Covington
614-247-4374
pcovington@astronomy.ohio-state.edu

Board Details:

No Touch
Thickness: 0.062"
Material: FR4
Dimensions: X 4.724" x Y 3.940"
Layers: 4
Min Trace Width: 7
Min Spacing: 7
Smallest Hole Size: 0.015"
Total Holes: 936
Finish: HAL
Solder Mask: LPI Both Sides, Green
Silkscreen: Top Side, White
Finished Copper: 1 oz.
CNC route points: 4
Internal cutout - None

Drill Sizes Used:
T1 0.015"
T2 0.033"
T3 0.035"
T4 0.036"
T5 0.037"
T6 0.045"
T7 0.090"
T8 0.110"
T9 0.125"


