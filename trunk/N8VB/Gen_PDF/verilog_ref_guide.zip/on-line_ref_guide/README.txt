
This hyper-linked Verilog Quick Reference Guide is provided as a courtesy
by Sutherland HDL, Inc., 22805 SW 92nd Place, Tualatin, OR  97062, USA.

To view this reference guide, load the file vlog_ref_top.html in your
web browser.

******* THIS REFERENCE GUIDE IS COPYRIGHTED MATERIAL *******

Copyright 1997, All rights reserved.
You may use this reference guide for personal use.  
You may not reproduce this document or any portion thereof in any form! 


Sutherland HDL, Inc. provides expert Verilog HDL and PLI training and design
consulting services.  We have trained engineers on the proper and most
effective methods to model with Verilog at companies throughout the world.
Please visit our web site, www.sutherland-hdl.com, for a full description
of our services and Verilog training workshops.

This reference guide is available as a professionally printed, spiral bound
pocket-size booklet.  Visit www.sutherland-hdl.com or call Sutherland HDL
at 1-503-692-0898 for information on ordering a hardcopy of this Verilog
reference guide.

Enjoy!

Stuart Sutherland,
President, Sutherland HDL, Inc.
