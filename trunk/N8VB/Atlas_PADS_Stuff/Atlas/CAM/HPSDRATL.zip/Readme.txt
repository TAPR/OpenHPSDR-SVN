HPSDR_ATLAS_NR

Mar 28, 2006
The Ohio State University
Department of Astronomy
Imaging Sciences Lab
4055 McPherson Laboratory
140 West 18th Avenue
Columbus, OH 43210-1173, USA

Contact: Phil Covington
614-247-4374
pcovington@astronomy.ohio-state.edu

Board Details:

Thickness: 0.062"
Material: FR4
Dimensions: X 5.50" x Y 3.94"
Layers: 4
Min Trace Width: 10
Min Spacing: 10
Smallest Hole Size: 0.020"
Total Holes: 1015
Finish: HAL
Solder Mask: LPI Both Sides, Green
Silkscreen: Top Side, White
Finished Copper: 1 oz.
CNC route points: 4
Internal cutout - QTY 0
No Touch Service
No nonplated holes
SMT on top side

Drill Sizes Used:
T1 0.020"
T2 0.033"
T3 0.037"
T4 0.045"
T5 0.055"
T6 0.118"
T7 0.125"


