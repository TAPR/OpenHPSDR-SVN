Release Notes for CDC RS-232 Emulation Reference Projects, Microchip Technology Inc.
19 November 2004


When changing the Product ID and Vendor ID, both the firmware (usbdsc.c) and
the .inf file must be updated with the new IDs.