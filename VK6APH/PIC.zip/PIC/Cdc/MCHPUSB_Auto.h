#include <P16F84.h>
#include <P16F84_bits.h>
#include <PortBits.h>

#define APROCFREQ 4000000

#define BITSIZE 14
#define BOOTADDRESS 0
#define FIRSTRAM 0x0C
#define LASTRAM 0x4F
#define HASOSCCAL 0
#define nPAGESRAM 1
#define nPAGESROM 1
//
// Header file - should be included in all C files used within the program
// This file is created automatically and should not be changed
//

//
// Functions
//
void UserInitialise();			// Your initialisation code
void UserInterrupt();			// Your interrupt code
void UserLoop();			// your Main loop code



// **********
//
// Application Designer Variables
//
// **********


// Defines specified by 1 or more elements

