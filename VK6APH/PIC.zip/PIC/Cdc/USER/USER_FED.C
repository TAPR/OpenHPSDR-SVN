//
// FED application to provide a pass though serial port - input data is sent to the USART port at 115200. There is no
// flow control on the USART port.
//
// This is a relatiely crude conversion and does not account for changes in bit rate requested by the host.
//
// To do this it is worth setting a flag when line coding changes (see cdc.h) and testing for this flag in this file. 
// Then when the  flag is set go and set up the USART with the new line coding parameters.
//
/** I N C L U D E S **********************************************************/
#include <usbcdc.h>
#include "user\user.h"

/** V A R I A B L E S ********************************************************/
char input_buffer[64];
char output_buffer[64];

const char Welcome[]={"FED USB Comm Port"};

unsigned char TxState,txlen;
char *tdp;			// Parameters for transmit from USB out of USART
unsigned char rxlen;		// length of receive buffer
char *rdp;			// Parameters for transmit from USB out of USART

enum TxStates {TXFIRST=0,TXING=1,TXCLEAR};


/** P R I V A T E  P R O T O T Y P E S ***************************************/
void InitializeUSART(void);
void BlinkUSBStatus(void);
void DumpTokens();	//#

/** D E C L A R A T I O N S **************************************************/
#pragma code
void UserInit(void)
{
    mInitAllLEDs();
    InitializeUSART();   
    
    TxState=TXFIRST;
    rdp=output_buffer;
}//end UserInit

void InitializeUSART(void)
{
    bRC6=1;
    TRISCbits.TRISC7=1; // RX
    TRISCbits.TRISC6=0; // TX
//#    SPBRG = 0x71;
//#    SPBRGH = 0x02;      // 0x0271 for 48MHz -> 19200 baud
    SPBRG = 0x68;
    SPBRGH = 0x0;      // 0x068 for 48MHz -> 115200 baud
    TXSTA = 0x24;       // TX enable BRGH=1
    RCSTA = 0x90;       // continuous RX
    BAUDCON = 0x08;     // BRG16 = 1
}//end InitializeUSART

/******************************************************************************
 * Function:        void ProcessIO(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is a place holder for other user routines.
 *                  It is a mixture of both USB and non-USB tasks.
 *
 * Note:            None
 *****************************************************************************/
 
void ProcessIO(void)
{   
 BlinkUSBStatus();
 // User Application USB tasks
 if((usb_device_state < CONFIGURED_STATE)||(bSUSPND==1)) return;
 
 if (TxState==TXFIRST)
 {
  txlen=sizeof(Welcome);
  tdp=Welcome;
  TxState=TXING;
 }
 if (TxState==TXCLEAR)
 {
  txlen=getsUSBUSART(input_buffer,64);
  if (txlen) {TxState=TXING; tdp=input_buffer;}
 }
 if ((TxState==TXING) && bTXIF)
 {
  txlen--;
  TXREG=*tdp++;
  if (!txlen) TxState=TXCLEAR;
 }
 if (bRCIF)
 {
  *rdp++=RCREG;
  rxlen++;
 }
 if (rxlen && (cdc_trf_state==CDC_TX_READY))
 {
  //putUSBUSART(output_buffer,rxlen);
  rxlen=0;
  rdp=output_buffer;
 }
 
}//end ProcessIO

/******************************************************************************
 * Function:        void BlinkUSBStatus(void)
 *
 * PreCondition:    None
 *
 * Input:           None
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        BlinkUSBStatus turns on and off LEDs corresponding to
 *                  the USB device state.
 *
 * Note:            mLED macros can be found in io_cfg.h
 *                  usb_device_state is declared in usbmmap.c and is modified
 *                  in usbdrv.c, usbctrltrf.c, and usb9.c
 *****************************************************************************/
void BlinkUSBStatus(void)
{
    static word led_count=0;
    
    if(led_count == 0)led_count = 10000U;
    led_count--;

    #define mLED_Both_Off()         {mLED_1_Off();mLED_2_Off();}
    #define mLED_Both_On()          {mLED_1_On();mLED_2_On();}
    #define mLED_Only_1_On()        {mLED_1_On();mLED_2_Off();}
    #define mLED_Only_2_On()        {mLED_1_Off();mLED_2_On();}
    
    #ifdef FEDUSBDEBUG
     if (!bRB5) DumpTokens(); //##
    #endif

    if(bSUSPND == 1)
    {
        if(led_count==0)
        {
            mLED_1_Toggle();
            mLED_2 = mLED_1;        // Both blink at the same time
        }//end if
    }
    else
    {
        if(usb_device_state == DETACHED_STATE)
        {
            mLED_Both_Off();
        }
        else if(usb_device_state == ATTACHED_STATE)
        {
            mLED_Both_On();
        }
        else if(usb_device_state == POWERED_STATE)
        {
            mLED_Only_1_On();
        }
        else if(usb_device_state == DEFAULT_STATE)
        {
            mLED_Only_2_On();
        }
        else if(usb_device_state == ADDRESS_STATE)
        {
            if(led_count == 0)
            {
                mLED_1_Toggle();
                mLED_2_Off();
            }//end if
        }
        else if(usb_device_state == CONFIGURED_STATE)
        {
            if(led_count==0)
            {
                mLED_1_Toggle();
                mLED_2 = !mLED_1;       // Alternate blink                
            }//end if
        }//end if(...)
    }//end if(UCONbits.SUSPND...)

}//end BlinkUSBStatus
