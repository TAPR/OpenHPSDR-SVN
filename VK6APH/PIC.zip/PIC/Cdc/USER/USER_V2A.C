/****************************************************************************
*
* user_v3.c  P V Harman VK6APH
*
* This program samples A0 of the A/D converter at 8kbps and sends it to the 
* PC via the USB connection when S2 is pressed.
* It uses Timer 0 to create an interupt every 1/8kHz seconds. At each 
* interrupt LED D4 is toggled so the frequency and stability can be 
* checked with a 'scope.
*
* USB Led flash is turned off to prevent jitter on 1/8kHz interrupt
* ERROR in that data is actually only sent every 1mS.
*
* NB: Blocking functions must NOT be used so that USB hardware can always
* be serviced.
* NOTE: use byte and not BYTE since latter defines a union
*
****************************************************************************/
#include <FEDC18.h>
#include "system\typedefs.h"
#include "system\usb\usb.h"
#include "io_cfg.h"             // I/O pin mapping
#include "user\user.h"

#define LED4 PD.B3				// LED D4 on development board 

/** GLOBAL V A R I A B L E S ***********************************************/
#pragma udata
byte old_sw2,old_sw3;
static byte state = 0;
static byte doatod = 0;
byte Flag = 0;  
char input_buffer[64];
char output_buffer[64];

/** P R I V A T E  P R O T O T Y P E S ***************************************/
void InitializeUSART(void);
void BlinkUSBStatus(void);
BOOL Switch2IsPressed(void);
BOOL Switch3IsPressed(void);
void Interrupt();		// define interupt routine
void AtoDtoUSB(void);

/** D E C L A R A T I O N S **************************************************/
#pragma code
void UserInit(void)
{
    mInitAllLEDs();
    mInitAllSwitches();
    old_sw2 = sw2;
    old_sw3 = sw3;
    // set up A.D converter on PortA 0
	bTRA0 = 1; 	   // set port A bit 0 as input for A/D
	ADCON1 = 0x0E; // set AN0 as input and VSS, VDD as ref
	ADCON0 = 0x01; // select channel 0 and turn A/D on
	ADCON2 = 0x80; // right justified, TAD, Fosc/2
   
	//PORTD = 0x00;  // set all port D outputs low
	//TRISD = 0x00;  // set port D as output
	bTRD3 = 0;  // set port D bit 3 as output for LED 
	
	//set up timer 0  to divide 5MHz clock by 2
	
	bT0CS = 0; 		// select internal clock
	bT0SE = 0;		// increment on low to high transition
	bT08BIT = 1;	// select 8 bit counter
	bPSA  = 0;		// use pre scaler
	
	// setTMR0  pre-scale to 2
	bT0PS2 = 0; bT0PS1 = 0; bT0PS0 = 0;
	
	bTMR0ON = 1;  	// enable timer 0
	
	bT0IE = 1; 		// enable TMR0 interrupts
	bGIE  = 1;		// enable interrupts 
	
	InitializeUSART();  
}

void InitializeUSART(void)
{
    bRC6=1;
    TRISCbits.TRISC7=1; // RX
    TRISCbits.TRISC6=0; // TX
    SPBRG = 0x68;
    SPBRGH = 0x0;       // 0x068 for 48MHz -> 115200 baud
    TXSTA = 0x24;       // TX enable BRGH=1
    RCSTA = 0x90;       // continuous RX
    BAUDCON = 0x08;     // BRG16 = 1
}

/*****************************************************************************
 * Function:        void ProcessIO(void)
 *
 * Overview:        This function is a place holder for other user routines.
 *                  It is a mixture of both USB and non-USB tasks.
 *****************************************************************************/
void ProcessIO(void)
{   
    //BlinkUSBStatus();		// Bink USB status LEDs
    
    // User Application USB tasks
    if((usb_device_state < CONFIGURED_STATE)||(bSUSPND==1)) return;

	AtoDtoUSB();			// call A to D converter on PortA 0 and send to USB 
}

void AtoDtoUSB(void)
{
	int ad_data;
	byte buffer[2];
	static int count = 0;
	
	// count the number of times that timer 0 interupts, when it has done so
	// 6 times then we have an 8kHz clock  (48kHz/6 = 8) 
	
	if(Flag)
	{ 
		doatod++;
		Flag = 0; 			// reset Timer 0 48kHz flag
	}
	
	// get A/D value and send to PC virtual terminal via USB
	if(state == 0 && doatod == 6)
	{
		doatod = 0; 		// reset 8kHz divider 
		//bGO = 1;			// start A/D conversion 
		state++;
	}
	if ((state == 1) && !bGO)			// check if A/D is complete
		state++;
	
	if (state == 2)
	{
		if(sw2 ==0) // send data when S2 is pressed 
		{
			buffer[0] = ADRESH;  // top 2 bits of A/D conversion
			buffer[1] = ADRESL;	 // bottom 8 bits
			
			if(mUSBUSARTIsTxTrfReady())
			{
				mUSBUSARTTxRam((byte*)buffer,2); // send A/D data
				LED4 = !LED4;
			}
		}
		bGO = 1;	// start A/D conversion 
		state = 0;  // reset state and start again
	}
    
}

// Timer 0 interrups every 1/48kHz seconds, set a flag when this happens

void Interrupt()
{
	 if (bTMR0IF)
	 {
	  	bTMR0IF = 0;		// reset TMR0 interrupt flag
	  	TMR0L = (~118) +1;  // set TMR0 - gives 48KHz with my xtal
	  	Flag=1;				// Set flag to show 1/48kHz seconds has passed
	 }
}

/******************************************************************************
 * Function:        void BlinkUSBStatus(void)
 *
 * Overview:        BlinkUSBStatus turns on and off LEDs corresponding to
 *                  the USB device state.
 *
 * Note:            mLED macros can be found in io_cfg.h
 *                  usb_device_state is declared in usbmmap.c and is modified
 *                  in usbdrv.c, usbctrltrf.c, and usb9.c
 *****************************************************************************/
void BlinkUSBStatus(void)
{
    static word led_count=0;
    
    if(led_count == 0)led_count = 10000U;
    led_count--;

    #define mLED_Both_Off()         {mLED_1_Off();mLED_2_Off();}
    #define mLED_Both_On()          {mLED_1_On();mLED_2_On();}
    #define mLED_Only_1_On()        {mLED_1_On();mLED_2_Off();}
    #define mLED_Only_2_On()        {mLED_1_Off();mLED_2_On();}
    
    if(bSUSPND == 1)
    {
        if(led_count==0)
        {
            mLED_1_Toggle();
            mLED_2 = mLED_1;        // Both blink at the same time
        }
    }
    else
    {
        if(usb_device_state == DETACHED_STATE)
        {
            mLED_Both_Off();
        }
        else if(usb_device_state == ATTACHED_STATE)
        {
            mLED_Both_On();
        }
        else if(usb_device_state == POWERED_STATE)
        {
            mLED_Only_1_On();
        }
        else if(usb_device_state == DEFAULT_STATE)
        {
            mLED_Only_2_On();
        }
        else if(usb_device_state == ADDRESS_STATE)
        {
            if(led_count == 0)
            {
                mLED_1_Toggle();
                mLED_2_Off();
            }
        }
        else if(usb_device_state == CONFIGURED_STATE)
        {
            if(led_count==0)
            {
                mLED_1_Toggle();
                mLED_2 = !mLED_1;       // Alternate blink                
            }
        }
    }

}

BOOL Switch2IsPressed(void)
{
    if(sw2 != old_sw2)
    {
        old_sw2 = sw2;                  // Save new value
        if(sw2 == 0)                    // If pressed
            return TRUE;                // Was pressed
    }
    return FALSE;                       // Was not pressed
}

BOOL Switch3IsPressed(void)
{
    if(sw3 != old_sw3)
    {
        old_sw3 = sw3;                  // Save new value
        if(sw3 == 0)                    // If pressed
            return TRUE;                // Was pressed
    }
    return FALSE;                       // Was not pressed
}

