#line 1 "C:/Program Files/FED/PIXIE/PreProc.C"
#line 3 "C:/Program Files/FED/PIXIE/Libs/ProcIncs/P18F4550.h"
typedef unsigned char BYTE;
typedef unsigned char FileReg;
typedef unsigned int WORD;
typedef unsigned long ulong;
#line 16
extern unsigned char SPPDATA;
#pragma locate SPPDATA 0x0F62
extern unsigned char SPPCFG;
#pragma locate SPPCFG 0x0F63
extern unsigned char SPPEPS;
#pragma locate SPPEPS 0x0F64
extern unsigned char SPPCON;
#pragma locate SPPCON 0x0F65
extern unsigned char UFRM;
#pragma locate UFRM 0x0F66
extern unsigned char UFRML;
#pragma locate UFRML 0x0F66
extern unsigned char UFRMH;
#pragma locate UFRMH 0x0F67
extern unsigned char UIR;
#pragma locate UIR 0x0F68
extern unsigned char UIE;
#pragma locate UIE 0x0F69
extern unsigned char UEIR;
#pragma locate UEIR 0x0F6A
extern unsigned char UEIE;
#pragma locate UEIE 0x0F6B
extern unsigned char USTAT;
#pragma locate USTAT 0x0F6C
extern unsigned char UCON;
#pragma locate UCON 0x0F6D
extern unsigned char UADDR;
#pragma locate UADDR 0x0F6E
extern unsigned char UCFG;
#pragma locate UCFG 0x0F6F
extern unsigned char UEP0;
#pragma locate UEP0 0x0F70
extern unsigned char UEP1;
#pragma locate UEP1 0x0F71
extern unsigned char UEP2;
#pragma locate UEP2 0x0F72
extern unsigned char UEP3;
#pragma locate UEP3 0x0F73
extern unsigned char UEP4;
#pragma locate UEP4 0x0F74
extern unsigned char UEP5;
#pragma locate UEP5 0x0F75
extern unsigned char UEP6;
#pragma locate UEP6 0x0F76
extern unsigned char UEP7;
#pragma locate UEP7 0x0F77
extern unsigned char UEP8;
#pragma locate UEP8 0x0F78
extern unsigned char UEP9;
#pragma locate UEP9 0x0F79
extern unsigned char UEP10;
#pragma locate UEP10 0x0F7A
extern unsigned char UEP11;
#pragma locate UEP11 0x0F7B
extern unsigned char UEP12;
#pragma locate UEP12 0x0F7C
extern unsigned char UEP13;
#pragma locate UEP13 0x0F7D
extern unsigned char UEP14;
#pragma locate UEP14 0x0F7E
extern unsigned char UEP15;
#pragma locate UEP15 0x0F7F
extern unsigned char PORTA;
#pragma locate PORTA 0x0F80
extern unsigned char PORTB;
#pragma locate PORTB 0x0F81
extern unsigned char PORTC;
#pragma locate PORTC 0x0F82
extern unsigned char PORTD;
#pragma locate PORTD 0x0F83
extern unsigned char PORTE;
#pragma locate PORTE 0x0F84
extern unsigned char LATA;
#pragma locate LATA 0x0F89
extern unsigned char LATB;
#pragma locate LATB 0x0F8A
extern unsigned char LATC;
#pragma locate LATC 0x0F8B
extern unsigned char LATD;
#pragma locate LATD 0x0F8C
extern unsigned char LATE;
#pragma locate LATE 0x0F8D
extern unsigned char DDRA;
#pragma locate DDRA 0x0F92
extern unsigned char TRISA;
#pragma locate TRISA 0x0F92
extern unsigned char DDRB;
#pragma locate DDRB 0x0F93
extern unsigned char TRISB;
#pragma locate TRISB 0x0F93
extern unsigned char DDRC;
#pragma locate DDRC 0x0F94
extern unsigned char TRISC;
#pragma locate TRISC 0x0F94
extern unsigned char DDRD;
#pragma locate DDRD 0x0F95
extern unsigned char TRISD;
#pragma locate TRISD 0x0F95
extern unsigned char DDRE;
#pragma locate DDRE 0x0F96
extern unsigned char TRISE;
#pragma locate TRISE 0x0F96
extern unsigned char OCSTUNE;
#pragma locate OCSTUNE 0x0F9B
extern unsigned char PIE1;
#pragma locate PIE1 0x0F9D
extern unsigned char PIR1;
#pragma locate PIR1 0x0F9E
extern unsigned char IPR1;
#pragma locate IPR1 0x0F9F
extern unsigned char PIE2;
#pragma locate PIE2 0x0FA0
extern unsigned char PIR2;
#pragma locate PIR2 0x0FA1
extern unsigned char IPR2;
#pragma locate IPR2 0x0FA2
extern unsigned char EECON1;
#pragma locate EECON1 0x0FA6
extern unsigned char EECON2;
#pragma locate EECON2 0x0FA7
extern unsigned char EEDATA;
#pragma locate EEDATA 0x0FA8
extern unsigned char EEADR;
#pragma locate EEADR 0x0FA9
extern unsigned char EEADRH;
#pragma locate EEADRH 0x0FAA
extern unsigned char RCSTA;
#pragma locate RCSTA 0x0FAB
extern unsigned char TXSTA;
#pragma locate TXSTA 0x0FAC
extern unsigned char TXREG;
#pragma locate TXREG 0x0FAD
extern unsigned char RCREG;
#pragma locate RCREG 0x0FAE
extern unsigned char SPBRG;
#pragma locate SPBRG 0x0FAF
extern unsigned char SPBRGH;
#pragma locate SPBRGH 0x0FB0
extern unsigned char T3CON;
#pragma locate T3CON 0x0FB1
extern unsigned char TMR3L;
#pragma locate TMR3L 0x0FB2
extern unsigned char TMR3H;
#pragma locate TMR3H 0x0FB3
extern unsigned char CMCON;
#pragma locate CMCON 0x0FB4
extern unsigned char CVRCON;
#pragma locate CVRCON 0x0FB5
extern unsigned char ECCP1AS;
#pragma locate ECCP1AS 0x0FB6
extern unsigned char PWM1CON;
#pragma locate PWM1CON 0x0FB7
extern unsigned char BAUDCTL;
#pragma locate BAUDCTL 0x0FB8
extern unsigned char CCP2CON;
#pragma locate CCP2CON 0x0FBA
extern unsigned char CCPR2;
#pragma locate CCPR2 0x0FBB
extern unsigned char CCPR2L;
#pragma locate CCPR2L 0x0FBB
extern unsigned char CCPR2H;
#pragma locate CCPR2H 0x0FBC
extern unsigned char CCP1CON;
#pragma locate CCP1CON 0x0FBD
extern unsigned char ECCP1CON;
#pragma locate ECCP1CON 0x0FBD
extern unsigned char CCPR1;
#pragma locate CCPR1 0x0FBE
extern unsigned char CCPR1L;
#pragma locate CCPR1L 0x0FBE
extern unsigned char CCPR1H;
#pragma locate CCPR1H 0x0FBF
extern unsigned char ADCON2;
#pragma locate ADCON2 0x0FC0
extern unsigned char ADCON1;
#pragma locate ADCON1 0x0FC1
extern unsigned char ADCON0;
#pragma locate ADCON0 0x0FC2
extern unsigned char ADRES;
#pragma locate ADRES 0x0FC3
extern unsigned char ADRESL;
#pragma locate ADRESL 0x0FC3
extern unsigned char ADRESH;
#pragma locate ADRESH 0x0FC4
extern unsigned char SSPCON2;
#pragma locate SSPCON2 0x0FC5
extern unsigned char SSPCON1;
#pragma locate SSPCON1 0x0FC6
extern unsigned char SSPSTAT;
#pragma locate SSPSTAT 0x0FC7
extern unsigned char SSPADD;
#pragma locate SSPADD 0x0FC8
extern unsigned char SSPBUF;
#pragma locate SSPBUF 0x0FC9
extern unsigned char T2CON;
#pragma locate T2CON 0x0FCA
extern unsigned char PR2;
#pragma locate PR2 0x0FCB
extern unsigned char TMR2;
#pragma locate TMR2 0x0FCC
extern unsigned char T1CON;
#pragma locate T1CON 0x0FCD
extern unsigned char TMR1L;
#pragma locate TMR1L 0x0FCE
extern unsigned char TMR1H;
#pragma locate TMR1H 0x0FCF
extern unsigned char RCON;
#pragma locate RCON 0x0FD0
extern unsigned char WDTCON;
#pragma locate WDTCON 0x0FD1
extern unsigned char LVDCON;
#pragma locate LVDCON 0x0FD2
extern unsigned char OSCCON;
#pragma locate OSCCON 0x0FD3
extern unsigned char T0CON;
#pragma locate T0CON 0x0FD5
extern unsigned char TMR0L;
#pragma locate TMR0L 0x0FD6
extern unsigned char TMR0H;
#pragma locate TMR0H 0x0FD7
extern unsigned char STATUS;
#pragma locate STATUS 0x0FD8
extern unsigned char FSR2L;
#pragma locate FSR2L 0x0FD9
extern unsigned char FSR2H;
#pragma locate FSR2H 0x0FDA
extern unsigned char PLUSW2;
#pragma locate PLUSW2 0x0FDB
extern unsigned char PREINC2;
#pragma locate PREINC2 0x0FDC
extern unsigned char POSTDEC2;
#pragma locate POSTDEC2 0x0FDD
extern unsigned char POSTINC2;
#pragma locate POSTINC2 0x0FDE
extern unsigned char INDF2;
#pragma locate INDF2 0x0FDF
extern unsigned char BSR;
#pragma locate BSR 0x0FE0
extern unsigned char FSR1L;
#pragma locate FSR1L 0x0FE1
extern unsigned char FSR1H;
#pragma locate FSR1H 0x0FE2
extern unsigned char PLUSW1;
#pragma locate PLUSW1 0x0FE3
extern unsigned char PREINC1;
#pragma locate PREINC1 0x0FE4
extern unsigned char POSTDEC1;
#pragma locate POSTDEC1 0x0FE5
extern unsigned char POSTINC1;
#pragma locate POSTINC1 0x0FE6
extern unsigned char INDF1;
#pragma locate INDF1 0x0FE7
extern unsigned char WREG;
#pragma locate WREG 0x0FE8
extern unsigned char FSR0L;
#pragma locate FSR0L 0x0FE9
extern unsigned char FSR0H;
#pragma locate FSR0H 0x0FEA
extern unsigned char PLUSW0;
#pragma locate PLUSW0 0x0FEB
extern unsigned char PREINC0;
#pragma locate PREINC0 0x0FEC
extern unsigned char POSTDEC0;
#pragma locate POSTDEC0 0x0FED
extern unsigned char POSTINC0;
#pragma locate POSTINC0 0x0FEE
extern unsigned char INDF0;
#pragma locate INDF0 0x0FEF
extern unsigned char INTCON3;
#pragma locate INTCON3 0x0FF0
extern unsigned char INTCON2;
#pragma locate INTCON2 0x0FF1
extern unsigned char INTCON;
#pragma locate INTCON 0x0FF2
extern unsigned char PROD;
#pragma locate PROD 0x0FF3
extern unsigned char PRODL;
#pragma locate PRODL 0x0FF3
extern unsigned char PRODH;
#pragma locate PRODH 0x0FF4
extern unsigned char TABLAT;
#pragma locate TABLAT 0x0FF5
extern unsigned char TBLPTR;
#pragma locate TBLPTR 0x0FF6
extern unsigned char TBLPTRL;
#pragma locate TBLPTRL 0x0FF6
extern unsigned char TBLPTRH;
#pragma locate TBLPTRH 0x0FF7
extern unsigned char TBLPTRU;
#pragma locate TBLPTRU 0x0FF8
extern unsigned char PC_;
#pragma locate PC_ 0x0FF9
extern unsigned char PCL;
#pragma locate PCL 0x0FF9
extern unsigned char PCLATH;
#pragma locate PCLATH 0x0FFA
extern unsigned char PCLATU;
#pragma locate PCLATU 0x0FFB
extern unsigned char STKPTR;
#pragma locate STKPTR 0x0FFC
extern unsigned char TOS;
#pragma locate TOS 0x0FFD
extern unsigned char TOSL;
#pragma locate TOSL 0x0FFD
extern unsigned char TOSH;
#pragma locate TOSH 0x0FFE
extern unsigned char TOSU;
#pragma locate TOSU 0x0FFF
#line 330
const int WS0=0;
const int WS1=1;
const int WS2=2;
const int WS3=3;
const int CLK1EN=4;
const int CSEN=5;
const int CLKCFG0=6;
const int CLKCFG1=7;

const int ADDR0=0;
const int ADDR1=1;
const int ADDR2=2;
const int ADDR3=3;
const int BUSY=4;
const int WRSPP=6;
const int RDSPP=7;

const int SPPEN=0;
const int USBOWN=1;
#line 353
const int URSTIF=0;
const int UERRIF=1;
const int ACTVIF=2;
const int TOKIF=3;
const int IDLEIF=4;
const int STALLIF=5;
const int SOFIF=6;

const int URSTIE=0;
const int UERRIE=1;
const int ACTVIE=2;
const int TOKIE=3;
const int IDLEIE=4;
const int STALLIE=5;
const int SOFIE=6;

const int PIDEF=0;
const int CRC5EF=1;
const int CRC16EF=2;
const int DFN8EF=3;
const int BTOEF=4;
const int BTSEF=7;

const int PIDEE=0;
const int CRC5EE=1;
const int CRC16EE=2;
const int DFN8EE=3;
const int BTOEE=4;
const int BTSEE=7;

const int PPBI=1;
const int DIR=2;
const int ENDP0=3;
const int ENDP1=4;
const int ENDP2=5;
const int ENDP3=6;

const int SUSPND=1;
const int RESUME=2;
const int USBEN=3;
const int PKTDIS=4;
const int SE0=5;
const int PPBRST=6;

const int ADDR4=4;
const int ADDR5=5;
const int ADDR6=6;

const int PPB0=0;
const int PPB1=1;
const int FSEN=2;
const int UTRDIS=3;
const int USBPUEN=4;
const int UOEMON=6;
const int UTEYE=7;

const int EPSTALL=0;
const int EPINEN=1;
const int EPOUTEN=2;
const int EPCONDIS=3;
const int EPHSHK=4;
#line 430
const int RA0=0;
const int RA1=1;
const int RA2=2;
const int RA3=3;
const int RA4=4;
const int RA5=5;
const int RA6=6;
const int AN0=0;
const int AN1=1;
const int AN2=2;
const int AN3=3;
const int T0CKI=4;
const int AN4=5;
const int OSC2=6;
const int VREFM=3;
const int VREFP=4;
const int LVDIN=6;

const int RB0=0;
const int RB1=1;
const int RB2=2;
const int RB3=3;
const int RB4=4;
const int RB5=5;
const int RB6=6;
const int RB7=7;
const int INT0=0;
const int INT1=1;
const int INT2=2;
const int PGM=5;
const int PGC=6;
const int PGD=7;

const int RC0=0;
const int RC1=1;
const int RC2=2;
const int RC4=4;
const int RC5=5;
const int RC6=6;
const int RC7=7;
const int T1OSO=0;
const int T1OSI=1;
const int CCP1=2;
const int TX=6;
const int RX=7;
const int T13CKI=0;
const int P1A=2;
const int CK=6;

const int RD0=0;
const int RD1=1;
const int RD2=2;
const int RD3=3;
const int RD4=4;
const int RD5=5;
const int RD6=6;
const int RD7=7;
const int SPP0=0;
const int SPP1=1;
const int SPP2=2;
const int SPP3=3;
const int SPP4=4;
const int SPP5=5;
const int SPP6=6;
const int SPP7=7;

const int RE0=0;
const int RE1=1;
const int RE2=2;
const int RE3=3;
const int RDPU=7;
const int CK1SPP=0;
const int CK2SPP=1;
const int OESPP=2;

const int LATA0=0;
const int LATA1=1;
const int LATA2=2;
const int LATA3=3;
const int LATA4=4;
const int LATA5=5;
const int LATA6=6;

const int LATB0=0;
const int LATB1=1;
const int LATB2=2;
const int LATB3=3;
const int LATB4=4;
const int LATB5=5;
const int LATB6=6;
const int LATB7=7;

const int LATC0=0;
const int LATC1=1;
const int LATC2=2;
const int LATC6=6;
const int LATC7=7;

const int LATD0=0;
const int LATD1=1;
const int LATD2=2;
const int LATD3=3;
const int LATD4=4;
const int LATD5=5;
const int LATD6=6;
const int LATD7=7;

const int LATE0=0;
const int LATE1=1;
const int LATE2=2;
#line 542
const int TRISA0=0;
const int TRISA1=1;
const int TRISA2=2;
const int TRISA3=3;
const int TRISA4=4;
const int TRISA5=5;
const int TRISA6=6;
#line 551
const int TRISB0=0;
const int TRISB1=1;
const int TRISB2=2;
const int TRISB3=3;
const int TRISB4=4;
const int TRISB5=5;
const int TRISB6=6;
const int TRISB7=7;
#line 561
const int TRISC0=0;
const int TRISC1=1;
const int TRISC2=2;
const int TRISC6=6;
const int TRISC7=7;
#line 568
const int TRISD0=0;
const int TRISD1=1;
const int TRISD2=2;
const int TRISD3=3;
const int TRISD4=4;
const int TRISD5=5;
const int TRISD6=6;
const int TRISD7=7;
#line 578
const int TRISE0=0;
const int TRISE1=1;
const int TRISE2=2;

const int TUN0=0;
const int TUN1=1;
const int TUN2=2;
const int TUN3=4;
const int TUN4=5;
const int HF256DIV=8;

const int TMR1IE=0;
const int TMR2IE=1;
const int CCP1IE=2;
const int SSPIE=3;
const int TXIE=4;
const int RCIE=5;
const int ADIE=6;
const int SPPIE=7;

const int TMR1IF=0;
const int TMR2IF=1;
const int CCP1IF=2;
const int SSPIF=3;
const int TXIF=4;
const int RCIF=5;
const int ADIF=6;
const int SPPIF=7;

const int TMR1IP=0;
const int TMR2IP=1;
const int CCP1IP=2;
const int SSPIP=3;
const int TXBIP=4;
const int RCIP=5;
const int ADIP=6;
const int SPPIP=7;

const int CCP2IE=0;
const int TMR3IE=1;
const int LVDIE=2;
const int BCLIE=3;
const int EEIE=4;
const int USBIE=5;
const int CMIE=6;
const int OSCIE=7;

const int CCP2IF=0;
const int TMR3IF=1;
const int LVDIF=2;
const int BCLIF=3;
const int EEIF=4;
const int USBIF=5;
const int CMIF=6;
const int OSCIF=7;

const int CCP2IP=0;
const int TMR3IP=1;
const int LVDIP=2;
const int BCLIP=3;
const int EEIP=4;
const int USBIP=5;
const int CMIP=6;
const int OSCIP=7;

const int RD=0;
const int WR=1;
const int WREN=2;
const int WRERR=3;
const int FREE=4;
const int CFGS=6;
const int EEPGD=7;
#line 655
const int RX9D=0;
const int OERR=1;
const int FERR=2;
const int ADEN=3;
const int CREN=4;
const int SREN=5;
const int RX9=6;
const int SPEN=7;

const int TX9D=0;
const int TRMT=1;
const int BRGH=2;
const int SENDB=3;
const int SYNC=4;
const int TXEN=5;
const int TX9=6;
const int CSRC=7;
#line 677
const int TMR3ON=0;
const int TMR3CS=1;
const int T3SYNC=2;
const int T3CCP1=3;
const int T3CKPS0=4;
const int T3CKPS1=5;
const int T3CCP2=6;
const int RD16=7;
const int T3NSYNC=2;
const int NOT_T3SYNC=2;
#line 690
const int CM0=0;
const int CM1=1;
const int CM2=2;
const int CIS=3;
const int C1INV=4;
const int C2INV=5;
const int C1OUT=6;
const int C2OUT=7;

const int CVR0=0;
const int CVR1=1;
const int CVR2=2;
const int CVR3=3;
const int CVREF=4;
const int CVRR=5;
const int CVROE=6;
const int CVREN=7;
const int CVRSS=4;

const int PSSBD0=0;
const int PSSBD1=1;
const int PSSAC0=2;
const int PSSAC1=3;
const int ECCPAS0=4;
const int ECCPAS1=5;
const int ECCPAS2=6;
const int ECCPASE=7;

const int PDC0=0;
const int PDC1=1;
const int PDC2=2;
const int PDC3=3;
const int PDC4=4;
const int PDC5=5;
const int PDC6=6;
const int PRSEN=7;

const int ABDEN=0;
const int WUE=1;
const int BRG16=3;
const int SCKP=4;
const int RCMT=6;
const int ABDOVF=7;

const int CCP2M0=0;
const int CCP2M1=1;
const int CCP2M2=2;
const int CCP2M3=3;
const int CCP1Y=4;
const int CCP1X=5;
#line 744
const int CCP1M0=0;
const int CCP1M1=1;
const int CCP1M2=2;
const int CCP1M3=3;

const int P1M0=6;
const int P1M1=7;
#line 755
const int ADCS0=0;
const int ADCS1=1;
const int ADCS2=2;
const int ACQT0=3;
const int ACQT1=4;
const int ACQT2=5;
const int ADFM=7;

const int PCFG0=0;
const int PCFG1=1;
const int PCFG2=2;
const int PCFG3=3;
const int VCFG0=4;
const int VCFG1=5;

const int ADON=0;
const int GO_DONE=1;
const int CHS0=2;
const int CHS1=3;
const int CHS2=4;
const int CHS3=5;
const int DONE=1;
const int GO=1;
const int NOT_DONE=1;
#line 783
const int SEN=0;
const int RSEN=1;
const int PEN=2;
const int RCEN=3;
const int ACKEN=4;
const int ACKDT=5;
const int ACKSTAT=6;
const int GCEN=7;

const int SSPM0=0;
const int SSPM1=1;
const int SSPM2=2;
const int SSPM3=3;
const int CKP=4;
const int SSPEN=5;
const int SSPOV=6;
const int WCOL=7;

const int BF=0;
const int UA=1;
const int R_W=2;
const int S=3;
const int P=4;
const int D_A=5;
const int CKE=6;
const int SMP=7;
const int I2C_READ=2;
const int I2C_START=3;
const int I2C_STOP=4;
const int I2C_DAT=5;
const int NOT_W=2;
const int NOT_A=5;
const int NOT_WRITE=2;
const int NOT_ADDRESS=5;
const int READ_WRITE=2;
const int DATA_ADDRESS=5;
const int R=2;
const int D=5;
#line 824
const int T2CKPS0=0;
const int T2CKPS1=1;
const int TMR2ON=2;
const int T2OUTPS0=3;
const int T2OUTPS1=4;
const int T2OUTPS2=5;
const int T2OUTPS3=6;
#line 834
const int TMR1ON=0;
const int TMR1CS=1;
const int T1SYNC=2;
const int T1OSCEN=3;
const int T1CKPS0=4;
const int T1CKPS1=5;
const int T1RUN=6;
const int NOT_T1SYNC=2;
#line 845
const int NOT_BOR=0;
const int NOT_POR=1;
const int NOT_PD=2;
const int NOT_TO=3;
const int NOT_RI=4;
const int SBOREN=6;
const int NOT_IPEN=7;
const int BOR=0;
const int POR=1;
const int TO=3;
const int RI=4;
const int IPEN=7;

const int SWDTEN=0;
const int SWDTE=0;

const int LVDL0=0;
const int LVDL1=1;
const int LVDL2=2;
const int LVDL3=3;
const int LVDEN=4;
const int IRVST=5;
const int VDIRMAG=7;
const int LVV0=0;
const int LVV1=1;
const int LVV2=2;
const int LVV3=3;
const int BGST=5;

const int SCS0=0;
const int SCS1=1;
const int FLTS=2;
const int OSTS=3;
const int IRCF0=4;
const int IRCF1=5;
const int IRCF2=6;
const int IDLEN=7;

const int T0PS0=0;
const int T0PS1=1;
const int T0PS2=2;
const int PSA=3;
const int T0SE=4;
const int T0CS=5;
const int T08BIT=6;
const int TMR0ON=7;
#line 894
const int C=0;
const int DC=1;
const int Z=2;
const int OV=3;
const int N=4;
#line 923
const int INT1IF=0;
const int INT2IF=1;
const int INT1IE=3;
const int INT2IE=4;
const int INT1IP=6;
const int INT2IP=7;
const int INT1F=0;
const int INT2F=1;
const int INT3F=2;
const int INT1E=3;
const int INT2E=4;
const int INT3E=5;
const int INT1P=6;
const int INT2P=7;

const int RBIP=0;
const int TMR0IP=2;
const int INTEDG2=4;
const int INTEDG1=5;
const int INTEDG0=6;
const int NOT_RBPU=7;
const int T0IP=2;
const int RBPU=7;

const int RBIF=0;
const int INT0IF=1;
const int TMR0IF=2;
const int RBIE=3;
const int INT0IE=4;
const int TMR0IE=5;
const int PEIE=6;
const int GIE=7;
const int INT0F=1;
const int T0IF=2;
const int INT0E=4;
const int T0IE=5;
const int GIEL=6;
const int GIEH=7;
#line 974
const int STKPTR0=0;
const int STKPTR1=1;
const int STKPTR2=2;
const int STKPTR3=3;
const int STKPTR4=4;
const int STKUNF=6;
const int STKOVF=7;
#line 991
const int RXPORT=&PORTC;
const int TXPORT=&PORTC;
const int RXBIT=7;
const int TXBIT=6;
#line 998
const int _CONFIG1L=0x300000;
const int _CONFIG1H=0x300001;
const int _CONFIG2L=0x300002;
const int _CONFIG2H=0x300003;
const int _CONFIG3H=0x300005;
const int _CONFIG4L=0x300006;
const int _CONFIG5L=0x300008;
const int _CONFIG5H=0x300009;
const int _CONFIG6L=0x30000A;
const int _CONFIG6H=0x30000B;
const int _CONFIG7L=0x30000C;
const int _CONFIG7H=0x30000D;
const int _CLKDIV_1_1L=0x00F8;
const int _CLKDIV_2_1L=0x00F9;
const int _CLKDIV_3_1L=0x00FA;
const int _CLKDIV_4_1L=0x00FB;
const int _CLKDIV_5_1L=0x00FC;
const int _CLKDIV_6_1L=0x00FD;
const int _CLKDIV_8_1L=0x00FE;
const int _CLKDIV_10_1L=0x00FF;
const int _CPUDIV_1_1L=0x00E7;
const int _CPUDIV_2_1L=0x00EF;
const int _CPUDIV_3_1L=0x00F7;
const int _CPUDIV_4_1L=0x00FF;
const int _USBDIV_1_1L=0x00DF;
const int _USBDIV_2_1L=0x00FF;
const int _FOSC_XT_XT_1H=0x00F0;
const int _FOSC_XTPLL_XT_1H=0x00F2;
const int _FOSC_ECIO_EC_1H=0x00F4;
const int _FOSC_EC_EC_1H=0x00F5;
const int _FOSC_ECPLLIO_EC_1H=0x00F6;
const int _FOSC_ECPLL_EC_1H=0x00F7;
const int _FOSC_INTOSCIO_EC_1H=0x00F8;
const int _FOSC_INTOSC_EC_1H=0x00F9;
const int _FOSC_INTOSC_XT_1H=0x00FA;
const int _FOSC_INTOSC_HS_1H=0x00FB;
const int _FOSC_HS_1H=0x00FC;
const int _FOSC_HSPLL_HS_1H=0x00FE;
const int _FCMEM_OFF_1H=0x00BF;
const int _FCMEM_ON_1H=0x00FF;
const int _IESO_OFF_1H=0x007F;
const int _IESO_ON_1H=0x00FF;
const int _PWRT_ON_2L=0x00FE;
const int _PWRT_OFF_2L=0x00FF;
const int _BOR_OFF_2L=0x00F9;
const int _BOR_SOFT_2L=0x00FB;
const int _BOR_ON_ACTIVE_2L=0x00FD;
const int _BOR_ON_2L=0x00FF;
const int _BORV_45_2L=0x00E7;
const int _BORV_42_2L=0x00EF;
const int _BORV_27_2L=0x00F7;
const int _BORV_20_2L=0x00FF;
const int _VREGEN_OFF_2L=0x00BF;
const int _VREGEN_ON_2L=0x00FF;
const int _WDT_OFF_2H=0x00FE;
const int _WDT_ON_2H=0x00FF;
const int _WDTPS_1_2H=0x00E1;
const int _WDTPS_2_2H=0x00E3;
const int _WDTPS_4_2H=0x00E5;
const int _WDTPS_8_2H=0x00E7;
const int _WDTPS_16_2H=0x00E9;
const int _WDTPS_32_2H=0x00EB;
const int _WDTPS_64_2H=0x00ED;
const int _WDTPS_128_2H=0x00EF;
const int _WDTPS_256_2H=0x00F1;
const int _WDTPS_512_2H=0x00F3;
const int _WDTPS_1024_2H=0x00F5;
const int _WDTPS_2048_2H=0x00F7;
const int _WDTPS_4096_2H=0x00F9;
const int _WDTPS_8192_2H=0x00FB;
const int _WDTPS_16384_2H=0x00FD;
const int _WDTPS_32768_2H=0x00FF;
const int _MCLRE_OFF_3H=0x007F;
const int _MCLRE_ON_3H=0x00FF;
const int _LPT1OSC_OFF_3H=0x00FB;
const int _LPT1OSC_ON_3H=0x00FF;
const int _PBADEN_OFF_3H=0x00FD;
const int _PBADEN_ON_3H=0x00FF;
const int _CCP2MX_OFF_3H=0x00FE;
const int _CCP2MX_ON_3H=0x00FF;
const int _STVR_OFF_4L=0x00FE;
const int _STVR_ON_4L=0x00FF;
const int _LVP_OFF_4L=0x00FB;
const int _LVP_ON_4L=0x00FF;
const int _ENHCPU_OFF_4L=0x00BF;
const int _ENHCPU_ON_4L=0x00FF;
const int _DEBUG_ON_4L=0x007F;
const int _DEBUG_OFF_4L=0x00FF;
const int _CP0_ON_5L=0x00FE;
const int _CP0_OFF_5L=0x00FF;
const int _CP1_ON_5L=0x00FD;
const int _CP1_OFF_5L=0x00FF;
const int _CP2_ON_5L=0x00FB;
const int _CP2_OFF_5L=0x00FF;
const int _CP3_ON_5L=0x00F7;
const int _CP3_OFF_5L=0x00FF;
const int _CPB_ON_5H=0x00BF;
const int _CPB_OFF_5H=0x00FF;
const int _CPD_ON_5H=0x007F;
const int _CPD_OFF_5H=0x00FF;
const int _WRT0_ON_6L=0x00FE;
const int _WRT0_OFF_6L=0x00FF;
const int _WRT1_ON_6L=0x00FD;
const int _WRT1_OFF_6L=0x00FF;
const int _WRT2_ON_6L=0x00FB;
const int _WRT2_OFF_6L=0x00FF;
const int _WRT3_ON_6L=0x00F7;
const int _WRT3_OFF_6L=0x00FF;
const int _WRTB_ON_6H=0x00BF;
const int _WRTB_OFF_6H=0x00FF;
const int _WRTC_ON_6H=0x00DF;
const int _WRTC_OFF_6H=0x00FF;
const int _WRTD_ON_6H=0x007F;
const int _WRTD_OFF_6H=0x00FF;
const int _EBTR0_ON_7L=0x00FE;
const int _EBTR0_OFF_7L=0x00FF;
const int _EBTR1_ON_7L=0x00FD;
const int _EBTR1_OFF_7L=0x00FF;
const int _EBTR2_ON_7L=0x00FB;
const int _EBTR2_OFF_7L=0x00FF;
const int _EBTR3_ON_7L=0x00F7;
const int _EBTR3_OFF_7L=0x00FF;
const int _EBTRB_ON_7H=0x00BF;
const int _EBTRB_OFF_7H=0x00FF;
const int _DEVID1=0x3FFFFE;
const int _DEVID2=0x3FFFFF;
const int _IDLOC0=0x200000;
const int _IDLOC1=0x200001;
const int _IDLOC2=0x200002;
const int _IDLOC3=0x200003;
const int _IDLOC4=0x200004;
const int _IDLOC5=0x200005;
const int _IDLOC6=0x200006;
const int _IDLOC7=0x200007;
#line 1138
struct sPort
{
unsigned char B0:1;
unsigned char B1:1;
unsigned char B2:1;
unsigned char B3:1;
unsigned char B4:1;
unsigned char B5:1;
unsigned char B6:1;
unsigned char B7:1;
};
extern sPort PA;
#pragma locate PA 0x0F80
extern sPort PB;
#pragma locate PB 0x0F81
extern sPort PC;
#pragma locate PC 0x0F82
extern sPort PD;
#pragma locate PD 0x0F83
extern sPort PE;
#pragma locate PE 0x0F84
#line 9 "C:/Program Files/FED/PIXIE/Libs/PortBits.h"
extern bit bRA0,bRA1,bRA2,bRA3,bRA4,bRA5,bRA6,bRA7;
extern bit bTRA0,bTRA1,bTRA2,bTRA3,bTRA4,bTRA5,bTRA6,bTRA7;
extern bit bRB0,bRB1,bRB2,bRB3,bRB4,bRB5,bRB6,bRB7;
extern bit bTRB0,bTRB1,bTRB2,bTRB3,bTRB4,bTRB5,bTRB6,bTRB7;
extern bit bRC0,bRC1,bRC2,bRC3,bRC4,bRC5,bRC6,bRC7;
extern bit bTRC0,bTRC1,bTRC2,bTRC3,bTRC4,bTRC5,bTRC6,bTRC7;
extern bit bRD0,bRD1,bRD2,bRD3,bRD4,bRD5,bRD6,bRD7;
extern bit bTRD0,bTRD1,bTRD2,bTRD3,bTRD4,bTRD5,bTRD6,bTRD7;
extern bit bRE0,bRE1,bRE2,bRE3,bRE4,bRE5,bRE6,bRE7;
extern bit bTRE0,bTRE1,bTRE2,bTRE3,bTRE4,bTRE5,bTRE6,bTRE7;
#line 104
extern bit bRF0,bRF1,bRF2,bRF3,bRF4,bRF5,bRF6,bRF7;
extern bit bTRF0,bTRF1,bTRF2,bTRF3,bTRF4,bTRF5,bTRF6,bTRF7;
extern bit bRG0,bRG1,bRG2,bRG3,bRG4,bRG5,bRG6,bRG7;
extern bit bTRG0,bTRG1,bTRG2,bTRG3,bTRG4,bTRG5,bTRG6,bTRG7;
extern bit bRH0,bRH1,bRH2,bRH3,bRH4,bRH5,bRH6,bRH7;
extern bit bTRH0,bTRH1,bTRH2,bTRH3,bTRH4,bTRH5,bTRH6,bTRH7;

#pragma locate bRA0 0xF80,0
#pragma locate bRA1 0xF80,1
#pragma locate bRA2 0xF80,2
#pragma locate bRA3 0xF80,3
#pragma locate bRA4 0xF80,4
#pragma locate bRA5 0xF80,5
#pragma locate bRA6 0xF80,6
#pragma locate bRA7 0xF80,7
#pragma locate bRB0 0xF81,0
#pragma locate bRB1 0xF81,1
#pragma locate bRB2 0xF81,2
#pragma locate bRB3 0xF81,3
#pragma locate bRB4 0xF81,4
#pragma locate bRB5 0xF81,5
#pragma locate bRB6 0xF81,6
#pragma locate bRB7 0xF81,7
#pragma locate bRC0 0xF82,0
#pragma locate bRC1 0xF82,1
#pragma locate bRC2 0xF82,2
#pragma locate bRC3 0xF82,3
#pragma locate bRC4 0xF82,4
#pragma locate bRC5 0xF82,5
#pragma locate bRC6 0xF82,6
#pragma locate bRC7 0xF82,7
#pragma locate bRD0 0xF83,0
#pragma locate bRD1 0xF83,1
#pragma locate bRD2 0xF83,2
#pragma locate bRD3 0xF83,3
#pragma locate bRD4 0xF83,4
#pragma locate bRD5 0xF83,5
#pragma locate bRD6 0xF83,6
#pragma locate bRD7 0xF83,7
#pragma locate bRE0 0xF84,0
#pragma locate bRE1 0xF84,1
#pragma locate bRE2 0xF84,2
#pragma locate bRE3 0xF84,3
#pragma locate bRE4 0xF84,4
#pragma locate bRE5 0xF84,5
#pragma locate bRE6 0xF84,6
#pragma locate bRE7 0xF84,7
#pragma locate bRF0 0xF85,0
#pragma locate bRF1 0xF85,1
#pragma locate bRF2 0xF85,2
#pragma locate bRF3 0xF85,3
#pragma locate bRF4 0xF85,4
#pragma locate bRF5 0xF85,5
#pragma locate bRF6 0xF85,6
#pragma locate bRF7 0xF85,7
#pragma locate bRG0 0xF86,0
#pragma locate bRG1 0xF86,1
#pragma locate bRG2 0xF86,2
#pragma locate bRG3 0xF86,3
#pragma locate bRG4 0xF86,4
#pragma locate bRG5 0xF86,5
#pragma locate bRG6 0xF86,6
#pragma locate bRG7 0xF86,7
#pragma locate bRH0 0xF87,0
#pragma locate bRH1 0xF87,1
#pragma locate bRH2 0xF87,2
#pragma locate bRH3 0xF87,3
#pragma locate bRH4 0xF87,4
#pragma locate bRH5 0xF87,5
#pragma locate bRH6 0xF87,6
#pragma locate bRH7 0xF87,7
#pragma locate bTRA0 0xF92,0
#pragma locate bTRA1 0xF92,1
#pragma locate bTRA2 0xF92,2
#pragma locate bTRA3 0xF92,3
#pragma locate bTRA4 0xF92,4
#pragma locate bTRA5 0xF92,5
#pragma locate bTRA6 0xF92,6
#pragma locate bTRA7 0xF92,7
#pragma locate bTRB0 0xF93,0
#pragma locate bTRB1 0xF93,1
#pragma locate bTRB2 0xF93,2
#pragma locate bTRB3 0xF93,3
#pragma locate bTRB4 0xF93,4
#pragma locate bTRB5 0xF93,5
#pragma locate bTRB6 0xF93,6
#pragma locate bTRB7 0xF93,7
#pragma locate bTRC0 0xF94,0
#pragma locate bTRC1 0xF94,1
#pragma locate bTRC2 0xF94,2
#pragma locate bTRC3 0xF94,3
#pragma locate bTRC4 0xF94,4
#pragma locate bTRC5 0xF94,5
#pragma locate bTRC6 0xF94,6
#pragma locate bTRC7 0xF94,7
#pragma locate bTRD0 0xF95,0
#pragma locate bTRD1 0xF95,1
#pragma locate bTRD2 0xF95,2
#pragma locate bTRD3 0xF95,3
#pragma locate bTRD4 0xF95,4
#pragma locate bTRD5 0xF95,5
#pragma locate bTRD6 0xF95,6
#pragma locate bTRD7 0xF95,7
#pragma locate bTRE0 0xF96,0
#pragma locate bTRE1 0xF96,1
#pragma locate bTRE2 0xF96,2
#pragma locate bTRE3 0xF96,3
#pragma locate bTRE4 0xF96,4
#pragma locate bTRE5 0xF96,5
#pragma locate bTRE6 0xF96,6
#pragma locate bTRE7 0xF96,7
#pragma locate bTRF0 0xF97,0
#pragma locate bTRF1 0xF97,1
#pragma locate bTRF2 0xF97,2
#pragma locate bTRF3 0xF97,3
#pragma locate bTRF4 0xF97,4
#pragma locate bTRF5 0xF97,5
#pragma locate bTRF6 0xF97,6
#pragma locate bTRF7 0xF97,7
#pragma locate bTRG0 0xF98,0
#pragma locate bTRG1 0xF98,1
#pragma locate bTRG2 0xF98,2
#pragma locate bTRG3 0xF98,3
#pragma locate bTRG4 0xF98,4
#pragma locate bTRG5 0xF98,5
#pragma locate bTRG6 0xF98,6
#pragma locate bTRG7 0xF98,7
#pragma locate bTRH0 0xF99,0
#pragma locate bTRH1 0xF99,1
#pragma locate bTRH2 0xF99,2
#pragma locate bTRH3 0xF99,3
#pragma locate bTRH4 0xF99,4
#pragma locate bTRH5 0xF99,5
#pragma locate bTRH6 0xF99,6
#pragma locate bTRH7 0xF99,7
#line 6 "C:/Program Files/FED/PIXIE/Libs/ProcIncs/P18F4550_bits.h"
extern bit bWS0;
#pragma locate bWS0 &SPPCFG,0x00
extern bit bWS1;
#pragma locate bWS1 &SPPCFG,0x01
extern bit bWS2;
#pragma locate bWS2 &SPPCFG,0x02
extern bit bWS3;
#pragma locate bWS3 &SPPCFG,0x03
extern bit bCLK1EN;
#pragma locate bCLK1EN &SPPCFG,0x04
extern bit bCSEN;
#pragma locate bCSEN &SPPCFG,0x05
extern bit bCLKCFG0;
#pragma locate bCLKCFG0 &SPPCFG,0x06
extern bit bCLKCFG1;
#pragma locate bCLKCFG1 &SPPCFG,0x07

extern bit bADDR0;
#pragma locate bADDR0 &SPPEPS,0x00
extern bit bADDR1;
#pragma locate bADDR1 &SPPEPS,0x01
extern bit bADDR2;
#pragma locate bADDR2 &SPPEPS,0x02
extern bit bADDR3;
#pragma locate bADDR3 &SPPEPS,0x03
extern bit bBUSY;
#pragma locate bBUSY &SPPEPS,0x04
extern bit bWRSPP;
#pragma locate bWRSPP &SPPEPS,0x06
extern bit bRDSPP;
#pragma locate bRDSPP &SPPEPS,0x07

extern bit bSPPEN;
#pragma locate bSPPEN &SPPCON,0x00
extern bit bUSBOWN;
#pragma locate bUSBOWN &SPPCON,0x01
#line 46
extern bit bURSTIF;
#pragma locate bURSTIF &UIR,0x00
extern bit bUERRIF;
#pragma locate bUERRIF &UIR,0x01
extern bit bACTVIF;
#pragma locate bACTVIF &UIR,0x02
extern bit bTOKIF;
#pragma locate bTOKIF &UIR,0x03
extern bit bTRNIF;
#pragma locate bTRNIF &UIR,0x03
extern bit bIDLEIF;
#pragma locate bIDLEIF &UIR,0x04
extern bit bSTALLIF;
#pragma locate bSTALLIF &UIR,0x05
extern bit bSOFIF;
#pragma locate bSOFIF &UIR,0x06

extern bit bURSTIE;
#pragma locate bURSTIE &UIE,0x00
extern bit bUERRIE;
#pragma locate bUERRIE &UIE,0x01
extern bit bACTVIE;
#pragma locate bACTVIE &UIE,0x02
extern bit bTOKIE;
#pragma locate bTOKIE &UIE,0x03
extern bit bTRNIE;
#pragma locate bTRNIE &UIE,0x03
extern bit bIDLEIE;
#pragma locate bIDLEIE &UIE,0x04
extern bit bSTALLIE;
#pragma locate bSTALLIE &UIE,0x05
extern bit bSOFIE;
#pragma locate bSOFIE &UIE,0x06

extern bit bPIDEF;
#pragma locate bPIDEF &UEIR,0x00
extern bit bCRC5EF;
#pragma locate bCRC5EF &UEIR,0x01
extern bit bCRC16EF;
#pragma locate bCRC16EF &UEIR,0x02
extern bit bDFN8EF;
#pragma locate bDFN8EF &UEIR,0x03
extern bit bBTOEF;
#pragma locate bBTOEF &UEIR,0x04
extern bit bBTSEF;
#pragma locate bBTSEF &UEIR,0x07

extern bit bPIDEE;
#pragma locate bPIDEE &UEIE,0x00
extern bit bCRC5EE;
#pragma locate bCRC5EE &UEIE,0x01
extern bit bCRC16EE;
#pragma locate bCRC16EE &UEIE,0x02
extern bit bDFN8EE;
#pragma locate bDFN8EE &UEIE,0x03
extern bit bBTOEE;
#pragma locate bBTOEE &UEIE,0x04
extern bit bBTSEE;
#pragma locate bBTSEE &UEIE,0x07

extern bit bPPBI;
#pragma locate bPPBI &USTAT,0x01
extern bit bDIR;
#pragma locate bDIR &USTAT,0x02
extern bit bENDP0;
#pragma locate bENDP0 &USTAT,0x03
extern bit bENDP1;
#pragma locate bENDP1 &USTAT,0x04
extern bit bENDP2;
#pragma locate bENDP2 &USTAT,0x05
extern bit bENDP3;
#pragma locate bENDP3 &USTAT,0x06

extern bit bSUSPND;
#pragma locate bSUSPND &UCON,0x01
extern bit bRESUME;
#pragma locate bRESUME &UCON,0x02
extern bit bUSBEN;
#pragma locate bUSBEN &UCON,0x03
extern bit bPKTDIS;
#pragma locate bPKTDIS &UCON,0x04
extern bit bSE0;
#pragma locate bSE0 &UCON,0x05
extern bit bPPBRST;
#pragma locate bPPBRST &UCON,0x06

extern bit bADDR4;
#pragma locate bADDR4 &UADDR,0x04
extern bit bADDR5;
#pragma locate bADDR5 &UADDR,0x05
extern bit bADDR6;
#pragma locate bADDR6 &UADDR,0x06

extern bit bPPB0;
#pragma locate bPPB0 &UCFG,0x00
extern bit bPPB1;
#pragma locate bPPB1 &UCFG,0x01
extern bit bFSEN;
#pragma locate bFSEN &UCFG,0x02
extern bit bUTRDIS;
#pragma locate bUTRDIS &UCFG,0x03
extern bit bUSBPUEN;
#pragma locate bUSBPUEN &UCFG,0x04
extern bit bUOEMON;
#pragma locate bUOEMON &UCFG,0x06
extern bit bUTEYE;
#pragma locate bUTEYE &UCFG,0x07

extern bit bEPSTALL;
#pragma locate bEPSTALL &UEP0,0x00
extern bit bEPINEN;
#pragma locate bEPINEN &UEP0,0x01
extern bit bEPOUTEN;
#pragma locate bEPOUTEN &UEP0,0x02
extern bit bEPCONDIS;
#pragma locate bEPCONDIS &UEP0,0x03
extern bit bEPHSHK;
#pragma locate bEPHSHK &UEP0,0x04

extern bit bEPSTALL0;
#pragma locate bEPSTALL0 &UEP0,0x00
extern bit bEPINEN0;
#pragma locate bEPINEN0 &UEP0,0x01
extern bit bEPOUTEN0;
#pragma locate bEPOUTEN0 &UEP0,0x02
extern bit bEPCONDIS0;
#pragma locate bEPCONDIS0 &UEP0,0x03
extern bit bEPHSHK0;
#pragma locate bEPHSHK0 &UEP0,0x04

extern bit bEPSTALL1;
#pragma locate bEPSTALL1 &UEP1,0x00
extern bit bEPINEN1;
#pragma locate bEPINEN1 &UEP1,0x01
extern bit bEPOUTEN1;
#pragma locate bEPOUTEN1 &UEP1,0x02
extern bit bEPCONDIS1;
#pragma locate bEPCONDIS1 &UEP1,0x03
extern bit bEPHSHK1;
#pragma locate bEPHSHK1 &UEP1,0x04

extern bit bEPSTALL2;
#pragma locate bEPSTALL2 &UEP2,0x00
extern bit bEPINEN2;
#pragma locate bEPINEN2 &UEP2,0x01
extern bit bEPOUTEN2;
#pragma locate bEPOUTEN2 &UEP2,0x02
extern bit bEPCONDIS2;
#pragma locate bEPCONDIS2 &UEP2,0x03
extern bit bEPHSHK2;
#pragma locate bEPHSHK2 &UEP2,0x04

extern bit bEPSTALL3;
#pragma locate bEPSTALL3 &UEP3,0x00
extern bit bEPINEN3;
#pragma locate bEPINEN3 &UEP3,0x01
extern bit bEPOUTEN3;
#pragma locate bEPOUTEN3 &UEP3,0x02
extern bit bEPCONDIS3;
#pragma locate bEPCONDIS3 &UEP3,0x03
extern bit bEPHSHK3;
#pragma locate bEPHSHK3 &UEP3,0x04

extern bit bEPSTALL4;
#pragma locate bEPSTALL4 &UEP4,0x00
extern bit bEPINEN4;
#pragma locate bEPINEN4 &UEP4,0x01
extern bit bEPOUTEN4;
#pragma locate bEPOUTEN4 &UEP4,0x02
extern bit bEPCONDIS4;
#pragma locate bEPCONDIS4 &UEP4,0x03
extern bit bEPHSHK4;
#pragma locate bEPHSHK4 &UEP4,0x04

extern bit bEPSTALL5;
#pragma locate bEPSTALL5 &UEP5,0x00
extern bit bEPINEN5;
#pragma locate bEPINEN5 &UEP5,0x01
extern bit bEPOUTEN5;
#pragma locate bEPOUTEN5 &UEP5,0x02
extern bit bEPCONDIS5;
#pragma locate bEPCONDIS5 &UEP5,0x03
extern bit bEPHSHK5;
#pragma locate bEPHSHK5 &UEP5,0x04

extern bit bEPSTALL6;
#pragma locate bEPSTALL6 &UEP6,0x00
extern bit bEPINEN6;
#pragma locate bEPINEN6 &UEP6,0x01
extern bit bEPOUTEN6;
#pragma locate bEPOUTEN6 &UEP6,0x02
extern bit bEPCONDIS6;
#pragma locate bEPCONDIS6 &UEP6,0x03
extern bit bEPHSHK6;
#pragma locate bEPHSHK6 &UEP6,0x04

extern bit bEPSTALL7;
#pragma locate bEPSTALL7 &UEP7,0x00
extern bit bEPINEN7;
#pragma locate bEPINEN7 &UEP7,0x01
extern bit bEPOUTEN7;
#pragma locate bEPOUTEN7 &UEP7,0x02
extern bit bEPCONDIS7;
#pragma locate bEPCONDIS7 &UEP7,0x03
extern bit bEPHSHK7;
#pragma locate bEPHSHK7 &UEP7,0x04

extern bit bEPSTALL8;
#pragma locate bEPSTALL8 &UEP8,0x00
extern bit bEPINEN8;
#pragma locate bEPINEN8 &UEP8,0x01
extern bit bEPOUTEN8;
#pragma locate bEPOUTEN8 &UEP8,0x02
extern bit bEPCONDIS8;
#pragma locate bEPCONDIS8 &UEP8,0x03
extern bit bEPHSHK8;
#pragma locate bEPHSHK8 &UEP8,0x04

extern bit bEPSTALL9;
#pragma locate bEPSTALL9 &UEP9,0x00
extern bit bEPINEN9;
#pragma locate bEPINEN9 &UEP9,0x01
extern bit bEPOUTEN9;
#pragma locate bEPOUTEN9 &UEP9,0x02
extern bit bEPCONDIS9;
#pragma locate bEPCONDIS9 &UEP9,0x03
extern bit bEPHSHK9;
#pragma locate bEPHSHK9 &UEP9,0x04

extern bit bEPSTALL10;
#pragma locate bEPSTALL10 &UEP10,0x00
extern bit bEPINEN10;
#pragma locate bEPINEN10 &UEP10,0x01
extern bit bEPOUTEN10;
#pragma locate bEPOUTEN10 &UEP10,0x02
extern bit bEPCONDIS10;
#pragma locate bEPCONDIS10 &UEP10,0x03
extern bit bEPHSHK10;
#pragma locate bEPHSHK10 &UEP10,0x04

extern bit bEPSTALL11;
#pragma locate bEPSTALL11 &UEP11,0x00
extern bit bEPINEN11;
#pragma locate bEPINEN11 &UEP11,0x01
extern bit bEPOUTEN11;
#pragma locate bEPOUTEN11 &UEP11,0x02
extern bit bEPCONDIS11;
#pragma locate bEPCONDIS11 &UEP11,0x03
extern bit bEPHSHK11;
#pragma locate bEPHSHK11 &UEP11,0x04

extern bit bEPSTALL12;
#pragma locate bEPSTALL12 &UEP12,0x00
extern bit bEPINEN12;
#pragma locate bEPINEN12 &UEP12,0x01
extern bit bEPOUTEN12;
#pragma locate bEPOUTEN12 &UEP12,0x02
extern bit bEPCONDIS12;
#pragma locate bEPCONDIS12 &UEP12,0x03
extern bit bEPHSHK12;
#pragma locate bEPHSHK12 &UEP12,0x04

extern bit bEPSTALL13;
#pragma locate bEPSTALL13 &UEP13,0x00
extern bit bEPINEN13;
#pragma locate bEPINEN13 &UEP13,0x01
extern bit bEPOUTEN13;
#pragma locate bEPOUTEN13 &UEP13,0x02
extern bit bEPCONDIS13;
#pragma locate bEPCONDIS13 &UEP13,0x03
extern bit bEPHSHK13;
#pragma locate bEPHSHK13 &UEP13,0x04

extern bit bEPSTALL14;
#pragma locate bEPSTALL14 &UEP14,0x00
extern bit bEPINEN14;
#pragma locate bEPINEN14 &UEP14,0x01
extern bit bEPOUTEN14;
#pragma locate bEPOUTEN14 &UEP14,0x02
extern bit bEPCONDIS14;
#pragma locate bEPCONDIS14 &UEP14,0x03
extern bit bEPHSHK14;
#pragma locate bEPHSHK14 &UEP14,0x04

extern bit bEPSTALL15;
#pragma locate bEPSTALL15 &UEP15,0x00
extern bit bEPINEN15;
#pragma locate bEPINEN15 &UEP15,0x01
extern bit bEPOUTEN15;
#pragma locate bEPOUTEN15 &UEP15,0x02
extern bit bEPCONDIS15;
#pragma locate bEPCONDIS15 &UEP15,0x03
extern bit bEPHSHK15;
#pragma locate bEPHSHK15 &UEP15,0x04
#line 342
extern bit bRA0;
#pragma locate bRA0 &PORTA,0x00
extern bit bRA1;
#pragma locate bRA1 &PORTA,0x01
extern bit bRA2;
#pragma locate bRA2 &PORTA,0x02
extern bit bRA3;
#pragma locate bRA3 &PORTA,0x03
extern bit bRA4;
#pragma locate bRA4 &PORTA,0x04
extern bit bRA5;
#pragma locate bRA5 &PORTA,0x05
extern bit bRA6;
#pragma locate bRA6 &PORTA,0x06
extern bit bAN0;
#pragma locate bAN0 &PORTA,0x00
extern bit bAN1;
#pragma locate bAN1 &PORTA,0x01
extern bit bAN2;
#pragma locate bAN2 &PORTA,0x02
extern bit bAN3;
#pragma locate bAN3 &PORTA,0x03
extern bit bT0CKI;
#pragma locate bT0CKI &PORTA,0x04
extern bit bAN4;
#pragma locate bAN4 &PORTA,0x05
extern bit bOSC2;
#pragma locate bOSC2 &PORTA,0x06
extern bit bVREFM;
#pragma locate bVREFM &PORTA,0x03
extern bit bVREFP;
#pragma locate bVREFP &PORTA,0x04
extern bit bLVDIN;
#pragma locate bLVDIN &PORTA,0x06

extern bit bRB0;
#pragma locate bRB0 &PORTB,0x00
extern bit bRB1;
#pragma locate bRB1 &PORTB,0x01
extern bit bRB2;
#pragma locate bRB2 &PORTB,0x02
extern bit bRB3;
#pragma locate bRB3 &PORTB,0x03
extern bit bRB4;
#pragma locate bRB4 &PORTB,0x04
extern bit bRB5;
#pragma locate bRB5 &PORTB,0x05
extern bit bRB6;
#pragma locate bRB6 &PORTB,0x06
extern bit bRB7;
#pragma locate bRB7 &PORTB,0x07
extern bit bINT0;
#pragma locate bINT0 &PORTB,0x00
extern bit bINT1;
#pragma locate bINT1 &PORTB,0x01
extern bit bINT2;
#pragma locate bINT2 &PORTB,0x02
extern bit bPGM;
#pragma locate bPGM &PORTB,0x05
extern bit bPGC;
#pragma locate bPGC &PORTB,0x06
extern bit bPGD;
#pragma locate bPGD &PORTB,0x07

extern bit bRC0;
#pragma locate bRC0 &PORTC,0x00
extern bit bRC1;
#pragma locate bRC1 &PORTC,0x01
extern bit bRC2;
#pragma locate bRC2 &PORTC,0x02
extern bit bRC4;
#pragma locate bRC4 &PORTC,0x04
extern bit bRC5;
#pragma locate bRC5 &PORTC,0x05
extern bit bRC6;
#pragma locate bRC6 &PORTC,0x06
extern bit bRC7;
#pragma locate bRC7 &PORTC,0x07
extern bit bT1OSO;
#pragma locate bT1OSO &PORTC,0x00
extern bit bT1OSI;
#pragma locate bT1OSI &PORTC,0x01
extern bit bCCP1;
#pragma locate bCCP1 &PORTC,0x02
extern bit bTX;
#pragma locate bTX &PORTC,0x06
extern bit bRX;
#pragma locate bRX &PORTC,0x07
extern bit bT13CKI;
#pragma locate bT13CKI &PORTC,0x00
extern bit bP1A;
#pragma locate bP1A &PORTC,0x02
extern bit bCK;
#pragma locate bCK &PORTC,0x06

extern bit bRD0;
#pragma locate bRD0 &PORTD,0x00
extern bit bRD1;
#pragma locate bRD1 &PORTD,0x01
extern bit bRD2;
#pragma locate bRD2 &PORTD,0x02
extern bit bRD3;
#pragma locate bRD3 &PORTD,0x03
extern bit bRD4;
#pragma locate bRD4 &PORTD,0x04
extern bit bRD5;
#pragma locate bRD5 &PORTD,0x05
extern bit bRD6;
#pragma locate bRD6 &PORTD,0x06
extern bit bRD7;
#pragma locate bRD7 &PORTD,0x07
extern bit bSPP0;
#pragma locate bSPP0 &PORTD,0x00
extern bit bSPP1;
#pragma locate bSPP1 &PORTD,0x01
extern bit bSPP2;
#pragma locate bSPP2 &PORTD,0x02
extern bit bSPP3;
#pragma locate bSPP3 &PORTD,0x03
extern bit bSPP4;
#pragma locate bSPP4 &PORTD,0x04
extern bit bSPP5;
#pragma locate bSPP5 &PORTD,0x05
extern bit bSPP6;
#pragma locate bSPP6 &PORTD,0x06
extern bit bSPP7;
#pragma locate bSPP7 &PORTD,0x07

extern bit bRE0;
#pragma locate bRE0 &PORTE,0x00
extern bit bRE1;
#pragma locate bRE1 &PORTE,0x01
extern bit bRE2;
#pragma locate bRE2 &PORTE,0x02
extern bit bRE3;
#pragma locate bRE3 &PORTE,0x03
extern bit bRDPU;
#pragma locate bRDPU &PORTE,0x07
extern bit bCK1SPP;
#pragma locate bCK1SPP &PORTE,0x00
extern bit bCK2SPP;
#pragma locate bCK2SPP &PORTE,0x01
extern bit bOESPP;
#pragma locate bOESPP &PORTE,0x02

extern bit bLATA0;
#pragma locate bLATA0 &LATA,0x00
extern bit bLATA1;
#pragma locate bLATA1 &LATA,0x01
extern bit bLATA2;
#pragma locate bLATA2 &LATA,0x02
extern bit bLATA3;
#pragma locate bLATA3 &LATA,0x03
extern bit bLATA4;
#pragma locate bLATA4 &LATA,0x04
extern bit bLATA5;
#pragma locate bLATA5 &LATA,0x05
extern bit bLATA6;
#pragma locate bLATA6 &LATA,0x06

extern bit bLATB0;
#pragma locate bLATB0 &LATB,0x00
extern bit bLATB1;
#pragma locate bLATB1 &LATB,0x01
extern bit bLATB2;
#pragma locate bLATB2 &LATB,0x02
extern bit bLATB3;
#pragma locate bLATB3 &LATB,0x03
extern bit bLATB4;
#pragma locate bLATB4 &LATB,0x04
extern bit bLATB5;
#pragma locate bLATB5 &LATB,0x05
extern bit bLATB6;
#pragma locate bLATB6 &LATB,0x06
extern bit bLATB7;
#pragma locate bLATB7 &LATB,0x07

extern bit bLATC0;
#pragma locate bLATC0 &LATC,0x00
extern bit bLATC1;
#pragma locate bLATC1 &LATC,0x01
extern bit bLATC2;
#pragma locate bLATC2 &LATC,0x02
extern bit bLATC6;
#pragma locate bLATC6 &LATC,0x06
extern bit bLATC7;
#pragma locate bLATC7 &LATC,0x07

extern bit bLATD0;
#pragma locate bLATD0 &LATD,0x00
extern bit bLATD1;
#pragma locate bLATD1 &LATD,0x01
extern bit bLATD2;
#pragma locate bLATD2 &LATD,0x02
extern bit bLATD3;
#pragma locate bLATD3 &LATD,0x03
extern bit bLATD4;
#pragma locate bLATD4 &LATD,0x04
extern bit bLATD5;
#pragma locate bLATD5 &LATD,0x05
extern bit bLATD6;
#pragma locate bLATD6 &LATD,0x06
extern bit bLATD7;
#pragma locate bLATD7 &LATD,0x07

extern bit bLATE0;
#pragma locate bLATE0 &LATE,0x00
extern bit bLATE1;
#pragma locate bLATE1 &LATE,0x01
extern bit bLATE2;
#pragma locate bLATE2 &LATE,0x02
#line 555
extern bit bTRISA0;
#pragma locate bTRISA0 &TRISA,0x00
extern bit bTRISA1;
#pragma locate bTRISA1 &TRISA,0x01
extern bit bTRISA2;
#pragma locate bTRISA2 &TRISA,0x02
extern bit bTRISA3;
#pragma locate bTRISA3 &TRISA,0x03
extern bit bTRISA4;
#pragma locate bTRISA4 &TRISA,0x04
extern bit bTRISA5;
#pragma locate bTRISA5 &TRISA,0x05
extern bit bTRISA6;
#pragma locate bTRISA6 &TRISA,0x06
#line 571
extern bit bTRISB0;
#pragma locate bTRISB0 &TRISB,0x00
extern bit bTRISB1;
#pragma locate bTRISB1 &TRISB,0x01
extern bit bTRISB2;
#pragma locate bTRISB2 &TRISB,0x02
extern bit bTRISB3;
#pragma locate bTRISB3 &TRISB,0x03
extern bit bTRISB4;
#pragma locate bTRISB4 &TRISB,0x04
extern bit bTRISB5;
#pragma locate bTRISB5 &TRISB,0x05
extern bit bTRISB6;
#pragma locate bTRISB6 &TRISB,0x06
extern bit bTRISB7;
#pragma locate bTRISB7 &TRISB,0x07
#line 589
extern bit bTRISC0;
#pragma locate bTRISC0 &TRISC,0x00
extern bit bTRISC1;
#pragma locate bTRISC1 &TRISC,0x01
extern bit bTRISC2;
#pragma locate bTRISC2 &TRISC,0x02
extern bit bTRISC6;
#pragma locate bTRISC6 &TRISC,0x06
extern bit bTRISC7;
#pragma locate bTRISC7 &TRISC,0x07
#line 601
extern bit bTRISD0;
#pragma locate bTRISD0 &TRISD,0x00
extern bit bTRISD1;
#pragma locate bTRISD1 &TRISD,0x01
extern bit bTRISD2;
#pragma locate bTRISD2 &TRISD,0x02
extern bit bTRISD3;
#pragma locate bTRISD3 &TRISD,0x03
extern bit bTRISD4;
#pragma locate bTRISD4 &TRISD,0x04
extern bit bTRISD5;
#pragma locate bTRISD5 &TRISD,0x05
extern bit bTRISD6;
#pragma locate bTRISD6 &TRISD,0x06
extern bit bTRISD7;
#pragma locate bTRISD7 &TRISD,0x07
#line 619
extern bit bTRISE0;
#pragma locate bTRISE0 &TRISE,0x00
extern bit bTRISE1;
#pragma locate bTRISE1 &TRISE,0x01
extern bit bTRISE2;
#pragma locate bTRISE2 &TRISE,0x02

extern bit bTUN0;
#pragma locate bTUN0 &OCSTUNE,0x00
extern bit bTUN1;
#pragma locate bTUN1 &OCSTUNE,0x01
extern bit bTUN2;
#pragma locate bTUN2 &OCSTUNE,0x02
extern bit bTUN3;
#pragma locate bTUN3 &OCSTUNE,0x04
extern bit bTUN4;
#pragma locate bTUN4 &OCSTUNE,0x05
extern bit bHF256DIV;
#pragma locate bHF256DIV &OCSTUNE,0x08

extern bit bTMR1IE;
#pragma locate bTMR1IE &PIE1,0x00
extern bit bTMR2IE;
#pragma locate bTMR2IE &PIE1,0x01
extern bit bCCP1IE;
#pragma locate bCCP1IE &PIE1,0x02
extern bit bSSPIE;
#pragma locate bSSPIE &PIE1,0x03
extern bit bTXIE;
#pragma locate bTXIE &PIE1,0x04
extern bit bRCIE;
#pragma locate bRCIE &PIE1,0x05
extern bit bADIE;
#pragma locate bADIE &PIE1,0x06
extern bit bSPPIE;
#pragma locate bSPPIE &PIE1,0x07

extern bit bTMR1IF;
#pragma locate bTMR1IF &PIR1,0x00
extern bit bTMR2IF;
#pragma locate bTMR2IF &PIR1,0x01
extern bit bCCP1IF;
#pragma locate bCCP1IF &PIR1,0x02
extern bit bSSPIF;
#pragma locate bSSPIF &PIR1,0x03
extern bit bTXIF;
#pragma locate bTXIF &PIR1,0x04
extern bit bRCIF;
#pragma locate bRCIF &PIR1,0x05
extern bit bADIF;
#pragma locate bADIF &PIR1,0x06
extern bit bSPPIF;
#pragma locate bSPPIF &PIR1,0x07

extern bit bTMR1IP;
#pragma locate bTMR1IP &IPR1,0x00
extern bit bTMR2IP;
#pragma locate bTMR2IP &IPR1,0x01
extern bit bCCP1IP;
#pragma locate bCCP1IP &IPR1,0x02
extern bit bSSPIP;
#pragma locate bSSPIP &IPR1,0x03
extern bit bTXBIP;
#pragma locate bTXBIP &IPR1,0x04
extern bit bRCIP;
#pragma locate bRCIP &IPR1,0x05
extern bit bADIP;
#pragma locate bADIP &IPR1,0x06
extern bit bSPPIP;
#pragma locate bSPPIP &IPR1,0x07

extern bit bCCP2IE;
#pragma locate bCCP2IE &PIE2,0x00
extern bit bTMR3IE;
#pragma locate bTMR3IE &PIE2,0x01
extern bit bLVDIE;
#pragma locate bLVDIE &PIE2,0x02
extern bit bBCLIE;
#pragma locate bBCLIE &PIE2,0x03
extern bit bEEIE;
#pragma locate bEEIE &PIE2,0x04
extern bit bUSBIE;
#pragma locate bUSBIE &PIE2,0x05
extern bit bCMIE;
#pragma locate bCMIE &PIE2,0x06
extern bit bOSCIE;
#pragma locate bOSCIE &PIE2,0x07

extern bit bCCP2IF;
#pragma locate bCCP2IF &PIR2,0x00
extern bit bTMR3IF;
#pragma locate bTMR3IF &PIR2,0x01
extern bit bLVDIF;
#pragma locate bLVDIF &PIR2,0x02
extern bit bBCLIF;
#pragma locate bBCLIF &PIR2,0x03
extern bit bEEIF;
#pragma locate bEEIF &PIR2,0x04
extern bit bUSBIF;
#pragma locate bUSBIF &PIR2,0x05
extern bit bCMIF;
#pragma locate bCMIF &PIR2,0x06
extern bit bOSCIF;
#pragma locate bOSCIF &PIR2,0x07

extern bit bCCP2IP;
#pragma locate bCCP2IP &IPR2,0x00
extern bit bTMR3IP;
#pragma locate bTMR3IP &IPR2,0x01
extern bit bLVDIP;
#pragma locate bLVDIP &IPR2,0x02
extern bit bBCLIP;
#pragma locate bBCLIP &IPR2,0x03
extern bit bEEIP;
#pragma locate bEEIP &IPR2,0x04
extern bit bUSBIP;
#pragma locate bUSBIP &IPR2,0x05
extern bit bCMIP;
#pragma locate bCMIP &IPR2,0x06
extern bit bOSCIP;
#pragma locate bOSCIP &IPR2,0x07

extern bit bRD;
#pragma locate bRD &EECON1,0x00
extern bit bWR;
#pragma locate bWR &EECON1,0x01
extern bit bWREN;
#pragma locate bWREN &EECON1,0x02
extern bit bWRERR;
#pragma locate bWRERR &EECON1,0x03
extern bit bFREE;
#pragma locate bFREE &EECON1,0x04
extern bit bCFGS;
#pragma locate bCFGS &EECON1,0x06
extern bit bEEPGD;
#pragma locate bEEPGD &EECON1,0x07
#line 760
extern bit bRX9D;
#pragma locate bRX9D &RCSTA,0x00
extern bit bOERR;
#pragma locate bOERR &RCSTA,0x01
extern bit bFERR;
#pragma locate bFERR &RCSTA,0x02
extern bit bADEN;
#pragma locate bADEN &RCSTA,0x03
extern bit bCREN;
#pragma locate bCREN &RCSTA,0x04
extern bit bSREN;
#pragma locate bSREN &RCSTA,0x05
extern bit bRX9;
#pragma locate bRX9 &RCSTA,0x06
extern bit bSPEN;
#pragma locate bSPEN &RCSTA,0x07

extern bit bTX9D;
#pragma locate bTX9D &TXSTA,0x00
extern bit bTRMT;
#pragma locate bTRMT &TXSTA,0x01
extern bit bBRGH;
#pragma locate bBRGH &TXSTA,0x02
extern bit bSENDB;
#pragma locate bSENDB &TXSTA,0x03
extern bit bSYNC;
#pragma locate bSYNC &TXSTA,0x04
extern bit bTXEN;
#pragma locate bTXEN &TXSTA,0x05
extern bit bTX9;
#pragma locate bTX9 &TXSTA,0x06
extern bit bCSRC;
#pragma locate bCSRC &TXSTA,0x07
#line 798
extern bit bTMR3ON;
#pragma locate bTMR3ON &T3CON,0x00
extern bit bTMR3CS;
#pragma locate bTMR3CS &T3CON,0x01
extern bit bT3SYNC;
#pragma locate bT3SYNC &T3CON,0x02
extern bit bT3CCP1;
#pragma locate bT3CCP1 &T3CON,0x03
extern bit bT3CKPS0;
#pragma locate bT3CKPS0 &T3CON,0x04
extern bit bT3CKPS1;
#pragma locate bT3CKPS1 &T3CON,0x05
extern bit bT3CCP2;
#pragma locate bT3CCP2 &T3CON,0x06
extern bit bRD16;
#pragma locate bRD16 &T3CON,0x07
extern bit bT3NSYNC;
#pragma locate bT3NSYNC &T3CON,0x02
extern bit bNOT_T3SYNC;
#pragma locate bNOT_T3SYNC &T3CON,0x02
#line 821
extern bit bCM0;
#pragma locate bCM0 &CMCON,0x00
extern bit bCM1;
#pragma locate bCM1 &CMCON,0x01
extern bit bCM2;
#pragma locate bCM2 &CMCON,0x02
extern bit bCIS;
#pragma locate bCIS &CMCON,0x03
extern bit bC1INV;
#pragma locate bC1INV &CMCON,0x04
extern bit bC2INV;
#pragma locate bC2INV &CMCON,0x05
extern bit bC1OUT;
#pragma locate bC1OUT &CMCON,0x06
extern bit bC2OUT;
#pragma locate bC2OUT &CMCON,0x07

extern bit bCVR0;
#pragma locate bCVR0 &CVRCON,0x00
extern bit bCVR1;
#pragma locate bCVR1 &CVRCON,0x01
extern bit bCVR2;
#pragma locate bCVR2 &CVRCON,0x02
extern bit bCVR3;
#pragma locate bCVR3 &CVRCON,0x03
extern bit bCVREF;
#pragma locate bCVREF &CVRCON,0x04
extern bit bCVRR;
#pragma locate bCVRR &CVRCON,0x05
extern bit bCVROE;
#pragma locate bCVROE &CVRCON,0x06
extern bit bCVREN;
#pragma locate bCVREN &CVRCON,0x07
extern bit bCVRSS;
#pragma locate bCVRSS &CVRCON,0x04

extern bit bPSSBD0;
#pragma locate bPSSBD0 &ECCP1AS,0x00
extern bit bPSSBD1;
#pragma locate bPSSBD1 &ECCP1AS,0x01
extern bit bPSSAC0;
#pragma locate bPSSAC0 &ECCP1AS,0x02
extern bit bPSSAC1;
#pragma locate bPSSAC1 &ECCP1AS,0x03
extern bit bECCPAS0;
#pragma locate bECCPAS0 &ECCP1AS,0x04
extern bit bECCPAS1;
#pragma locate bECCPAS1 &ECCP1AS,0x05
extern bit bECCPAS2;
#pragma locate bECCPAS2 &ECCP1AS,0x06
extern bit bECCPASE;
#pragma locate bECCPASE &ECCP1AS,0x07

extern bit bPDC0;
#pragma locate bPDC0 &PWM1CON,0x00
extern bit bPDC1;
#pragma locate bPDC1 &PWM1CON,0x01
extern bit bPDC2;
#pragma locate bPDC2 &PWM1CON,0x02
extern bit bPDC3;
#pragma locate bPDC3 &PWM1CON,0x03
extern bit bPDC4;
#pragma locate bPDC4 &PWM1CON,0x04
extern bit bPDC5;
#pragma locate bPDC5 &PWM1CON,0x05
extern bit bPDC6;
#pragma locate bPDC6 &PWM1CON,0x06
extern bit bPRSEN;
#pragma locate bPRSEN &PWM1CON,0x07

extern bit bABDEN;
#pragma locate bABDEN &BAUDCTL,0x00
extern bit bWUE;
#pragma locate bWUE &BAUDCTL,0x01
extern bit bBRG16;
#pragma locate bBRG16 &BAUDCTL,0x03
extern bit bSCKP;
#pragma locate bSCKP &BAUDCTL,0x04
extern bit bRCMT;
#pragma locate bRCMT &BAUDCTL,0x06
extern bit bABDOVF;
#pragma locate bABDOVF &BAUDCTL,0x07

extern bit bCCP2M0;
#pragma locate bCCP2M0 &CCP2CON,0x00
extern bit bCCP2M1;
#pragma locate bCCP2M1 &CCP2CON,0x01
extern bit bCCP2M2;
#pragma locate bCCP2M2 &CCP2CON,0x02
extern bit bCCP2M3;
#pragma locate bCCP2M3 &CCP2CON,0x03
extern bit bCCP1Y;
#pragma locate bCCP1Y &CCP2CON,0x04
extern bit bCCP1X;
#pragma locate bCCP1X &CCP2CON,0x05
#line 920
extern bit bCCP1M0;
#pragma locate bCCP1M0 &CCP1CON,0x00
extern bit bCCP1M1;
#pragma locate bCCP1M1 &CCP1CON,0x01
extern bit bCCP1M2;
#pragma locate bCCP1M2 &CCP1CON,0x02
extern bit bCCP1M3;
#pragma locate bCCP1M3 &CCP1CON,0x03

extern bit bP1M0;
#pragma locate bP1M0 &ECCP1CON,0x06
extern bit bP1M1;
#pragma locate bP1M1 &ECCP1CON,0x07
#line 937
extern bit bADCS0;
#pragma locate bADCS0 &ADCON2,0x00
extern bit bADCS1;
#pragma locate bADCS1 &ADCON2,0x01
extern bit bADCS2;
#pragma locate bADCS2 &ADCON2,0x02
extern bit bACQT0;
#pragma locate bACQT0 &ADCON2,0x03
extern bit bACQT1;
#pragma locate bACQT1 &ADCON2,0x04
extern bit bACQT2;
#pragma locate bACQT2 &ADCON2,0x05
extern bit bADFM;
#pragma locate bADFM &ADCON2,0x07

extern bit bPCFG0;
#pragma locate bPCFG0 &ADCON1,0x00
extern bit bPCFG1;
#pragma locate bPCFG1 &ADCON1,0x01
extern bit bPCFG2;
#pragma locate bPCFG2 &ADCON1,0x02
extern bit bPCFG3;
#pragma locate bPCFG3 &ADCON1,0x03
extern bit bVCFG0;
#pragma locate bVCFG0 &ADCON1,0x04
extern bit bVCFG1;
#pragma locate bVCFG1 &ADCON1,0x05

extern bit bADON;
#pragma locate bADON &ADCON0,0x00
extern bit bGO_DONE;
#pragma locate bGO_DONE &ADCON0,0x01
extern bit bCHS0;
#pragma locate bCHS0 &ADCON0,0x02
extern bit bCHS1;
#pragma locate bCHS1 &ADCON0,0x03
extern bit bCHS2;
#pragma locate bCHS2 &ADCON0,0x04
extern bit bCHS3;
#pragma locate bCHS3 &ADCON0,0x05
extern bit bDONE;
#pragma locate bDONE &ADCON0,0x01
extern bit bGO;
#pragma locate bGO &ADCON0,0x01
extern bit bNOT_DONE;
#pragma locate bNOT_DONE &ADCON0,0x01
#line 987
extern bit bSEN;
#pragma locate bSEN &SSPCON2,0x00
extern bit bRSEN;
#pragma locate bRSEN &SSPCON2,0x01
extern bit bPEN;
#pragma locate bPEN &SSPCON2,0x02
extern bit bRCEN;
#pragma locate bRCEN &SSPCON2,0x03
extern bit bACKEN;
#pragma locate bACKEN &SSPCON2,0x04
extern bit bACKDT;
#pragma locate bACKDT &SSPCON2,0x05
extern bit bACKSTAT;
#pragma locate bACKSTAT &SSPCON2,0x06
extern bit bGCEN;
#pragma locate bGCEN &SSPCON2,0x07

extern bit bSSPM0;
#pragma locate bSSPM0 &SSPCON1,0x00
extern bit bSSPM1;
#pragma locate bSSPM1 &SSPCON1,0x01
extern bit bSSPM2;
#pragma locate bSSPM2 &SSPCON1,0x02
extern bit bSSPM3;
#pragma locate bSSPM3 &SSPCON1,0x03
extern bit bCKP;
#pragma locate bCKP &SSPCON1,0x04
extern bit bSSPEN;
#pragma locate bSSPEN &SSPCON1,0x05
extern bit bSSPOV;
#pragma locate bSSPOV &SSPCON1,0x06
extern bit bWCOL;
#pragma locate bWCOL &SSPCON1,0x07

extern bit bBF;
#pragma locate bBF &SSPSTAT,0x00
extern bit bUA;
#pragma locate bUA &SSPSTAT,0x01
extern bit bR_W;
#pragma locate bR_W &SSPSTAT,0x02
extern bit bS;
#pragma locate bS &SSPSTAT,0x03
extern bit bP;
#pragma locate bP &SSPSTAT,0x04
extern bit bD_A;
#pragma locate bD_A &SSPSTAT,0x05
extern bit bCKE;
#pragma locate bCKE &SSPSTAT,0x06
extern bit bSMP;
#pragma locate bSMP &SSPSTAT,0x07
extern bit bI2C_READ;
#pragma locate bI2C_READ &SSPSTAT,0x02
extern bit bI2C_START;
#pragma locate bI2C_START &SSPSTAT,0x03
extern bit bI2C_STOP;
#pragma locate bI2C_STOP &SSPSTAT,0x04
extern bit bI2C_DAT;
#pragma locate bI2C_DAT &SSPSTAT,0x05
extern bit bNOT_W;
#pragma locate bNOT_W &SSPSTAT,0x02
extern bit bNOT_A;
#pragma locate bNOT_A &SSPSTAT,0x05
extern bit bNOT_WRITE;
#pragma locate bNOT_WRITE &SSPSTAT,0x02
extern bit bNOT_ADDRESS;
#pragma locate bNOT_ADDRESS &SSPSTAT,0x05
extern bit bREAD_WRITE;
#pragma locate bREAD_WRITE &SSPSTAT,0x02
extern bit bDATA_ADDRESS;
#pragma locate bDATA_ADDRESS &SSPSTAT,0x05
extern bit bR;
#pragma locate bR &SSPSTAT,0x02
extern bit bD;
#pragma locate bD &SSPSTAT,0x05
#line 1064
extern bit bT2CKPS0;
#pragma locate bT2CKPS0 &T2CON,0x00
extern bit bT2CKPS1;
#pragma locate bT2CKPS1 &T2CON,0x01
extern bit bTMR2ON;
#pragma locate bTMR2ON &T2CON,0x02
extern bit bT2OUTPS0;
#pragma locate bT2OUTPS0 &T2CON,0x03
extern bit bT2OUTPS1;
#pragma locate bT2OUTPS1 &T2CON,0x04
extern bit bT2OUTPS2;
#pragma locate bT2OUTPS2 &T2CON,0x05
extern bit bT2OUTPS3;
#pragma locate bT2OUTPS3 &T2CON,0x06
#line 1081
extern bit bTMR1ON;
#pragma locate bTMR1ON &T1CON,0x00
extern bit bTMR1CS;
#pragma locate bTMR1CS &T1CON,0x01
extern bit bT1SYNC;
#pragma locate bT1SYNC &T1CON,0x02
extern bit bT1OSCEN;
#pragma locate bT1OSCEN &T1CON,0x03
extern bit bT1CKPS0;
#pragma locate bT1CKPS0 &T1CON,0x04
extern bit bT1CKPS1;
#pragma locate bT1CKPS1 &T1CON,0x05
extern bit bT1RUN;
#pragma locate bT1RUN &T1CON,0x06
extern bit bNOT_T1SYNC;
#pragma locate bNOT_T1SYNC &T1CON,0x02
#line 1100
extern bit bNOT_BOR;
#pragma locate bNOT_BOR &RCON,0x00
extern bit bNOT_POR;
#pragma locate bNOT_POR &RCON,0x01
extern bit bNOT_PD;
#pragma locate bNOT_PD &RCON,0x02
extern bit bNOT_TO;
#pragma locate bNOT_TO &RCON,0x03
extern bit bNOT_RI;
#pragma locate bNOT_RI &RCON,0x04
extern bit bSBOREN;
#pragma locate bSBOREN &RCON,0x06
extern bit bNOT_IPEN;
#pragma locate bNOT_IPEN &RCON,0x07
extern bit bBOR;
#pragma locate bBOR &RCON,0x00
extern bit bPOR;
#pragma locate bPOR &RCON,0x01
extern bit bTO;
#pragma locate bTO &RCON,0x03
extern bit bRI;
#pragma locate bRI &RCON,0x04
extern bit bIPEN;
#pragma locate bIPEN &RCON,0x07

extern bit bSWDTEN;
#pragma locate bSWDTEN &WDTCON,0x00
extern bit bSWDTE;
#pragma locate bSWDTE &WDTCON,0x00

extern bit bLVDL0;
#pragma locate bLVDL0 &LVDCON,0x00
extern bit bLVDL1;
#pragma locate bLVDL1 &LVDCON,0x01
extern bit bLVDL2;
#pragma locate bLVDL2 &LVDCON,0x02
extern bit bLVDL3;
#pragma locate bLVDL3 &LVDCON,0x03
extern bit bLVDEN;
#pragma locate bLVDEN &LVDCON,0x04
extern bit bIRVST;
#pragma locate bIRVST &LVDCON,0x05
extern bit bVDIRMAG;
#pragma locate bVDIRMAG &LVDCON,0x07
extern bit bLVV0;
#pragma locate bLVV0 &LVDCON,0x00
extern bit bLVV1;
#pragma locate bLVV1 &LVDCON,0x01
extern bit bLVV2;
#pragma locate bLVV2 &LVDCON,0x02
extern bit bLVV3;
#pragma locate bLVV3 &LVDCON,0x03
extern bit bBGST;
#pragma locate bBGST &LVDCON,0x05

extern bit bSCS0;
#pragma locate bSCS0 &OSCCON,0x00
extern bit bSCS1;
#pragma locate bSCS1 &OSCCON,0x01
extern bit bFLTS;
#pragma locate bFLTS &OSCCON,0x02
extern bit bOSTS;
#pragma locate bOSTS &OSCCON,0x03
extern bit bIRCF0;
#pragma locate bIRCF0 &OSCCON,0x04
extern bit bIRCF1;
#pragma locate bIRCF1 &OSCCON,0x05
extern bit bIRCF2;
#pragma locate bIRCF2 &OSCCON,0x06
extern bit bIDLEN;
#pragma locate bIDLEN &OSCCON,0x07

extern bit bT0PS0;
#pragma locate bT0PS0 &T0CON,0x00
extern bit bT0PS1;
#pragma locate bT0PS1 &T0CON,0x01
extern bit bT0PS2;
#pragma locate bT0PS2 &T0CON,0x02
extern bit bPSA;
#pragma locate bPSA &T0CON,0x03
extern bit bT0SE;
#pragma locate bT0SE &T0CON,0x04
extern bit bT0CS;
#pragma locate bT0CS &T0CON,0x05
extern bit bT08BIT;
#pragma locate bT08BIT &T0CON,0x06
extern bit bTMR0ON;
#pragma locate bTMR0ON &T0CON,0x07
#line 1191
extern bit bC;
#pragma locate bC &STATUS,0x00
extern bit bDC;
#pragma locate bDC &STATUS,0x01
extern bit bZ;
#pragma locate bZ &STATUS,0x02
extern bit bOV;
#pragma locate bOV &STATUS,0x03
extern bit bN;
#pragma locate bN &STATUS,0x04
#line 1225
extern bit bINT1IF;
#pragma locate bINT1IF &INTCON3,0x00
extern bit bINT2IF;
#pragma locate bINT2IF &INTCON3,0x01
extern bit bINT1IE;
#pragma locate bINT1IE &INTCON3,0x03
extern bit bINT2IE;
#pragma locate bINT2IE &INTCON3,0x04
extern bit bINT1IP;
#pragma locate bINT1IP &INTCON3,0x06
extern bit bINT2IP;
#pragma locate bINT2IP &INTCON3,0x07
extern bit bINT1F;
#pragma locate bINT1F &INTCON3,0x00
extern bit bINT2F;
#pragma locate bINT2F &INTCON3,0x01
extern bit bINT3F;
#pragma locate bINT3F &INTCON3,0x02
extern bit bINT1E;
#pragma locate bINT1E &INTCON3,0x03
extern bit bINT2E;
#pragma locate bINT2E &INTCON3,0x04
extern bit bINT3E;
#pragma locate bINT3E &INTCON3,0x05
extern bit bINT1P;
#pragma locate bINT1P &INTCON3,0x06
extern bit bINT2P;
#pragma locate bINT2P &INTCON3,0x07

extern bit bRBIP;
#pragma locate bRBIP &INTCON2,0x00
extern bit bTMR0IP;
#pragma locate bTMR0IP &INTCON2,0x02
extern bit bINTEDG2;
#pragma locate bINTEDG2 &INTCON2,0x04
extern bit bINTEDG1;
#pragma locate bINTEDG1 &INTCON2,0x05
extern bit bINTEDG0;
#pragma locate bINTEDG0 &INTCON2,0x06
extern bit bNOT_RBPU;
#pragma locate bNOT_RBPU &INTCON2,0x07
extern bit bT0IP;
#pragma locate bT0IP &INTCON2,0x02
extern bit bRBPU;
#pragma locate bRBPU &INTCON2,0x07

extern bit bRBIF;
#pragma locate bRBIF &INTCON,0x00
extern bit bINT0IF;
#pragma locate bINT0IF &INTCON,0x01
extern bit bTMR0IF;
#pragma locate bTMR0IF &INTCON,0x02
extern bit bRBIE;
#pragma locate bRBIE &INTCON,0x03
extern bit bINT0IE;
#pragma locate bINT0IE &INTCON,0x04
extern bit bTMR0IE;
#pragma locate bTMR0IE &INTCON,0x05
extern bit bPEIE;
#pragma locate bPEIE &INTCON,0x06
extern bit bGIE;
#pragma locate bGIE &INTCON,0x07
extern bit bINT0F;
#pragma locate bINT0F &INTCON,0x01
extern bit bT0IF;
#pragma locate bT0IF &INTCON,0x02
extern bit bINT0E;
#pragma locate bINT0E &INTCON,0x04
extern bit bT0IE;
#pragma locate bT0IE &INTCON,0x05
extern bit bGIEL;
#pragma locate bGIEL &INTCON,0x06
extern bit bGIEH;
#pragma locate bGIEH &INTCON,0x07
#line 1312
extern bit bSTKPTR0;
#pragma locate bSTKPTR0 &STKPTR,0x00
extern bit bSTKPTR1;
#pragma locate bSTKPTR1 &STKPTR,0x01
extern bit bSTKPTR2;
#pragma locate bSTKPTR2 &STKPTR,0x02
extern bit bSTKPTR3;
#pragma locate bSTKPTR3 &STKPTR,0x03
extern bit bSTKPTR4;
#pragma locate bSTKPTR4 &STKPTR,0x04
extern bit bSTKUNF;
#pragma locate bSTKUNF &STKPTR,0x06
extern bit bSTKOVF;
#pragma locate bSTKOVF &STKPTR,0x07
#line 23 "C:/Program Files/FED/PIXIE/Libs/ProcIncs/pic.h"
const int true=1;
const int false=0;
#line 18 "C:/Program Files/FED/PIXIE/Libs/FEDC18.h"
struct _TRISAbits
{
unsigned char TRISA0:1;
unsigned char TRISA1:1;
unsigned char TRISA2:1;
unsigned char TRISA3:1;
unsigned char TRISA4:1;
unsigned char TRISA5:1;
unsigned char TRISA6:1;
unsigned char TRISA7:1;
};

struct _TRISBbits
{
unsigned char TRISB0:1;
unsigned char TRISB1:1;
unsigned char TRISB2:1;
unsigned char TRISB3:1;
unsigned char TRISB4:1;
unsigned char TRISB5:1;
unsigned char TRISB6:1;
unsigned char TRISB7:1;
};

struct _TRISCbits
{
unsigned char TRISC0:1;
unsigned char TRISC1:1;
unsigned char TRISC2:1;
unsigned char TRISC3:1;
unsigned char TRISC4:1;
unsigned char TRISC5:1;
unsigned char TRISC6:1;
unsigned char TRISC7:1;
};

struct _TRISDbits
{
unsigned char TRISD0:1;
unsigned char TRISD1:1;
unsigned char TRISD2:1;
unsigned char TRISD3:1;
unsigned char TRISD4:1;
unsigned char TRISD5:1;
unsigned char TRISD6:1;
unsigned char TRISD7:1;
};

struct _TRISEbits
{
unsigned char TRISE0:1;
unsigned char TRISE1:1;
unsigned char TRISE2:1;
unsigned char TRISE3:1;
unsigned char TRISE4:1;
unsigned char TRISE5:1;
unsigned char TRISE6:1;
unsigned char TRISE7:1;
};

extern _TRISAbits TRISAbits;
#pragma locate TRISAbits 0x0F91
extern _TRISBbits TRISBbits;
#pragma locate TRISBbits 0x0F93
extern _TRISCbits TRISCbits;
#pragma locate TRISCbits 0x0F94
extern _TRISDbits TRISDbits;
#pragma locate TRISDbits 0x0F95
extern _TRISEbits TRISEbits;
#pragma locate TRISEbits 0x0F96

struct _PORTAbits
{
unsigned char RA0:1;
unsigned char RA1:1;
unsigned char RA2:1;
unsigned char RA3:1;
unsigned char RA4:1;
unsigned char RA5:1;
unsigned char RA6:1;
unsigned char RA7:1;
};

struct _PORTBbits
{
unsigned char RB0:1;
unsigned char RB1:1;
unsigned char RB2:1;
unsigned char RB3:1;
unsigned char RB4:1;
unsigned char RB5:1;
unsigned char RB6:1;
unsigned char RB7:1;
};

struct _PORTCbits
{
unsigned char RC0:1;
unsigned char RC1:1;
unsigned char RC2:1;
unsigned char RC3:1;
unsigned char RC4:1;
unsigned char RC5:1;
unsigned char RC6:1;
unsigned char RC7:1;
};

struct _PORTDbits
{
unsigned char RD0:1;
unsigned char RD1:1;
unsigned char RD2:1;
unsigned char RD3:1;
unsigned char RD4:1;
unsigned char RD5:1;
unsigned char RD6:1;
unsigned char RD7:1;
};
#line 138
struct _PORTEbits
{
unsigned char RE0:1;
unsigned char RE1:1;
unsigned char RE2:1;
unsigned char RE3:1;
unsigned char RE4:1;
unsigned char RE5:1;
unsigned char RE6:1;
unsigned char RE7:1;
};

extern _PORTAbits PORTAbits;
#pragma locate PORTAbits 0x0F80
extern _PORTBbits PORTBbits;
#pragma locate PORTBbits 0x0F81
extern _PORTCbits PORTCbits;
#pragma locate PORTCbits 0x0F82
extern _PORTDbits PORTDbits;
#pragma locate PORTDbits 0x0F83
extern _PORTEbits PORTEbits;
#pragma locate PORTEbits 0x0F84
#line 162
struct _LATAbits
{
unsigned char LATA0:1;
unsigned char LATA1:1;
unsigned char LATA2:1;
unsigned char LATA3:1;
unsigned char LATA4:1;
unsigned char LATA5:1;
unsigned char LATA6:1;
unsigned char LATA7:1;
};

struct _LATBbits
{
unsigned char LATB0:1;
unsigned char LATB1:1;
unsigned char LATB2:1;
unsigned char LATB3:1;
unsigned char LATB4:1;
unsigned char LATB5:1;
unsigned char LATB6:1;
unsigned char LATB7:1;
};

struct _LATCbits
{
unsigned char LATC0:1;
unsigned char LATC1:1;
unsigned char LATC2:1;
unsigned char LATC3:1;
unsigned char LATC4:1;
unsigned char LATC5:1;
unsigned char LATC6:1;
unsigned char LATC7:1;
};

struct _LATDbits
{
unsigned char LATD0:1;
unsigned char LATD1:1;
unsigned char LATD2:1;
unsigned char LATD3:1;
unsigned char LATD4:1;
unsigned char LATD5:1;
unsigned char LATD6:1;
unsigned char LATD7:1;
};

struct _LATEbits
{
unsigned char LATE0:1;
unsigned char LATE1:1;
unsigned char LATE2:1;
unsigned char LATE3:1;
unsigned char LATE4:1;
unsigned char LATE5:1;
unsigned char LATE6:1;
unsigned char LATE7:1;
};

extern _LATAbits LATAbits;
#pragma locate LATAbits 0x0F89
extern _LATBbits LATBbits;
#pragma locate LATBbits 0x0F8A
extern _LATCbits LATCbits;
#pragma locate LATCbits 0x0F8B
extern _LATDbits LATDbits;
#pragma locate LATDbits 0x0F8C
extern _LATEbits LATEbits;
#pragma locate LATEbits 0x0F8D
#line 40 "C:/My Documents/PIC/Cdc/system/typedefs.h"
typedef unsigned char byte;
typedef unsigned int word;
typedef unsigned long dword;

typedef union _BYTE
{
byte _byte;
struct
{
unsigned b0:1;
unsigned b1:1;
unsigned b2:1;
unsigned b3:1;
unsigned b4:1;
unsigned b5:1;
unsigned b6:1;
unsigned b7:1;
};
} MBYTE;

typedef union _WORD
{
word _word;
struct
{
byte byte0;
byte byte1;
};
struct
{
MBYTE Byte0;
MBYTE Byte1;
};
struct
{
MBYTE LowB;
MBYTE HighB;
};
struct
{
byte v[2];
};
} MWORD;
#line 86
typedef union _DWORD
{
dword _dword;
struct
{
byte byte0;
byte byte1;
byte byte2;
byte byte3;
};
struct
{
word word0;
word word1;
};
struct
{
MBYTE Byte0;
MBYTE Byte1;
MBYTE Byte2;
MBYTE Byte3;
};
struct
{
MWORD Word0;
MWORD Word1;
};
struct
{
byte v[4];
};
} DWORD;
#line 123
typedef void(*pFunc)(void);

typedef union _POINTER
{
struct
{
byte bLow;
byte bHigh;

};
word _word;
#line 137
byte* bRam;

word* wRam;
#line 142
 byte* bRom;
 word* wRom;
#line 148
} POINTER;

typedef enum _BOOL { FALSE = 0, TRUE } BOOL;
#line 122 "C:/My Documents/PIC/Cdc/system/usb/usbdefs/usbdefs_std_dsc.h"
typedef struct _USB_DEV_DSC
{
byte bLength; byte bDscType; word bcdUSB;
byte bDevCls; byte bDevSubCls; byte bDevProtocol;
byte bMaxPktSize0; word idVendor; word idProduct;
word bcdDevice; byte iMFR; byte iProduct;
byte iSerialNum; byte bNumCfg;
} USB_DEV_DSC;
#line 134
typedef struct _USB_CFG_DSC
{
byte bLength; byte bDscType; word wTotalLength;
byte bNumIntf; byte bCfgValue; byte iCfg;
byte bmAttributes; byte bMaxPower;
} USB_CFG_DSC;
#line 144
typedef struct _USB_INTF_DSC
{
byte bLength; byte bDscType; byte bIntfNum;
byte bAltSetting; byte bNumEPs; byte bIntfCls;
byte bIntfSubCls; byte bIntfProtocol; byte iIntf;
} USB_INTF_DSC;
#line 154
typedef struct _USB_EP_DSC
{
byte bLength; byte bDscType; byte bEPAdr;
byte bmAttributes; word wMaxPktSize; byte bInterval;
} USB_EP_DSC;
#line 263 "C:/My Documents/PIC/Cdc/system/usb/class/cdc/cdc.h"
typedef union _LINE_CODING
{
struct
{
byte _byte[0x07];
};
struct
{
DWORD dwDTERate;
byte bCharFormat;
byte bParityType;
byte bDataBits;
};
} LINE_CODING;

typedef union _CONTROL_SIGNAL_BITMAP
{
byte _byte;
struct
{
unsigned DTE_PRESENT;
unsigned CARRIER_CONTROL;
};
} CONTROL_SIGNAL_BITMAP;
#line 292
typedef struct _USB_CDC_HEADER_FN_DSC
{
byte bFNLength;
byte bDscType;
byte bDscSubType;
word bcdCDC;
} USB_CDC_HEADER_FN_DSC;
#line 301
typedef struct _USB_CDC_ACM_FN_DSC
{
byte bFNLength;
byte bDscType;
byte bDscSubType;
byte bmCapabilities;
} USB_CDC_ACM_FN_DSC;
#line 310
typedef struct _USB_CDC_UNION_FN_DSC
{
byte bFNLength;
byte bDscType;
byte bDscSubType;
byte bMasterIntf;
byte bSaveIntf0;
} USB_CDC_UNION_FN_DSC;
#line 320
typedef struct _USB_CDC_CALL_MGT_FN_DSC
{
byte bFNLength;
byte bDscType;
byte bDscSubType;
byte bmCapabilities;
byte bDataInterface;
} USB_CDC_CALL_MGT_FN_DSC;
#line 330
extern byte cdc_rx_len;

extern byte cdc_trf_state;
extern POINTER pCDCSrc;
extern byte cdc_tx_len;
extern byte cdc_mem_type;
#line 338
void USBCheckCDCRequest(void);
void CDCInitEP(void);
byte getsUSBUSART(char *buffer, byte len);
void putrsUSBUSART( char *data);
void putsUSBUSART(char *data);
void CDCTxService(void);
#line 56 "C:/My Documents/PIC/Cdc/autofiles/usbdsc.h"
struct CFG01
{ USB_CFG_DSC cd01;
USB_INTF_DSC i01a00;
USB_CDC_HEADER_FN_DSC cdc_header_fn_i01a00;
USB_CDC_ACM_FN_DSC cdc_acm_fn_i01a00;
USB_CDC_UNION_FN_DSC cdc_union_fn_i01a00;
USB_CDC_CALL_MGT_FN_DSC cdc_call_mgt_fn_i01a00;
USB_EP_DSC ep02i_i01a00;
USB_INTF_DSC i02a00;
USB_EP_DSC ep03o_i02a00;
USB_EP_DSC ep03i_i02a00;
};
#line 83
extern  const USB_DEV_DSC device_dsc;
extern const CFG01 cfg01;
#line 87
extern  const unsigned char *USB_CD_Ptr[];
extern  const unsigned char *USB_SD_Ptr[];
#line 91
extern const void (*ClassReqHandler[1])();
#line 59 "C:/My Documents/PIC/Cdc/system/usb/usbdefs/usbdefs_ep0_buff.h"
typedef union _CTRL_TRF_SETUP
{

struct
{
byte _byte[8];
};
#line 68
struct
{
byte bmRequestType;
byte bRequest;
word wValue;
word wIndex;
word wLength;
};
struct
{
unsigned char :8;
unsigned char :8;
MWORD W_Value;
MWORD W_Index;
MWORD W_Length;
};
struct
{
unsigned char Recipient:5;
unsigned char RequestType:2;
unsigned char DataDir:1;
unsigned char :8;
byte bFeature;
unsigned char:8;
unsigned char:8;
unsigned char:8;
unsigned char:8;
unsigned char:8;
};
struct
{
unsigned char:8;
unsigned char:8;
byte bDscIndex;
byte bDscType;
word wLangID;
unsigned char:8;
unsigned char:8;
};
struct
{
unsigned :8;
unsigned :8;
MBYTE bDevADR;
byte bDevADRH;
unsigned :8;
unsigned :8;
unsigned :8;
unsigned :8;
};
struct
{
unsigned :8;
unsigned :8;
byte bCfgValue;
byte bCfgRSD;
unsigned :8;
unsigned :8;
unsigned :8;
unsigned :8;
};
struct
{
unsigned :8;
unsigned :8;
byte bAltID;
byte bAltID_H;
byte bIntfID;
byte bIntfID_H;
unsigned :8;
unsigned :8;
};
struct
{
unsigned :8;
unsigned :8;
unsigned :8;
unsigned :8;
byte bEPID;
byte bEPID_H;
unsigned :8;
unsigned :8;
};
struct
{
unsigned :8;
unsigned :8;
unsigned :8;
unsigned :8;
unsigned char EPNum:4;
unsigned :3;
unsigned char EPDir:1;
unsigned :8;
unsigned :8;
unsigned :8;
};
#line 166
} CTRL_TRF_SETUP;
#line 179
typedef union _CTRL_TRF_DATA
{

struct
{
byte _byte[8];
};
#line 188
struct
{
byte _byte0;
byte _byte1;
byte _byte2;
byte _byte3;
byte _byte4;
byte _byte5;
byte _byte6;
byte _byte7;
};
struct
{
word _word0;
word _word1;
word _word2;
word _word3;
};

} CTRL_TRF_DATA;
#line 70 "C:/My Documents/PIC/Cdc/system/usb/usbmmap.h"
typedef union _USB_DEVICE_STATUS
{
byte _byte;
struct
{
unsigned RemoteWakeup:1;
unsigned ctrl_trf_mem:1;
};
} USB_DEVICE_STATUS;

typedef union _BD_STAT
{
byte _byte;
struct{
unsigned char BC8:1;
unsigned char BC9:1;
unsigned char BSTALL:1;
unsigned char DTSEN:1;
unsigned char INCDIS:1;
unsigned char KEN:1;
unsigned char DTS:1;
unsigned char UOWN:1;
};
struct{
unsigned char BC8:1;
unsigned char BC9:1;
unsigned char PID0:1;
unsigned char PID1:1;
unsigned char PID2:1;
unsigned char PID3:1;
unsigned char :1;
unsigned char UOWN:1;
};
struct{
unsigned char :2;
unsigned char PID:4;
unsigned char :2;
};
} BD_STAT;

typedef union _BDT
{
struct
{
BD_STAT Stat;
byte Cnt;
byte ADRL;
byte ADRH;
};
struct
{
unsigned char :8;
unsigned char :8;
byte* ADR;
};
} BDT;
#line 128
extern byte usb_device_state;
extern USB_DEVICE_STATUS usb_stat;
extern byte usb_active_cfg;
extern byte usb_alt_intf[1];

extern   BDT ep0Bo;
extern   BDT ep0Bi;
extern   BDT ep1Bo;
extern   BDT ep1Bi;
extern   BDT ep2Bo;
extern   BDT ep2Bi;
extern   BDT ep3Bo;
extern   BDT ep3Bi;
extern   BDT ep4Bo;
extern   BDT ep4Bi;
extern   BDT ep5Bo;
extern   BDT ep5Bi;
extern   BDT ep6Bo;
extern   BDT ep6Bi;
extern   BDT ep7Bo;
extern   BDT ep7Bi;
extern   BDT ep8Bo;
extern   BDT ep8Bi;
extern   BDT ep9Bo;
extern   BDT ep9Bi;
extern   BDT ep10Bo;
extern   BDT ep10Bi;
extern   BDT ep11Bo;
extern   BDT ep11Bi;
extern   BDT ep12Bo;
extern   BDT ep12Bi;
extern   BDT ep13Bo;
extern   BDT ep13Bi;
extern   BDT ep14Bo;
extern   BDT ep14Bi;
extern   BDT ep15Bo;
extern   BDT ep15Bi;
#line 167
#pragma locate ep0Bo 0x400
#pragma locate ep0Bi 0x404
#line 172
#pragma locate ep1Bo 0x408
#pragma locate ep1Bi 0x40C
#line 177
#pragma locate ep2Bo 0x410
#pragma locate ep2Bi 0x414
#line 182
#pragma locate ep3Bo 0x418
#pragma locate ep3Bi 0x41C
#line 246
extern   CTRL_TRF_SETUP SetupPkt;
extern   CTRL_TRF_DATA CtrlTrfData;
#pragma locate SetupPkt 0x480
#pragma locate CtrlTrfData 0x480+8
#line 252
extern   unsigned char cdc_notice[8];
extern   unsigned char cdc_data_rx[64];
extern   unsigned char cdc_data_tx[64];
#pragma locate cdc_notice 0x500
#pragma locate cdc_data_rx 0x500+8
#pragma locate cdc_data_tx 0x500+8+64
#line 200 "C:/My Documents/PIC/Cdc/system/usb/usbdrv/usbdrv.h"
void USBCheckBusStatus(void);
void USBDriverService(void);
void USBRemoteWakeup(void);
void USBSoftDetach(void);

void ClearArray(byte* startAdr,byte count);
#line 68 "C:/My Documents/PIC/Cdc/system/usb/usbctrltrf/usbctrltrf.h"
extern byte ctrl_trf_session_owner;

extern POINTER pSrc;
extern POINTER pDst;
extern MWORD wCount;
#line 75
void USBCtrlEPService(void);
void USBCtrlTrfTxService(void);
void USBCtrlTrfRxService(void);
void USBCtrlEPServiceComplete(void);
void USBPrepareForNextSetupTrf(void);
#line 92 "C:/My Documents/PIC/Cdc/system/usb/usb9/usb9.h"
void USBCheckStdRequest(void);
#line 41 "C:/My Documents/PIC/Cdc/user/user.h"
void UserInit(void);
void ProcessIO(void);
void TxHex(unsigned char x,unsigned char lf);
#line 27 "C:/MY DOCUMENTS/PIC/Cdc/user/user_v5.c"
const int NormalInt=1;
#line 30
#pragma udata 
byte old_sw2,old_sw3;
static byte state = 0;
static byte doatod = 0;
byte Flag = 0;
#line 37
static int count = 0;
static byte buffer[256];
#line 41
void InitializeUSART(void);
void BlinkUSBStatus(void);
BOOL Switch2IsPressed(void);
BOOL Switch3IsPressed(void);
void Interrupt();
void AtoDtoUSB(void);
#line 49
#pragma code 
void UserInit(void)
{
LATD &= 0xF0; TRISD &= 0xF0;;
TRISBbits.TRISB4=1;TRISBbits.TRISB5=1;;
old_sw2 = PORTBbits.RB4;
old_sw3 = PORTBbits.RB5;

bTRA0 = 1;
ADCON1 = 0x0E;
ADCON0 = 0x01;
ADCON2 = 0x80;
#line 64
bTRD3 = 0;
#line 68
bT0CS = 0;
bT0SE = 0;
bT08BIT = 1;
bPSA = 0;
#line 74
bT0PS2 = 0; bT0PS1 = 0; bT0PS0 = 0;

bTMR0ON = 1;
#line 81
InitializeUSART();
}

void InitializeUSART(void)
{
bRC6=1;
TRISCbits.TRISC7=1;
TRISCbits.TRISC6=0;
SPBRG = 0x68;
SPBRGH = 0x0;
TXSTA = 0x24;
RCSTA = 0x90;
BAUDCTL = 0x08;
}
#line 102
void ProcessIO(void)
{
BlinkUSBStatus();
if((usb_device_state < 6)||(bSUSPND==1)) return;
if(usb_device_state == 6)
bGIE = 1;

if(PORTBbits.RB4 == 0)
bT0IE = 1;
else
bT0IE = 0;
}

void Interrupt()
{
if (bTMR0IF)
{
bTMR0IF = 0;
TMR0L = (~68) +1;
#line 126
doatod++;
}
#line 131
if(doatod == 1)
{
doatod = 0;
bGO = 1;
while (bGO);
PD.B3 = !PD.B3;
#line 140
buffer[count] = count;
buffer[++count] = count;
count++;

if (count == 254)
{
count = 0;
if(PORTBbits.RB4 ==0)
{
if((cdc_trf_state == 0))
{ pCDCSrc.bRam = (byte*)buffer; cdc_tx_len = 254; cdc_mem_type = 0; cdc_trf_state = 1; };
}
}
}
}
#line 167
void BlinkUSBStatus(void)
{
static word led_count=0;

if(led_count == 0)led_count = 10000U;
led_count--;
#line 179
if(bSUSPND == 1)
{
if(led_count==0)
{
LATDbits.LATD0 = !LATDbits.LATD0;;
LATDbits.LATD1 = LATDbits.LATD0;
}
}
else
{
if(usb_device_state == 0)
{
{LATDbits.LATD0 = 0;;LATDbits.LATD1 = 0;;};
}
else if(usb_device_state == 1)
{
{LATDbits.LATD0 = 1;;LATDbits.LATD1 = 1;;};
}
else if(usb_device_state == 2)
{
{LATDbits.LATD0 = 1;;LATDbits.LATD1 = 0;;};
}
else if(usb_device_state == 3)
{
{LATDbits.LATD0 = 0;;LATDbits.LATD1 = 1;;};
}
else if(usb_device_state == 5)
{
if(led_count == 0)
{
LATDbits.LATD0 = !LATDbits.LATD0;;
LATDbits.LATD1 = 0;;
}
}
else if(usb_device_state == 6)
{
if(led_count==0)
{
LATDbits.LATD0 = !LATDbits.LATD0;;
LATDbits.LATD1 = !LATDbits.LATD0;
}
}
}

}

BOOL Switch2IsPressed(void)
{
if(PORTBbits.RB4 != old_sw2)
{
old_sw2 = PORTBbits.RB4;
if(PORTBbits.RB4 == 0)
return TRUE;
}
return FALSE;
}

BOOL Switch3IsPressed(void)
{
if(PORTBbits.RB5 != old_sw3)
{
old_sw3 = PORTBbits.RB5;
if(PORTBbits.RB5 == 0)
return TRUE;
}
return FALSE;
}
