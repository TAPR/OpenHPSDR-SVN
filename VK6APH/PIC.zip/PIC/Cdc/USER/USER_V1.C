/****************************************************************************
*
* user_v1.c  P V Harman VK6APH
*
* This program reads A0 of the A/D converter and sends it to the 
* PC via the USB connection when S2 is pressed. 
*
* User routines for USB interface to SDR1000. NB: Blocking functions must
* NOT be used so that USB hardware can always be serviced
* NOTE: use byte and not BYTE since latter defines a union
*
****************************************************************************/
#include <FEDC18.h>
#include "system\typedefs.h"
#include "system\usb\usb.h"
#include "io_cfg.h"             // I/O pin mapping
#include "user\user.h"

/** V A R I A B L E S ********************************************************/
#pragma udata
byte old_sw2,old_sw3;
static byte state = 0;

char input_buffer[64];
char output_buffer[64];

/** P R I V A T E  P R O T O T Y P E S ***************************************/
void InitializeUSART(void);
void BlinkUSBStatus(void);
BOOL Switch2IsPressed(void);
BOOL Switch3IsPressed(void);

void AtoDtoUSB(void);

/** D E C L A R A T I O N S **************************************************/
#pragma code
void UserInit(void)
{
    mInitAllLEDs();
    mInitAllSwitches();
    old_sw2 = sw2;
    old_sw3 = sw3;
    // set up A.D converter on PortA 0
	bTRA0 = 1; 	   // set port A bit 0 as input for A/D
	ADCON1 = 0x0E; // set AN0 as input and VSS, VDD as ref
	ADCON0 = 0x01; // select channel 0 and turn A/D on
	ADCON2 = 0x80; // right justified, TAD, Fosc/2
        
    InitializeUSART();   
}

void InitializeUSART(void)
{
    bRC6=1;
    TRISCbits.TRISC7=1; // RX
    TRISCbits.TRISC6=0; // TX
    SPBRG = 0x68;
    SPBRGH = 0x0;       // 0x068 for 48MHz -> 115200 baud
    TXSTA = 0x24;       // TX enable BRGH=1
    RCSTA = 0x90;       // continuous RX
    BAUDCON = 0x08;     // BRG16 = 1
}

/*****************************************************************************
 * Function:        void ProcessIO(void)
 *
 * Overview:        This function is a place holder for other user routines.
 *                  It is a mixture of both USB and non-USB tasks.
 *****************************************************************************/
void ProcessIO(void)
{   
    BlinkUSBStatus();		// Bink USB status LEDs
    
    // User Application USB tasks
    if((usb_device_state < CONFIGURED_STATE)||(bSUSPND==1)) return;

	AtoDtoUSB();			// call A to D converter on PortA 0 and send to USB 

}

void AtoDtoUSB(void)
{
	int ad_data;
	static int last_data;

	byte buffer[2];
	
	// get A/D value and send to PC virtual terminal via USB
	if(state == 0)
	{
		bGO = 1;			// start A/D conversion 
		state++;
	}
	if ((state == 1) && !bGO)			// check if A/D is complete
		state++;

	
	if (state == 2)
	{
		ad_data = ADRESH; 
		ad_data = ad_data << 8 | ADRESL;  // form 10 bit data 
		
		//if (ad_data != last_data)  // only send to USB  if data has changed
	
		//if(Switch2IsPressed())
		if(sw2 ==0) // only send when SW2 is pressed
		{
			if(mUSBUSARTIsTxTrfReady())
				buffer[0] = ADRESH;  // top 2 bits of A/D conversion
				buffer[1] = ADRESL;	 // bottom 8 bits
				mUSBUSARTTxRam((byte*)buffer,2); // send A/D data
			last_data = ad_data;
		}
		state = 0;  // reset state and start again
	}
    
}



/******************************************************************************
 * Function:        void BlinkUSBStatus(void)
 *
 * Overview:        BlinkUSBStatus turns on and off LEDs corresponding to
 *                  the USB device state.
 *
 * Note:            mLED macros can be found in io_cfg.h
 *                  usb_device_state is declared in usbmmap.c and is modified
 *                  in usbdrv.c, usbctrltrf.c, and usb9.c
 *****************************************************************************/
void BlinkUSBStatus(void)
{
    static word led_count=0;
    
    if(led_count == 0)led_count = 10000U;
    led_count--;

    #define mLED_Both_Off()         {mLED_1_Off();mLED_2_Off();}
    #define mLED_Both_On()          {mLED_1_On();mLED_2_On();}
    #define mLED_Only_1_On()        {mLED_1_On();mLED_2_Off();}
    #define mLED_Only_2_On()        {mLED_1_Off();mLED_2_On();}
    
    if(bSUSPND == 1)
    {
        if(led_count==0)
        {
            mLED_1_Toggle();
            mLED_2 = mLED_1;        // Both blink at the same time
        }
    }
    else
    {
        if(usb_device_state == DETACHED_STATE)
        {
            mLED_Both_Off();
        }
        else if(usb_device_state == ATTACHED_STATE)
        {
            mLED_Both_On();
        }
        else if(usb_device_state == POWERED_STATE)
        {
            mLED_Only_1_On();
        }
        else if(usb_device_state == DEFAULT_STATE)
        {
            mLED_Only_2_On();
        }
        else if(usb_device_state == ADDRESS_STATE)
        {
            if(led_count == 0)
            {
                mLED_1_Toggle();
                mLED_2_Off();
            }
        }
        else if(usb_device_state == CONFIGURED_STATE)
        {
            if(led_count==0)
            {
                mLED_1_Toggle();
                mLED_2 = !mLED_1;       // Alternate blink                
            }
        }
    }

}

BOOL Switch2IsPressed(void)
{
    if(sw2 != old_sw2)
    {
        old_sw2 = sw2;                  // Save new value
        if(sw2 == 0)                    // If pressed
            return TRUE;                // Was pressed
    }
    return FALSE;                       // Was not pressed
}

BOOL Switch3IsPressed(void)
{
    if(sw3 != old_sw3)
    {
        old_sw3 = sw3;                  // Save new value
        if(sw3 == 0)                    // If pressed
            return TRUE;                // Was pressed
    }
    return FALSE;                       // Was not pressed
}

