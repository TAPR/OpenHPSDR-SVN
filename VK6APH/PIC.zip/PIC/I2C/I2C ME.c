
///////////////////////////////////////////////////////////////////////////////
//
// I2C ME.c - I2C  test program for 16F877
//
//
//
///////////////////////////////////////////////////////////////////////////////

// define use of Bootloader

//const int MCBOOTLOADER = 1;

#include "delays.h"
#include <strings.h>		// used by fnprint()
#include <datalib.h>
#include <pic.h>
#include "mssp.h"

#define S2 !PB.B4		// push button S2 on development board
#define S3 !PB.B5		// push button S3 on development board
#define D4 PD.B3		// LED D4 on development board 

#pragma udata

//private prototypes
void InitializeUSART(void);

#asmfunc send(char Data)		// set fnprintf function
#pragma code

void main()
{
	InitializeUSART(); // initalize RS2332 port
	InitializeMSSP();  // initalize I2C port - see mssp.c

	if(i2c_master_start())  // send start to I2C buss
	{
		fnprintf(send, "Error - 12C start\n %");
		//while(1); // loop on error 
	}
	
	if(i2c_master_out_byte(0x00)) // send address and write signal
	{
		fnprintf(send, "Error - 12C address \n %");
		while(1); // loop on error
	}	
		
	if(i2c_master_out_byte(0xAA)) // send data 
	{
		fnprintf(send, "Error - 12C data\n %");
		while(1); // loop on error
	}	
	

	while(1);
	
}

