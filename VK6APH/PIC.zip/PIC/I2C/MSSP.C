
///////////////////////////////////////////////////////////////////////////////
//
//  Functions  to use  MSSP  with I2C 
//
///////////////////////////////////////////////////////////////////////////////

#include <pic.h>
#include "delays.h"

void InitializeMSSP(void)
{
	//bRC3 = 1;  // set SCL  high
	//bRC4 = 1;  // set SDA  high
	bTRC3 = 1; // SCL - pin 8 (23) 
	bTRC4 = 1; // SDA - pin 9 (18)
	bCKE = 0; // levels conform to I2C specification
	bSMP = 1; // slew rate enabled for 400kHz mode

	SSPADD = 29; // 12 MHz/ (SSPADD + 1 )  = 400kHz
	
	bSSPM3 = 1; // I2C master mode
	bSSPM2 = 0;
	bSSPM1 = 0;
	bSSPM0 = 0;
	
	bSSPEN = 1; // enable MSSP
}

BYTE i2c_master_start(void) // returns a 1 on error
{
	BYTE n = 50, flag = 1;
	bSEN = 1;
	while (bSEN && --n);
	if (n)
		flag = 0;
	return (flag);
}

BYTE i2c_master_stop(void) // returns a 1 on error
{
	BYTE n = 50, flag = 1;
	bPEN = 1;
	while (bPEN && --n);
	if (n)
		flag= 0;
	return(flag);
}

BYTE i2c_master_out_byte(BYTE o_byte)  // returns a 1 on error
{
	BYTE n = 50, flag = 1;
	SSPBUF = o_byte;
	while (bBF && --n);
	if (n == 0)
		return(1);	
	n = 50;
	while (bACKSTAT && --n);	// cleared when the slave ack's
	if(n)
		flag = 0;
	return(flag);
}

BYTE i2c_master_in_byte(BYTE ack)
{
	bRCEN = 1;
	Wait(1);
	while(bRCEN);
	bACKDT = ack ? 0 : 1;
	bACKEN = 1;
	while(bACKEN);
	return(SSPBUF);
} 






