#include <P18F4550.h>
#include <P18F4550_bits.h>
#include <PortBits.h>

#define APROCFREQ 48000000

#define BITSIZE 16
#define BOOTADDRESS 0
#define FIRSTRAM 0x00
#define LASTRAM 0x7FF
#define HASOSCCAL 0
#define nPAGESRAM 1
#define nPAGESROM 1
//
// Header file - should be included in all C files used within the program
// This file is created automatically and should not be changed
//

//
// Functions
//
void UserInitialise();			// Your initialisation code
void UserInterrupt();			// Your interrupt code
void UserLoop();			// your Main loop code


// **********
//
// A/D converter 18x
//
// **********
#define AD18xBitUsed 1
void void done(void)();
#define ADEn 1
#define InChan 0
#define ADClock OscDiv2
#define ADnChan 1
#define vADFM 1
#define ADACQ TAd0
#define VRefSrcP VRef_Vdd
#define VRefSrcM VRef_Vss
#define A0Port PORTA
#define A0Bit 0
#define A1Port PORTA
#define A1Bit 1
#define A2Port PORTA
#define A2Bit 2
#define A3VRefPort PORTA
#define A3VRefBit 3
#define A4Port PORTA
#define A4Bit 5
#define A5Port PORTE
#define A5Bit 0
#define A6Port PORTE
#define A6Bit 1
#define A7Port PORTE
#define A7Bit 2
#define A8Port PORTB
#define A8Bit 2
#define A9Port PORTB
#define A9Bit 3
#define A10Port PORTB
#define A10Bit 1
#define A11Port PORTB
#define A11Bit 4
#define A12Port PORTB
#define A12Bit 0

// **********
//
// Application Designer Variables
//
// **********


// Defines specified by 1 or more elements

