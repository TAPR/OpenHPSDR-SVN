
///////////////////////////////////////////////////////////////////////////////
//
// 48kHz clock.c - test program for 18F4550 USB board
//
// 48kHz clock.hex should be loaded using USB boot loader
//
// Test program toggles LED4 on development board at 48kHz by 
// dividing 12MHz clock  by 2 and then x 
// To divide by x use the two's completment  of x and set TMR0 to that value. 
//  (e.g. to select  two's complement of x use (~x) + 1. 
// It will count up from that value until it overflows. On overflow it sets its 
// interupt flag which we can test for or use to create an interupt.
//
///////////////////////////////////////////////////////////////////////////////

// define use of Bootloader

const int MCBOOTLOADER = 1;

#include "delays.h"
#include <strings.h>
#include <datalib.h>
#include <pic.h>

#define D4 PD.B3		// LED D4 on development board 

#pragma udata

//private prototypes


// remap vectors to avoid USB boot loader
extern void _startup(void);
#pragma code _RESET_INTERRUPT_VECTOR = 0x000800
void _reset(void)
{
	#pragma asmline goto _startup
}

#pragma code

void main()
{
	
	PORTD = 0x00;  // set all port D outputs low
	TRISD = 0x00;  // set port D as output
	
	//set up timer 0  to divide 12MHz clock by 2
	
	bT0CS = 0; 		// select internal clock
	bT0SE = 0;		// increment on low to high transition
	bT08BIT = 1;		// select 8 bit counter
	//bPSA  = 0;				// use pre scaler
	
	bT0PS3 = 0;	// should be bPSA but not defined
	
	// set pre-scale to 2
	bT0PS2 = 0; bT0PS1 = 0; bT0PS0 = 0;
	
	bTMR0ON = 1;  // enable timer 0
	
	// ***** now do this using interupts *******
	
	while(1)
	{
		if (bTMR0IF)	// check if TMR0 interupt flag is set 
		{
			D4 = !D4;  // toggle LED
			TMR0L = (~83) +1;  // set TMR0 again
			bTMR0IF = 0; 
		}
	}
}

