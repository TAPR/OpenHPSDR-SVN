
///////////////////////////////////////////////////////////////////////////////
//
// 48kHz clock.c - test program for 18F4550 USB board
//
// 48kHz clock.hex should be loaded using USB boot loader
//
// Test program toggles LED4 on development board at 48kHz by 
// dividing 20MHz clock  by n and then x 
// To divide by x use the two's completment  of x and set TMR0 to that value. 
//  (e.g. to select  two's complement of x use (~x) + 1. 
// It will count up from that value until it overflows. On overflow it 
// causes and interrupt. Inside the interrupt routine we set a flag
// that can be tested in the main loop. 
//
///////////////////////////////////////////////////////////////////////////////

// define use of Bootloader

const int MCBOOTLOADER = 1;

#include "delays.h"
#include <strings.h>
#include <datalib.h>
#include <pic.h>

#define LED4 PD.B3		// LED D4 on development board 

#pragma udata

//private prototypes
void Interrupt();		// define interupt routine

// remap vectors to avoid USB boot loader
extern void _startup(void);
#pragma code _RESET_INTERRUPT_VECTOR = 0x000800
void _reset(void)
{
	#pragma asmline goto _startup
}

#pragma code

BYTE Flag;  // ****** IMPORTANT CHANGE TO ' byte'  when using USB code ********

void main()
{
	PORTD = 0x00;  // set all port D outputs low
	TRISD = 0x00;  // set port D as output
	
	//set up timer 0  to divide 5MHz clock by 2
	
	bT0CS = 0; 		// select internal clock
	bT0SE = 0;		// increment on low to high transition
	bT08BIT = 1;	// select 8 bit counter
	//bPSA  = 0;			 // use pre scaler
	
	bT0PS3 = 0;	// should be bPSA but not defined
	
	// setTMR0  pre-scale to 2
	bT0PS2 = 0; bT0PS1 = 0; bT0PS0 = 0;
	
	bTMR0ON = 1;  // enable timer 0
	
	bT0IE = 1; 		// enable TMR0 interrupts
	bGIE  = 1;		// enable interrupts
	
	while(1)
	{
		if (Flag)	// check if TMR0 interrupt flag is set 
		{
			LED4 = !LED4; 	// toggle LED
			Flag = 0;  		// reset timer flag 
		}
	}
}

void Interrupt()
{
	 if (bTMR0IF)
	 {
	  	bTMR0IF = 0;		// reset TMR0 interrupt flag
	  	TMR0L = (~118) +1;  // set TMR0 - gives 48KHz with my Xtal
	  	Flag=1;				// Set flag to show 1/48kHz has passed
	 }
}

