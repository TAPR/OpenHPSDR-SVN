#include "C:\\My Documents\\PIC\\I2C WIZ\\I2C WIZ_Auto.h"

//
// This file includes all user definable routines. It may be changed at will as
// it will not be regenerated once the application has been generated for the
// first time.
//

#include "delays.h"

//*******************************************************************************
//
// Insert your interrupt handling code if required here. 
// Note quick interrupts are used so code must be simple
// See the manual for details of quick interrupts.
//

void UserInterrupt()
{
	// Insert your code here

 #asmline goto UserIntReturn	; PIC Assembler - go back to interrupt routine
}


//*******************************************************************************
//
// Insert your initialisation code if required here. 
// Note that when this routine is called Interrupts will not be enabled - the 
// Application Designer will enable them before the main loop
//

void UserInitialise()
{
/*
// set SDA data bit to drive
	bRB0 = 1; 
	bTRB0 = 0;
// set SCL data bit to drive
	bRB1 = 1;
	bTRB1 = 0;
*/
}

//*******************************************************************************
//
// Insert your main loop code if required here. This routine will be called
// as part of the main loop code
//

void UserLoop()
{
// write to I2C port

	BYTE got = 1;


	
	IIWrite(0x00,IISTART);  // send address and write
	IIWrite(0x55,IIACK);	// send data 
	got = IIWrite(0x0A,IISTOP);  // send data and stop
	while(1);
	
}
