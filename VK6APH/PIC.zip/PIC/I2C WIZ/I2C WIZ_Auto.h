#include <P18F4550.h>
#include <P18F4550_bits.h>
#include <PortBits.h>
#include <datalib.h>

#define APROCFREQ 48000000

#define BITSIZE 16
#define BOOTADDRESS 0
#define FIRSTRAM 0x00
#define LASTRAM 0x7FF
#define HASOSCCAL 0
#define nPAGESRAM 1
#define nPAGESROM 1
//
// Header file - should be included in all C files used within the program
// This file is created automatically and should not be changed
//

//
// Functions
//
void UserInitialise();			// Your initialisation code
void UserInterrupt();			// Your interrupt code
void UserLoop();			// your Main loop code


// **********
//
// I2C bus driver - software driven
//
// **********
#define IICUsed 1
#define SDAPort PORTB
#define SDABit 0
#define SCLPort PORTB
#define SCLBit 1

// **********
//
// Application Designer Variables
//
// **********


// Defines specified by 1 or more elements

