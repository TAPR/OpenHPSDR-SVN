#include "C:\\My Documents\\PIC\\I2C WIZ\\I2C WIZ_Auto.h"


// *** Input File - C:\PROGRA~1\FED\PIXIE\APPWIZ\APPWIZ18\misc.c

#ifdef IICUsed
void IIInit()
{
 IIRead(IISTOP);
}
#endif

		








		








                                                        
