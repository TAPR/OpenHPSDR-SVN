
///////////////////////////////////////////////////////////////////////////////
//
// test_v4.c - test program for 18F4550 USB board
//
// test.hex should be loaded using USB boot loader
// Pressing button S3 toggles the state of the D4 led
// Each time the button is pressed  "Hello World!" and an  ASCII character is 
// send to the serial port at 115200 baud. The charater
// starts at 0 and the ASCII value is incremented each time.
// Uses the hardware USART. 
// Also reads a 10 bit A/D voltage on Port A bit 0 and
// passes this to the 10 bit PWM on Port C pin 2. Connect a
// potentiomneter on  Port A pin 0 and a PWM voltmeter
// on Port C pin 2 to test this. Note that the PWM seems to have
// 8 bits and not 10 bits of resolution - this may be a 
// simulator bug. 
//
///////////////////////////////////////////////////////////////////////////////

// define use of Bootloader

const int MCBOOTLOADER = 1;

#include "delays.h"
//#include <FEDC18.h>
#include <strings.h>
#include <datalib.h>
#include <pic.h>

#define S2 !PB.B4		// push button S2 on development board
#define S3 !PB.B5		// push button S3 on development board
#define D4 PD.B3		// LED D4 on development board 

#pragma udata

//private prototypes
void InitializeUSART(void);
void send(char Data);
#asmfunc send(char Data)		// set fnprintf function

// remap vectors to avoid USB boot loader

extern void _startup(void);
#pragma code _RESET_INTERRUPT_VECTOR = 0x000800
void _reset(void)
{
	#pragma asmline goto _startup
}

#pragma code

int ad_data;
int last_data;
BYTE pwmh;

void main()
{
	BYTE  i = '0';

	InitializeUSART(); // intialize serial port

	PORTD = 0x00;  // set all port D outputs low
	TRISD = 0x00;  // set port D as output
	bTRB4 = 1;	   // set port B bit 4 as input for push button S2
	bTRB5 = 1;	   // set port B bit 5 as input  for push button S3
	
	// set up A/D converter
	bTRA0 = 1; 	   // set port A bit 0 as input for A/D
	ADCON1 = 0x0E; // set AN0 as input and VSS, VDD as ref
	ADCON0 = 0x01; // select channel 0 and turn A/D on
	ADCON2 = 0x00; // left justified, TAD, Fosc/2
	
	// set up PWM 
	bTRC2 = 0;	   // set port C 2 as output for  PWM 
	CCP1CON = 0b00001100; // PWM LSB1 = LSB0 = 0
	//bCCP1M0 = 0;
	PR2 = 0xFF;    // set 10 bit PWM resolution 
	TMR2 = 0x00;   // set TMR2 sets period 
	T2CON = 0x00;  // 
	bTMR2ON = 1;   // turn TMR2 on 
	bT2CKPS1 = 0; bT2CKPS0 = 0; 
	
	
	struct DUTY
	{
		BYTE hi8;	// high 8  bits of duty cycle
		BYTE lo2;	// low 2 bits in the highest 2 bits
	}
	struct DUTY duty;

	while(1)
	{
		if (S3)		// if button S3 is pressed
		{
			while(S3);				// wait for button to be released
			//Wait(50); 				// debounce button for 50mS
			D4 = !D4; 				// toggle Led 
			fnprintf(send,"\n %s %c %", "Hello World!", i);	// % at end prevents \0 being sent ! 
			i++; 
		}
		
		// get A/D value and send to terminal
		bGO = 1;		// start A/D conversion 
		while (!bGO);	// wait for A/D conversion to be done
		//PORTD = ADRESH; 
		ad_data = ADRESH; 
		ad_data = ad_data << 2 | ADRESL >> 6 ;
		if (ad_data != last_data)  // only print if data has changed
		{
			fnprintf(send," A/D result = %2x \n%", ad_data);
			last_data = ad_data;
		}
		
		duty.hi8 = ADRESH;
		duty.lo2 = ADRESL;
		CCPR1L = duty.hi8;	// high 8 bits
		
		bCCP1X = 0; bCCP1Y = 0; // low bits
		if (duty.lo2 & 0x80)
			bCCP1X = 1;
		if (duty.lo2 & 0x40)
			bCCP1Y = 1; 
	}
}

