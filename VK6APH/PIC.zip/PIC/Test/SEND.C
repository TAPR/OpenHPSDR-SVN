/////////////////////////////////////////////////////////////////////////////////
//
//  function sends char in Data to USART hardware
//
/////////////////////////////////////////////////////////////////////////////////

#include <pic.h>

void send(char  Data)
{
		while (!bTXIF);			// wait until USART is ready 
			TXREG = Data;		// send data to terminal 
}

///////////////////////////////////////////////////////////////////////////////////
//
//  function initilaze USART hardware
//
//////////////////////////////////////////////////////////////////////////////////

void InitializeUSART(void)
{
	bRC6 = 1;
	//TRISCbits.TRISC7=1; // Rx
	//TRISCbits.TRISC6=0; // Tx
	bTRC7 = 1;
	bTRC6 = 0;
	SPBRG  = 0x68;		
	SPBRGH = 0x00;		// set 115200 baud for 48MHz clock
	TXSTA  = 0x24;		// Tx enable BRGH = 1
	RCSTA  = 0x90; 		// continous Rx
	//BAUDCON = 0x08;		// BRG16 = 1
	BAUDCTL = 0x08; 	// BRG16 = 1
}
