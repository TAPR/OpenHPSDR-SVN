
///////////////////////////////////////////////////////////////////////////////
//
// test.c - test program for 18F4550 USB board
//
// test.hex should be loaded using USB boot loader
// Pressing button S3 toggles the state of the D4 led
// Each time the button is pressed  "Hello World!" and and  ASCII character is 
// send to the serial port at 115200 baud. The charater
// starts at 0 and the ASCII value is incremented each time.
// Uses the hardware USART 
//
///////////////////////////////////////////////////////////////////////////////

// define use of Bootloader

const int MCBOOTLOADER = 1;

#include "delays.h"
//#include <FEDC18.h>
#include <strings.h>
#include <datalib.h>
#include <pic.h>

#define S2 !PB.B4		// push button S2 on development board
#define S3 !PB.B5		// push button S3 on development board
#define D4 PD.B3		// LED D4 on development board 

#pragma udata

//private prototypes
void InitializeUSART(void);
void send(char Data);
#asmfunc send(char Data)		// set fnprintf function

// remap vectors to avoid USB boot loader

extern void _startup(void);
#pragma code _RESET_INTERRUPT_VECTOR = 0x000800
void _reset(void)
{
	#pragma asmline goto _startup
}

#pragma code

void main()
{
	BYTE  i = '0';

	InitializeUSART(); // intialize serial port

	PORTD = 0x00;  // set all port D outputs low
	TRISD = 0x00;  // set port D as output
	bTRB4 = 1;	   // set port B bit 4 as input for push button S2
	bTRB5 = 1;	   // set port B bit 5 as input  for push button S3

	while(1)
	{
		if (S3)		// if button S3 is pressed
		{
			while(S3);				// wait for button to be released
			//Wait(50); 				// debounce button for 50mS
			D4 = !D4; 				// toggle Led 
			fnprintf(send,"\n %s %c %", "Hello World!", i);	// % at end prevents \0 being sent ! 
			i++; 
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////
//
//  function sends char in Data to USART hardware
//
/////////////////////////////////////////////////////////////////////////////////
void send(char  Data)
{
		while (!bTXIF);			// wait until USART is ready 
			TXREG = Data;		// send data to terminal 
}

///////////////////////////////////////////////////////////////////////////////////
//
//  function initilaze USART hardware
//
//////////////////////////////////////////////////////////////////////////////////

void InitializeUSART(void)
{
	bRC6 = 1;
	//TRISCbits.TRISC7=1; // Rx
	//TRISCbits.TRISC6=0; // Tx
	bTRC7 = 1;
	bTRC6 = 0;
	SPBRG  = 0x68;		
	SPBRGH = 0x00;		// set 115200 baud for 48MHz clock
	TXSTA  = 0x24;		// Tx enable BRGH = 1
	RCSTA  = 0x90; 		// continous Rx
	//BAUDCON = 0x08;		// BRG16 = 1
	BAUDCTL = 0x08; 	// BRG16 = 1
}
