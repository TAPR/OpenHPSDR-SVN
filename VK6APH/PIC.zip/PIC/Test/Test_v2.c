
///////////////////////////////////////////////////////////////////////////////
//
// test.c - test program for 18F4550 USB board
//
// test.hex should be loaded using USB boot loader
// Pressing button S3 toggles the state of the D4 led
// Each time the button is pressed  "Hello World!" and and  ASCII character is 
// send to the serial port at 115200 baud. The charater
// starts at 0 and the ASCII value is incremented each time.
//
///////////////////////////////////////////////////////////////////////////////

// define use of Bootloader

const int MCBOOTLOADER = 1;

#include "delays.h"
//#include <FEDC18.h>
#include <strings.h>		// needed by printf
#include <datalib.h>		// needed by pSerialOut
#include <pic.h>

// set up software serial port on Port c pin 6
const long SERIALRATE_OUT = 115000;
const int BITTIME_OUT = (48000*1000)/SERIALRATE_OUT/4;
const BYTE SERIALPORT_OUT = &PORTC;
const BYTE SERIALBIT_OUT = 6;



#define S2 !PB.B4		// push button S2 on development board
#define S3 !PB.B5		// push button S3 on development board
#define D4 PD.B3		// LED D4 on development board 

#pragma callfunction pSerialOut		// set fnprintf function

#pragma udata

//private prototypes

// remap vectors to avoid USB boot loader

extern void _startup(void);
#pragma code _RESET_INTERRUPT_VECTOR = 0x000800
void _reset(void)
{
	#pragma asmline goto _startup
}

#pragma code

void main()
{

// ***** WARNING - Port settings have to be inside main()  *********
PORTD = 0x00;  // set all port D outputs low
TRISD = 0x00;  // set port D as output
bTRB4 = 1;	   // set port B bit 4 as input for push button S2
bTRB5 = 1;	   // set port B bit 5 as input  for push button S3
bRC6 = 1;	   // set UART bit high 
bTRC6 = 0; 	   // Tx

BYTE  i = '0';

while(1)
	{
		if (S3)						// if button S3 is pressed
		{
			while(S3);				// wait for button to be released
			//Wait(50); 								// debounce button for 50mS
			D4 = !D4; 				// toggle Led 
			//pSerialOut(i);
			printf("\n %s %c %", "Hello World!", i);	// % at end prevents \0 being sent ! 
			i++; 
		}
	}
}


