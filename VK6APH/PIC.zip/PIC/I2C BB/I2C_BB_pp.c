#line 1 "C:/Program Files/FED/PIXIE/PreProc.C"
#line 3 "C:/Program Files/FED/PIXIE/Libs/ProcIncs/P16F877.h"
typedef unsigned char BYTE;
typedef unsigned char FileReg;
typedef unsigned int WORD;
typedef unsigned long ulong;
#line 65
extern FileReg INDF ;
#pragma locate INDF 0x0000
extern FileReg TMR0 ;
#pragma locate TMR0 0x0001
extern FileReg PCL ;
#pragma locate PCL 0x0002
extern FileReg STATUS ;
#pragma locate STATUS 0x0003
extern FileReg FSR ;
#pragma locate FSR 0x0004
extern FileReg PORTA ;
#pragma locate PORTA 0x0005
extern FileReg PORTB ;
#pragma locate PORTB 0x0006
extern FileReg PORTC ;
#pragma locate PORTC 0x0007
extern FileReg PORTD ;
#pragma locate PORTD 0x0008
extern FileReg PORTE ;
#pragma locate PORTE 0x0009
extern FileReg PCLATH ;
#pragma locate PCLATH 0x000A
extern FileReg INTCON ;
#pragma locate INTCON 0x000B
extern FileReg PIR1 ;
#pragma locate PIR1 0x000C
extern FileReg PIR2 ;
#pragma locate PIR2 0x000D
extern FileReg TMR1L ;
#pragma locate TMR1L 0x000E
extern FileReg TMR1H ;
#pragma locate TMR1H 0x000F
extern FileReg T1CON ;
#pragma locate T1CON 0x0010
extern FileReg TMR2 ;
#pragma locate TMR2 0x0011
extern FileReg T2CON ;
#pragma locate T2CON 0x0012
extern FileReg SSPBUF ;
#pragma locate SSPBUF 0x0013
extern FileReg SSPCON ;
#pragma locate SSPCON 0x0014
extern FileReg CCPR1L ;
#pragma locate CCPR1L 0x0015
extern FileReg CCPR1H ;
#pragma locate CCPR1H 0x0016
extern FileReg CCP1CON ;
#pragma locate CCP1CON 0x0017
extern FileReg RCSTA ;
#pragma locate RCSTA 0x0018
extern FileReg TXREG ;
#pragma locate TXREG 0x0019
extern FileReg RCREG ;
#pragma locate RCREG 0x001A
extern FileReg CCPR2L ;
#pragma locate CCPR2L 0x001B
extern FileReg CCPR2H ;
#pragma locate CCPR2H 0x001C
extern FileReg CCP2CON ;
#pragma locate CCP2CON 0x001D
extern FileReg ADRESH ;
#pragma locate ADRESH 0x001E
extern FileReg ADCON0 ;
#pragma locate ADCON0 0x001F
extern FileReg OPTION_REG ;
#pragma locate OPTION_REG 0x0081
extern FileReg TRISA ;
#pragma locate TRISA 0x0085
extern FileReg TRISB ;
#pragma locate TRISB 0x0086
extern FileReg TRISC ;
#pragma locate TRISC 0x0087
extern FileReg TRISD ;
#pragma locate TRISD 0x0088
extern FileReg TRISE ;
#pragma locate TRISE 0x0089
extern FileReg PIE1 ;
#pragma locate PIE1 0x008C
extern FileReg PIE2 ;
#pragma locate PIE2 0x008D
extern FileReg PCON ;
#pragma locate PCON 0x008E
extern FileReg SSPCON2 ;
#pragma locate SSPCON2 0x0091
extern FileReg PR2 ;
#pragma locate PR2 0x0092
extern FileReg SSPADD ;
#pragma locate SSPADD 0x0093
extern FileReg SSPSTAT ;
#pragma locate SSPSTAT 0x0094
extern FileReg TXSTA ;
#pragma locate TXSTA 0x0098
extern FileReg SPBRG ;
#pragma locate SPBRG 0x0099
extern FileReg ADRESL ;
#pragma locate ADRESL 0x009E
extern FileReg ADCON1 ;
#pragma locate ADCON1 0x009F
extern FileReg EEDATA ;
#pragma locate EEDATA 0x010C
extern FileReg EEADR ;
#pragma locate EEADR 0x010D
extern FileReg EEDATH ;
#pragma locate EEDATH 0x010E
extern FileReg EEADRH ;
#pragma locate EEADRH 0x010F
extern FileReg EECON1 ;
#pragma locate EECON1 0x018C
extern FileReg EECON2 ;
#pragma locate EECON2 0x018D

enum T_STATUS {
IRP =0x0007,RP1 =0x0006,RP0 =0x0005,NOT_TO =0x0004,NOT_PD =0x0003,Z =0x0002,DC =0x0001,C =0x0000
};

enum T_INTCON {
GIE =0x0007,PEIE =0x0006,T0IE =0x0005,INTE =0x0004,RBIE =0x0003,T0IF =0x0002,INTF =0x0001,RBIF =0x0000
};

enum T_PIR1 {
PSPIF =0x0007,ADIF =0x0006,RCIF =0x0005,TXIF =0x0004,SSPIF =0x0003,CCP1IF =0x0002,TMR2IF =0x0001,TMR1IF =0x0000
};

enum T_PIR2 {
EEIF =0x0004,BCLIF =0x0003,CCP2IF =0x0000
};

enum T_T1CON {
T1CKPS1 =0x0005,T1CKPS0 =0x0004,T1OSCEN =0x0003,NOT_T1SYNC =0x0002,TMR1CS =0x0001,TMR1ON =0x0000
};

enum T_T2CON {
TOUTPS3 =0x0006,TOUTPS2 =0x0005,TOUTPS1 =0x0004,TOUTPS0 =0x0003,TMR2ON =0x0002,T2CKPS1 =0x0001,T2CKPS0 =0x0000
};

enum T_SSPCON {
WCOL =0x0007,SSPOV =0x0006,SSPEN =0x0005,CKP =0x0004,SSPM3 =0x0003,SSPM2 =0x0002,SSPM1 =0x0001,SSPM0 =0x0000
};

enum T_CCP1CON {
CCP1X =0x0005,CCP1Y =0x0004,CCP1M3 =0x0003,CCP1M2 =0x0002,CCP1M1 =0x0001,CCP1M0 =0x0000
};

enum T_RCSTA {
SPEN =0x0007,RX9 =0x0006,SREN =0x0005,CREN =0x0004,ADDEN =0x0003,FERR =0x0002,OERR =0x0001,RX9D =0x0000
};

enum T_CCP2CON {
CCP2X =0x0005,CCP2Y =0x0004,CCP2M3 =0x0003,CCP2M2 =0x0002,CCP2M1 =0x0001,CCP2M0 =0x0000
};

enum T_ADCON0 {
ADCS1 =0x0007,ADCS0 =0x0006,CHS2 =0x0005,CHS1 =0x0004,CHS0 =0x0003,GO =0x0002,CHS3 =0x0001,ADON =0x0000
};

enum T_OPTION {
NOT_RBPU =0x0007,INTEDG =0x0006,T0CS =0x0005,T0SE =0x0004,PSA =0x0003,PS2 =0x0002,PS1 =0x0001,PS0 =0x0000
};

enum T_TRISE {
IBF =0x0007,OBF =0x0006,IBOV =0x0005,PSPMODE =0x0004,TRISE2 =0x0002,TRISE1 =0x0001,TRISE0 =0x0000
};

enum T_PIE1 {
PSPIE =0x0007,ADIE =0x0006,RCIE =0x0005,TXIE =0x0004,SSPIE =0x0003,CCP1IE =0x0002,TMR2IE =0x0001,TMR1IE =0x0000
};

enum T_PIE2 {
EEIE =0x0004,BCLIE =0x0003,
CCP2IE =0x0000
};

enum T_PCON {
NOT_POR =0x0001,NOT_BO =0x0000
};

enum T_SSPCON2 {
GCEN =0x0007,ACKSTAT =0x0006,ACKDT =0x0005,ACKEN =0x0004,RCEN =0x0003,PEN =0x0002,RSEN =0x0001 ,SEN =0x0000
};

const unsigned char SMP =0x0007;
const unsigned char CKE =0x0006;
const unsigned char D =0x0005;
const unsigned char I2C_DATA =0x0005;
const unsigned char NOT_A =0x0005;
const unsigned char NOT_ADDRESS =0x0005;
const unsigned char D_A =0x0005;
const unsigned char DATA_ADDRESS =0x0005;
const unsigned char P =0x0004;
const unsigned char I2C_STOP =0x0004;
const unsigned char S =0x0003;
const unsigned char I2C_START =0x0003;
const unsigned char R =0x0002;
const unsigned char I2C_READ =0x0002;
const unsigned char NOT_W =0x0002;
const unsigned char NOT_WRITE =0x0002;
const unsigned char R_W =0x0002;
const unsigned char READ_WRITE =0x0002;
const unsigned char UA =0x0001;
const unsigned char BF =0x0000;
#line 267
enum T_TXSTA {
CSRC =0x0007,TX9 =0x0006,TXEN =0x0005,SYNC =0x0004,BRGH =0x0002,TRMT =0x0001,TX9D =0x0000
};

enum T_ADCON1 {
ADFM =0x0007,PCFG3 =0x0003,PCFG2 =0x0002,PCFG1 =0x0001,PCFG0 =0x0000
};

enum T_EECON1 {
EEPGD =0x0007,WRERR =0x0003,WREN =0x0002,WR =0x0001,RD =0x0000
};
#line 281
struct sPort
{
unsigned char B0:1;
unsigned char B1:1;
unsigned char B2:1;
unsigned char B3:1;
unsigned char B4:1;
unsigned char B5:1;
unsigned char B6:1;
unsigned char B7:1;
};

extern sPort PA;
#pragma locate PA 5
extern sPort PB;
#pragma locate PB 6
extern sPort PC;
#pragma locate PC 7
extern sPort PD;
#pragma locate PD 8
extern sPort PE;
#pragma locate PE 9
#line 9 "C:/Program Files/FED/PIXIE/Libs/PortBits.h"
extern bit bRA0,bRA1,bRA2,bRA3,bRA4,bRA5,bRA6,bRA7;
extern bit bTRA0,bTRA1,bTRA2,bTRA3,bTRA4,bTRA5,bTRA6,bTRA7;
extern bit bRB0,bRB1,bRB2,bRB3,bRB4,bRB5,bRB6,bRB7;
extern bit bTRB0,bTRB1,bTRB2,bTRB3,bTRB4,bTRB5,bTRB6,bTRB7;
extern bit bRC0,bRC1,bRC2,bRC3,bRC4,bRC5,bRC6,bRC7;
extern bit bTRC0,bTRC1,bTRC2,bTRC3,bTRC4,bTRC5,bTRC6,bTRC7;
extern bit bRD0,bRD1,bRD2,bRD3,bRD4,bRD5,bRD6,bRD7;
extern bit bTRD0,bTRD1,bTRD2,bTRD3,bTRD4,bTRD5,bTRD6,bTRD7;
extern bit bRE0,bRE1,bRE2,bRE3,bRE4,bRE5,bRE6,bRE7;
extern bit bTRE0,bTRE1,bTRE2,bTRE3,bTRE4,bTRE5,bTRE6,bTRE7;
#line 21
#pragma locate bRA0 5,0
#pragma locate bRA1 5,1
#pragma locate bRA2 5,2
#pragma locate bRA3 5,3
#pragma locate bRA4 5,4
#pragma locate bRA5 5,5
#pragma locate bRA6 5,6
#pragma locate bRA7 5,7
#pragma locate bRB0 6,0
#pragma locate bRB1 6,1
#pragma locate bRB2 6,2
#pragma locate bRB3 6,3
#pragma locate bRB4 6,4
#pragma locate bRB5 6,5
#pragma locate bRB6 6,6
#pragma locate bRB7 6,7
#pragma locate bRC0 7,0
#pragma locate bRC1 7,1
#pragma locate bRC2 7,2
#pragma locate bRC3 7,3
#pragma locate bRC4 7,4
#pragma locate bRC5 7,5
#pragma locate bRC6 7,6
#pragma locate bRC7 7,7
#pragma locate bRD0 8,0
#pragma locate bRD1 8,1
#pragma locate bRD2 8,2
#pragma locate bRD3 8,3
#pragma locate bRD4 8,4
#pragma locate bRD5 8,5
#pragma locate bRD6 8,6
#pragma locate bRD7 8,7
#pragma locate bRE0 9,0
#pragma locate bRE1 9,1
#pragma locate bRE2 9,2
#pragma locate bRE3 9,3
#pragma locate bRE4 9,4
#pragma locate bRE5 9,5
#pragma locate bRE6 9,6
#pragma locate bRE7 9,7
#pragma locate bTRA0 0x85,0
#pragma locate bTRA1 0x85,1
#pragma locate bTRA2 0x85,2
#pragma locate bTRA3 0x85,3
#pragma locate bTRA4 0x85,4
#pragma locate bTRA5 0x85,5
#pragma locate bTRA6 0x85,6
#pragma locate bTRA7 0x85,7
#pragma locate bTRB0 0x86,0
#pragma locate bTRB1 0x86,1
#pragma locate bTRB2 0x86,2
#pragma locate bTRB3 0x86,3
#pragma locate bTRB4 0x86,4
#pragma locate bTRB5 0x86,5
#pragma locate bTRB6 0x86,6
#pragma locate bTRB7 0x86,7
#pragma locate bTRC0 0x87,0
#pragma locate bTRC1 0x87,1
#pragma locate bTRC2 0x87,2
#pragma locate bTRC3 0x87,3
#pragma locate bTRC4 0x87,4
#pragma locate bTRC5 0x87,5
#pragma locate bTRC6 0x87,6
#pragma locate bTRC7 0x87,7
#pragma locate bTRD0 0x88,0
#pragma locate bTRD1 0x88,1
#pragma locate bTRD2 0x88,2
#pragma locate bTRD3 0x88,3
#pragma locate bTRD4 0x88,4
#pragma locate bTRD5 0x88,5
#pragma locate bTRD6 0x88,6
#pragma locate bTRD7 0x88,7
#pragma locate bTRE0 0x89,0
#pragma locate bTRE1 0x89,1
#pragma locate bTRE2 0x89,2
#pragma locate bTRE3 0x89,3
#pragma locate bTRE4 0x89,4
#pragma locate bTRE5 0x89,5
#pragma locate bTRE6 0x89,6
#pragma locate bTRE7 0x89,7
#line 5 "C:/Program Files/FED/PIXIE/Libs/ProcIncs/P16F877_bits.h"
extern bit bC;
#pragma locate bC &STATUS,0x00
extern bit bDC;
#pragma locate bDC &STATUS,0x01
extern bit bIRP;
#pragma locate bIRP &STATUS,0x07
extern bit bNOT_PD;
#pragma locate bNOT_PD &STATUS,0x03
extern bit bNOT_TO;
#pragma locate bNOT_TO &STATUS,0x04
extern bit bRP0;
#pragma locate bRP0 &STATUS,0x05
extern bit bRP1;
#pragma locate bRP1 &STATUS,0x06
extern bit bZ;
#pragma locate bZ &STATUS,0x02

extern bit bGIE;
#pragma locate bGIE &INTCON,0x07
extern bit bINTE;
#pragma locate bINTE &INTCON,0x04
extern bit bINTF;
#pragma locate bINTF &INTCON,0x01
extern bit bPEIE;
#pragma locate bPEIE &INTCON,0x06
extern bit bRBIE;
#pragma locate bRBIE &INTCON,0x03
extern bit bRBIF;
#pragma locate bRBIF &INTCON,0x00
extern bit bT0IE;
#pragma locate bT0IE &INTCON,0x05
extern bit bT0IF;
#pragma locate bT0IF &INTCON,0x02

extern bit bADIF;
#pragma locate bADIF &PIR1,0x06
extern bit bCCP1IF;
#pragma locate bCCP1IF &PIR1,0x02
extern bit bPSPIF;
#pragma locate bPSPIF &PIR1,0x07
extern bit bRCIF;
#pragma locate bRCIF &PIR1,0x05
extern bit bSSPIF;
#pragma locate bSSPIF &PIR1,0x03
extern bit bTMR1IF;
#pragma locate bTMR1IF &PIR1,0x00
extern bit bTMR2IF;
#pragma locate bTMR2IF &PIR1,0x01
extern bit bTXIF;
#pragma locate bTXIF &PIR1,0x04

extern bit bBCLIF;
#pragma locate bBCLIF &PIR2,0x03
extern bit bCCP2IF;
#pragma locate bCCP2IF &PIR2,0x00
extern bit bEEIF;
#pragma locate bEEIF &PIR2,0x04

extern bit bNOT_T1SYNC;
#pragma locate bNOT_T1SYNC &T1CON,0x02
extern bit bT1CKPS0;
#pragma locate bT1CKPS0 &T1CON,0x04
extern bit bT1CKPS1;
#pragma locate bT1CKPS1 &T1CON,0x05
extern bit bT1INSYNC;
#pragma locate bT1INSYNC &T1CON,0x02
extern bit bT1OSCEN;
#pragma locate bT1OSCEN &T1CON,0x03
extern bit bTMR1CS;
#pragma locate bTMR1CS &T1CON,0x01
extern bit bTMR1ON;
#pragma locate bTMR1ON &T1CON,0x00

extern bit bT2CKPS0;
#pragma locate bT2CKPS0 &T2CON,0x00
extern bit bT2CKPS1;
#pragma locate bT2CKPS1 &T2CON,0x01
extern bit bTMR2ON;
#pragma locate bTMR2ON &T2CON,0x02
extern bit bTOUTPS0;
#pragma locate bTOUTPS0 &T2CON,0x03
extern bit bTOUTPS1;
#pragma locate bTOUTPS1 &T2CON,0x04
extern bit bTOUTPS2;
#pragma locate bTOUTPS2 &T2CON,0x05
extern bit bTOUTPS3;
#pragma locate bTOUTPS3 &T2CON,0x06

extern bit bCKP;
#pragma locate bCKP &SSPCON,0x04
extern bit bSSPEN;
#pragma locate bSSPEN &SSPCON,0x05
extern bit bSSPM0;
#pragma locate bSSPM0 &SSPCON,0x00
extern bit bSSPM1;
#pragma locate bSSPM1 &SSPCON,0x01
extern bit bSSPM2;
#pragma locate bSSPM2 &SSPCON,0x02
extern bit bSSPM3;
#pragma locate bSSPM3 &SSPCON,0x03
extern bit bSSPOV;
#pragma locate bSSPOV &SSPCON,0x06
extern bit bWCOL;
#pragma locate bWCOL &SSPCON,0x07

extern bit bCCP1M0;
#pragma locate bCCP1M0 &CCP1CON,0x00
extern bit bCCP1M1;
#pragma locate bCCP1M1 &CCP1CON,0x01
extern bit bCCP1M2;
#pragma locate bCCP1M2 &CCP1CON,0x02
extern bit bCCP1M3;
#pragma locate bCCP1M3 &CCP1CON,0x03
extern bit bCCP1X;
#pragma locate bCCP1X &CCP1CON,0x05
extern bit bCCP1Y;
#pragma locate bCCP1Y &CCP1CON,0x04

extern bit bADDEN;
#pragma locate bADDEN &RCSTA,0x03
extern bit bCREN;
#pragma locate bCREN &RCSTA,0x04
extern bit bFERR;
#pragma locate bFERR &RCSTA,0x02
extern bit bNOT_RC8;
#pragma locate bNOT_RC8 &RCSTA,0x06
extern bit bOERR;
#pragma locate bOERR &RCSTA,0x01
extern bit bRC8_9;
#pragma locate bRC8_9 &RCSTA,0x06
extern bit bRC9;
#pragma locate bRC9 &RCSTA,0x06
extern bit bRCD8;
#pragma locate bRCD8 &RCSTA,0x00
extern bit bRX9;
#pragma locate bRX9 &RCSTA,0x06
extern bit bRX9D;
#pragma locate bRX9D &RCSTA,0x00
extern bit bSPEN;
#pragma locate bSPEN &RCSTA,0x07
extern bit bSREN;
#pragma locate bSREN &RCSTA,0x05

extern bit bCCP2M0;
#pragma locate bCCP2M0 &CCP2CON,0x00
extern bit bCCP2M1;
#pragma locate bCCP2M1 &CCP2CON,0x01
extern bit bCCP2M2;
#pragma locate bCCP2M2 &CCP2CON,0x02
extern bit bCCP2M3;
#pragma locate bCCP2M3 &CCP2CON,0x03
extern bit bCCP2X;
#pragma locate bCCP2X &CCP2CON,0x05
extern bit bCCP2Y;
#pragma locate bCCP2Y &CCP2CON,0x04

extern bit bADCS0;
#pragma locate bADCS0 &ADCON0,0x06
extern bit bADCS1;
#pragma locate bADCS1 &ADCON0,0x07
extern bit bADON;
#pragma locate bADON &ADCON0,0x00
extern bit bCHS0;
#pragma locate bCHS0 &ADCON0,0x03
extern bit bCHS1;
#pragma locate bCHS1 &ADCON0,0x04
extern bit bCHS2;
#pragma locate bCHS2 &ADCON0,0x05
extern bit bCHS3;
#pragma locate bCHS3 &ADCON0,0x01
extern bit bGO;
#pragma locate bGO &ADCON0,0x02
extern bit bGO_DONE;
#pragma locate bGO_DONE &ADCON0,0x02
extern bit bNOT_DONE;
#pragma locate bNOT_DONE &ADCON0,0x02

extern bit bINTEDG;
#pragma locate bINTEDG &OPTION_REG,0x06
extern bit bNOT_RBPU;
#pragma locate bNOT_RBPU &OPTION_REG,0x07
extern bit bPS0;
#pragma locate bPS0 &OPTION_REG,0x00
extern bit bPS1;
#pragma locate bPS1 &OPTION_REG,0x01
extern bit bPS2;
#pragma locate bPS2 &OPTION_REG,0x02
extern bit bPSA;
#pragma locate bPSA &OPTION_REG,0x03
extern bit bT0CS;
#pragma locate bT0CS &OPTION_REG,0x05
extern bit bT0SE;
#pragma locate bT0SE &OPTION_REG,0x04

extern bit bIBF;
#pragma locate bIBF &TRISE,0x07
extern bit bIBOV;
#pragma locate bIBOV &TRISE,0x05
extern bit bOBF;
#pragma locate bOBF &TRISE,0x06
extern bit bPSPMODE;
#pragma locate bPSPMODE &TRISE,0x04
extern bit bTRISE0;
#pragma locate bTRISE0 &TRISE,0x00
extern bit bTRISE1;
#pragma locate bTRISE1 &TRISE,0x01
extern bit bTRISE2;
#pragma locate bTRISE2 &TRISE,0x02

extern bit bADIE;
#pragma locate bADIE &PIE1,0x06
extern bit bCCP1IE;
#pragma locate bCCP1IE &PIE1,0x02
extern bit bPSPIE;
#pragma locate bPSPIE &PIE1,0x07
extern bit bRCIE;
#pragma locate bRCIE &PIE1,0x05
extern bit bSSPIE;
#pragma locate bSSPIE &PIE1,0x03
extern bit bTMR1IE;
#pragma locate bTMR1IE &PIE1,0x00
extern bit bTMR2IE;
#pragma locate bTMR2IE &PIE1,0x01
extern bit bTXIE;
#pragma locate bTXIE &PIE1,0x04

extern bit bBCLIE;
#pragma locate bBCLIE &PIE2,0x03
extern bit bCCP2IE;
#pragma locate bCCP2IE &PIE2,0x00
extern bit bEEIE;
#pragma locate bEEIE &PIE2,0x04

extern bit bNOT_BO;
#pragma locate bNOT_BO &PCON,0x00
extern bit bNOT_BOR;
#pragma locate bNOT_BOR &PCON,0x00
extern bit bNOT_POR;
#pragma locate bNOT_POR &PCON,0x01

extern bit bACKDT;
#pragma locate bACKDT &SSPCON2,0x05
extern bit bACKEN;
#pragma locate bACKEN &SSPCON2,0x04
extern bit bACKSTAT;
#pragma locate bACKSTAT &SSPCON2,0x06
extern bit bGCEN;
#pragma locate bGCEN &SSPCON2,0x07
extern bit bPEN;
#pragma locate bPEN &SSPCON2,0x02
extern bit bRCEN;
#pragma locate bRCEN &SSPCON2,0x03
extern bit bRSEN;
#pragma locate bRSEN &SSPCON2,0x01
extern bit bSEN;
#pragma locate bSEN &SSPCON2,0x00

extern bit bBF;
#pragma locate bBF &SSPSTAT,0x00
extern bit bCKE;
#pragma locate bCKE &SSPSTAT,0x06
extern bit bD;
#pragma locate bD &SSPSTAT,0x05
extern bit bD_A;
#pragma locate bD_A &SSPSTAT,0x05
extern bit bDATA_ADDRESS;
#pragma locate bDATA_ADDRESS &SSPSTAT,0x05
extern bit bI2C_DATA;
#pragma locate bI2C_DATA &SSPSTAT,0x05
extern bit bI2C_READ;
#pragma locate bI2C_READ &SSPSTAT,0x02
extern bit bI2C_START;
#pragma locate bI2C_START &SSPSTAT,0x03
extern bit bI2C_STOP;
#pragma locate bI2C_STOP &SSPSTAT,0x04
extern bit bNOT_A;
#pragma locate bNOT_A &SSPSTAT,0x05
extern bit bNOT_ADDRESS;
#pragma locate bNOT_ADDRESS &SSPSTAT,0x05
extern bit bNOT_W;
#pragma locate bNOT_W &SSPSTAT,0x02
extern bit bNOT_WRITE;
#pragma locate bNOT_WRITE &SSPSTAT,0x02
extern bit bP;
#pragma locate bP &SSPSTAT,0x04
extern bit bR;
#pragma locate bR &SSPSTAT,0x02
extern bit bR_W;
#pragma locate bR_W &SSPSTAT,0x02
extern bit bREAD_WRITE;
#pragma locate bREAD_WRITE &SSPSTAT,0x02
extern bit bS;
#pragma locate bS &SSPSTAT,0x03
extern bit bSMP;
#pragma locate bSMP &SSPSTAT,0x07
extern bit bUA;
#pragma locate bUA &SSPSTAT,0x01

extern bit bBRGH;
#pragma locate bBRGH &TXSTA,0x02
extern bit bCSRC;
#pragma locate bCSRC &TXSTA,0x07
extern bit bNOT_TX8;
#pragma locate bNOT_TX8 &TXSTA,0x06
extern bit bSYNC;
#pragma locate bSYNC &TXSTA,0x04
extern bit bTRMT;
#pragma locate bTRMT &TXSTA,0x01
extern bit bTX8_9;
#pragma locate bTX8_9 &TXSTA,0x06
extern bit bTX9;
#pragma locate bTX9 &TXSTA,0x06
extern bit bTX9D;
#pragma locate bTX9D &TXSTA,0x00
extern bit bTXD8;
#pragma locate bTXD8 &TXSTA,0x00
extern bit bTXEN;
#pragma locate bTXEN &TXSTA,0x05

extern bit bADFM;
#pragma locate bADFM &ADCON1,0x05
extern bit bPCFG0;
#pragma locate bPCFG0 &ADCON1,0x00
extern bit bPCFG1;
#pragma locate bPCFG1 &ADCON1,0x01
extern bit bPCFG2;
#pragma locate bPCFG2 &ADCON1,0x02
extern bit bPCFG3;
#pragma locate bPCFG3 &ADCON1,0x03

extern bit bEEPGD;
#pragma locate bEEPGD &EECON1,0x07
extern bit bRD;
#pragma locate bRD &EECON1,0x00
extern bit bWR;
#pragma locate bWR &EECON1,0x01
extern bit bWREN;
#pragma locate bWREN &EECON1,0x02
extern bit bWRERR;
#pragma locate bWRERR &EECON1,0x03
#line 1 "C:/My Documents/PIC/I2C BB/I2C_BB.h"
void i2c_setup_bb(void);
void i2c_high_sda(void);
void i2c_low_sda(void);
void i2c_high_scl(void);
void i2c_low_scl(void);
void delay50(void);
void i2c_setup_bb(void);
void i2c_start_bb(void);
void i2c_out_byte_bb(BYTE o_byte);
BYTE i2c_in_byte_bb(BYTE ack);
void i2c_stop_bb(void);
#line 19 "C:/MY DOCUMENTS/PIC/I2C BB/I2C_BB.c"
void delay50(void);

void delay50(void)
{
BYTE n = 0x01;
while (--n);
}
#line 29
void i2c_high_sda(void)
{

bTRB2 = 1;
delay50();
}

void i2c_low_sda(void)
{
bRB2 = 0;
bTRB2 = 0:
delay50();
}

void i2c_high_scl(void)
{
bTRB1 = 1;
delay50();
}

void i2c_low_scl(void)
{
bRB1 = 0;
bTRB1 = 0;
delay50();
}

void i2c_setup_bb(void)
{
i2c_high_sda();
i2c_high_scl();
}

void i2c_start_bb(void)
{
i2c_low_scl();
i2c_high_sda();
i2c_high_scl();
i2c_low_sda();
i2c_low_scl();
}

void i2c_out_byte_bb(BYTE o_byte)
{
BYTE n;
for (n = 0; n<8; n++)
{
if (o_byte & 0x80)
{
i2c_high_sda();
}
else
{
i2c_low_sda();
}
i2c_high_scl();
i2c_low_scl();
o_byte = o_byte << 1;
}
i2c_high_scl();
i2c_low_scl();
}

BYTE i2c_in_byte_bb(BYTE ack)
{
BYTE i_byte,n;
i2c_high_sda();
for (n = 0; n <8; n++)
{
i2c_high_scl();

if (bRB2)
{
i_byte = (i_byte << 1) | 0x01);
}
else
{
i_byte = i_byte << 1;
}
i2c_low_scl();
}

if (ack)
{
i2c_high_sda();
}

i2c_high_scl();
i2c_low_scl();

i2c_high_sda();

return (i_byte);
}

void i2c_stop_bb(void)
{
i2c_low_scl();
i2c_low_sda();
i2c_high_scl();
i2c_high_sda();

}
