#include <pic.h>
#include "i2c_bb.h"


void main(void)
{
	i2c_setup_bb();
	i2c_start_bb();
	i2c_out_byte_bb(0x00);
	i2c_out_byte_bb(0xAA);
	i2c_stop_bb();
	
	while (1); 

}
