
///////////////////////////////////////////////////////////////////////////////
//
//  Routines for bit bang I2C service
//
///////////////////////////////////////////////////////////////////////////////

#include <pic.h>
#include "i2c_bb.h"

// define pins to be used for SCL and SDA 

#define SDA_DIR bTRB2
#define SCL_DIR bTRB1

#define SDA_PIN bRB2
#define SCL_PIN bRB1

void delay50(void);	// sets SCL clock frequency

void delay50(void)
{
	BYTE n  = 0x01;
	while (--n);
}



void i2c_high_sda(void)
{
	// bring SDA to high impedance
	SDA_DIR = 1;
	delay50();
}

void i2c_low_sda(void)
{
	SDA_PIN = 0;
	SDA_DIR = 0:	// output a hard logic 0
	delay50();
}

void i2c_high_scl(void)
{
	SCL_DIR = 1; 	// high impedance
	delay50();
}

void i2c_low_scl(void)
{
	SCL_PIN = 0;
	SCL_DIR = 0;
	delay50();
}

void i2c_setup_bb(void)
{
	i2c_high_sda();
	i2c_high_scl();
}

void i2c_start_bb(void)
{
	i2c_low_scl();
	i2c_high_sda();
	i2c_high_scl();
	i2c_low_sda();
	i2c_low_scl();
}

void i2c_out_byte_bb(BYTE o_byte)
{
	BYTE n;
	for (n = 0; n<8; n++)
	{
		if (o_byte & 0x80) // test most significant bit
		{
			i2c_high_sda(); // set up SDA
		}
		else
		{
			i2c_low_sda();
		}
		i2c_high_scl();	// and clock out the data
		i2c_low_scl(); 
		o_byte = o_byte << 1;
	}
	i2c_high_scl();	// nack
	i2c_low_scl();
}

BYTE i2c_in_byte_bb(BYTE ack)
{	
	BYTE i_byte,n;
	i2c_high_sda();
	for (n = 0; n <8; n++)
	{
		i2c_high_scl();
		
		if (SDA_PIN)
		{
			i_byte = (i_byte << 1) | 0x01);  // msb first
		}
		else
		{
			i_byte = i_byte << 1;
		}
		i2c_low_scl();
	}
	
	if (ack) // if ack is desired, bring SDA  low for a clock pulse
	{
		i2c_high_sda();
	}
	
	i2c_high_scl(); // clock for ack or nack
	i2c_low_scl(); 
	
	i2c_high_sda(); // be sure to leave routine with SDA high
	
	return (i_byte);
}

void i2c_stop_bb(void)
{
	i2c_low_scl();
	i2c_low_sda();
	i2c_high_scl();
	i2c_high_sda(); // bring SDA high while SCL is high
	// idle is SDA high and SCL high
} 
	
