If there are any questions, please contact:

Lyle Johnson
18345 Osprey Court
Mount Vernon, WA  98274-7725

(360) 424-4971
lyle@kk7p.com

I need five (5) pieces.

This is a four (4) layer board.  
FR4
.062" thick


There are some important details on this fabrication.  See the enclosed PDF-format drawing for details.


The following files are included:

Readme.txt		This file
JANUS.APP		Aperture file
JANUS.BOT		Bottom layer
JANUS.DRD		Drill drawing
JANUS.DTS		Drill tape summary report
JANUS.GND		Ground plane
JANUS.GTD		Design file
JANUS.PWR		Power plane
JANUS.SMB		Bottom solder mask
JANUS.SMT		Top solder mask
JANUS.SST		Top silkscreen
JANUS.TAP		Drill file
JANUS.TOP		Top layer
JANUS.PDF		Drawing with important information on this fabrication.

Stack order:

Top silkscreen
Top solder mask
Top layer
Power plane
Ground plane
Bottom layer
Bottom solder mask

[end of file]

