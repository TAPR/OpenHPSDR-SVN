QS1R_REVAB

NOVEMBER 30, 2006
The Ohio State University
Department of Astronomy
Imaging Sciences Lab
4055 McPherson Laboratory
140 West 18th Avenue
Columbus, OH 43210-1173, USA

Contact: Phil Covington
614-247-4374
pcovington@astronomy.ohio-state.edu

Board Details:

No-touch
Layers: 4
Dimensions: X:6.000" x Y: 4.000"
Thickness: 0.062"
Material: FR4
Surface Finish: HAL
Outer Layer Copper Weight: 1 oz.
Inner Layer Copper Weight: 0.5 oz.
Solder Mask: LPI Both Sides, Green
Silkscreen: Top only, White
Layer Order: TOP,L2,L3,BOT
Min Trace Width: 7
Min Spacing: 7
Smallest Hole Size: 0.015"
Total Holes: 965
CNC route points: 4



