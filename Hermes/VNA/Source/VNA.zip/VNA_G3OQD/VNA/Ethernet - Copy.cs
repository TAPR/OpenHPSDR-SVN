﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using System.Diagnostics; 

namespace HermesVNAApplication
{
    class Ethernet
    {
        
        public static int GetNetworkInterfaces(ref string localIP, ref string[] IP_array)
        {

            IPHostEntry host;
            int adapter_number = 0;

            // get the IP addresses of the interface cards
            host = Dns.GetHostEntry(Dns.GetHostName());

            // get the name of the interface cards
            NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();

            var Adapter_to_IP = new List<string>();  // use a list since we don't know how many cards we have 

            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    ++adapter_number;
                    localIP += "[" + adapter_number.ToString() + "]  " + interfaces[adapter_number - 1].Description.ToString() +
                               " IP Address =  " + ip.ToString() + "\n";
                    Adapter_to_IP.Add(ip.ToString());  // save the adapter # and its IP address  
                }
            }

            IP_array = Adapter_to_IP.ToArray(); // convert to an array
            return (adapter_number);             // return number of adapters found
        }


        // Send two frames of 512 bytes to Hermes 
        public static void Ethernet_send(int state, bool run, Socket socket, string Hermes_IP_address, int SampleRate, int txLevel,
                                          byte OC_data, byte[] frequency, byte Drive_Level, bool Attenuator)                         
        {
                       
            #region how Ethernet_send works
            /*          
             
             Send frames to Ozy -- frames consist of 512 bytes as follows:
             <0x7f><0x7f><0x7f><C0><C1><C2><C3><C4><Left><Left><Right><Right><I><I><Q><Q><Left>..... 

             C0 bit 0 is "PTT"
             
             if CO = 0x0000_000x then
             C1 bits:
             7      Mic source: 0 = Janus, 1 = Penelope
             6,5    boards present:  00 neither, 01 Penelope, 10 Mercury, 11 both
             4      122.88MHz source: 0 Penelope, 1 Mercury
             3,2    10MHz ref source: 00 atlas, 01 Penelope, 10 Mercury
             1,0    sampling rate:    00 48kHz, 01 96kHz, 10 192 kHz
             * 
             C2 bits:
             7-1    Penelope open collector outputs 6-0
             0      xmt mode: 1 class E, 0 all other modes

             C3 bits:
             7    Alex Rx out: 0 off, 1 on
             6,5  Alex Rx antenna: 00 none, 01 Rx1, 10 Rx2, 11 XV
             4    Mercury ADC random: 0 off, 1 on
             3    Mercury ADC dither:  0 off, 1 on
             2    Mercury preamp: 0 off, 1 on
             1,0  Alex attenuator: 00 0dB, 01 10dB, 10 20dB, 11 30dB

             C4 bits
             7-3  unused
             1,0  Alex Tx relay: 00 Tx1, 01 Tx2, 10 Tx3
             2    1 = full duplex, 0 = simplex 
             if C4[2] = 0 and C0 = 0x0000_001x then C1..C4 hold frequency in Hz for Penny and Mercury, C1 = MSB
             if C4[2] = 1 and C0 = 0x0000_001x then C1..C4 hold frequency in Hz for Penny, C1 = MSB
             if C4[2] = 1 and C0 = 0x0000_010x then C1..C4 hold frequency in Hz for Mercury, C1 = MSB
             

             For a full description of the USB protocol see the document in \trunk\Documents
             */

            #endregion

            // state determines what C&C bits to send, 0 = sampling rate & attenuator state 
            // 1 = frequency,  2 =  drive level   

            if ((Hermes_IP_address == null) || (Hermes_IP_address.Length == 0))
            {
                // avoid errors if a hermes device is not connected.  this could happen if not connected and you read a calibration file
                return;
            }

            socket.SendBufferSize = 1032;

            // create an endpoint for sending to Hermes
            IPEndPoint HermesEP = new IPEndPoint(IPAddress.Parse(Hermes_IP_address), 1024);

            short I_data = 0;   
            short Q_data = 0;
            int frame_number = 0;
            int pntr; int x = 0;
            byte C0 = 0x00, C1 = 0x00, C2 = 0x00, C3 = 0x00, C4 = 0x00;
            const byte sync = 0x7F;
            int sequence_number = 0;

            byte[] to_Hermes = new byte[1024 + 8];       // array to send to Hermes via Ethernet, includes the 8 bytes before the data

            // Hermes uses Drive control - 0x00 to 0xFF

            // send 2 frames of 512 bytes for a total of 1024 bytes to Hermes via Ethernet
            for (frame_number = 0; frame_number < 2; frame_number++)
            {
                switch (state)
                {
                    case 0:
                        {
                            C0 = 0x00; C1 = 0x00; C2 = 0x00; C4 = 0x00;

                            // set sampling rate bits in C1
                            switch (SampleRate)
                            {
                                case 480000: break;
                                case 96000:
                                    C1 = (byte)(C1 | 0x01);
                                    break;
                                case 192000:
                                    C1 = (byte)(C1 | 0x02);
                                    break;
                            }

                            // select 20dB attenuator
                            C3 = Attenuator ? (byte)0x00 : (byte)0x04;

                            // Set Open Collector outputs as per selection
                            C2 = (byte)((int)OC_data << 1);  // Open Collector bits are  7... 1
                            break;
                        }
                    case 1:
                        {
                            // set CO  to  0x02 and send frequency for Hermes
                            C0 = 0x02; C1 = frequency[3]; C2 = frequency[2]; C3 = frequency[1]; C4 = frequency[0]; // send frequency data22
                            break;
                        }

                    case 2:
                        {
                            // set Drive Level and enable VNA 
                            C0 = 0x12;
                            C1 = Drive_Level;
                            C2 = run ? (byte)0x80 : (byte)0x00;              // 0x80 = VNA enabled, 0x00 = VNA disabled 
                            break;
                        }
                }


                pntr = (frame_number * 512) + 8;     // start past the 8 bytes header before the data
                to_Hermes[pntr] = sync; to_Hermes[++pntr] = sync; to_Hermes[++pntr] = sync;
                to_Hermes[++pntr] = C0; to_Hermes[++pntr] = C1; to_Hermes[++pntr] = C2;
                to_Hermes[++pntr] = C3; to_Hermes[++pntr] = C4;

                for (x = 8; x < 512; x += 8)        // fill out one 512-byte frame
                {
                    // send I & Q data to Hermes Q = 0 and I the Tx level  (0 to 2^15 - 1)
                    to_Hermes[++pntr] = (byte)(I_data >> 8);      // I_data[0];
                    to_Hermes[++pntr] = (byte)(I_data & 0xff);    // I_data[1];
                    to_Hermes[++pntr] = (byte)(Q_data >> 8);      // Q_data[0];
                    to_Hermes[++pntr] = (byte)(Q_data & 0xff);    // Q_data[1];  
                } // end for

            }

            if (true)  // send the frames to Hermes using UDP/IP
            {
                // put the header info into the start of the to_Hermes buffer
                to_Hermes[0] = 0xEF;   // first 2 bytes are ether type
                to_Hermes[1] = 0xFE;
                to_Hermes[2] = 0x01;   // frame type = 1
                to_Hermes[3] = 0x02;   // end point = EP2

                // insert sequence number.  It's in 'big-endian' order (MSByte first, LSByte last)
                to_Hermes[4] = (byte)(sequence_number >> 24);
                to_Hermes[5] = (byte)((sequence_number >> 16) & 0xff);
                to_Hermes[6] = (byte)((sequence_number >> 8) & 0xff);
                to_Hermes[7] = (byte)(sequence_number & 0xff);

                try
                {
                    //Send the UDP/IP packet out the network device
                    int rc = socket.SendTo(to_Hermes, HermesEP);
                }
                catch (Exception d)
                {
                    Debug.WriteLine("-- " + d.Message);   // *** need to warn user if this fails
                }

                // increment the sequence number for next time.  Make sure it's an unchecked operation, so that
                // no ArithmeticException is thrown when it wraps back to 0 (overflow.)
                unchecked
                {
                    sequence_number++;
                }
            }
        }
    }
}
