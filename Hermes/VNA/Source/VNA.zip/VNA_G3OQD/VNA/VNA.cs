﻿/*
 * This code is based on  VNA-lpg by Lawrence Glaister VE7IT
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Numerics;

namespace HermesVNAApplication
{
    class VNA
    {

        // Compute One-Port Calibration method error terms from three independent 
        // measurements of calibration standards. Open, Short and Load
        //
        // These three error terms are then used by 
        // VNA_ComputeActualReflectionCoefficient() to turn the measurement
        // of an unknown into an actual reflection coefficient.
        //
        // M1 is the measured reflection coefficient for the first calibration standard.
        // A1 is the actual reflection coefficient for the first calibration standard.
        // M2 is the measured reflection coefficient for the second calibration standard.
        // A2 is the actual reflection coefficient for the second calibration standard.
        // M3 is the measured reflection coefficient for the third calibration standard.
        // A3 is the actual reflection coefficient for the third calibration standard.

        public static bool ComputeOnePortCalibrationErrorTerms(Complex M1, Complex A1, Complex M2, Complex A2, Complex M3, Complex A3, ref Complex e00, ref Complex e11, ref Complex Deltae)
        {

            // Check for independence...
            if ((A1 == A2) || (A1 == A3) || (A2 == A3))
                return (false);
            if ((M1 == M2) || (M1 == M3) || (M2 == M3))
                return (false);

            //
            // This is an analytic solution (via substitution) of the following 3 linear equations in 3 unknowns:
            //	M1 = e00 + A1*M1*e11 - A1*Deltae
            //	M2 = e00 + A2*M2*e11 - A2*Deltae
            //	M3 = e00 + A3*M3*e11 - A3*Deltae 
            //

            // Compute Deltae
            Deltae = (((A2 * M2 - A1 * M1) * (M1 - M3)) + ((A3 * M3 - A1 * M1) * (M2 - M1))) /
                      (((A2 * M2 - A1 * M1) * (A3 - A1)) - ((A3 * M3 - A1 * M1) * (A2 - A1)));

            // Compute e11
            e11 = (M2 - M1 + (A2 - A1) * Deltae) / (A2 * M2 - A1 * M1);

            // Compute e00
            e00 = M1 - A1 * M1 * e11 + A1 * Deltae;

            return (true);
        }
        
        
        
        
        // Computes a complex impedance (Zx) from an actual reflection coefficient (RhoA)
        // and a base impedance (Zo - usually 50 + j0).
        public static bool ComputeComplexImpedance(Complex G, Complex Zo, ref Complex Zx)
        {

            Complex tempZx = Complex.Zero;
            
            // This is an analytic solution (by rearranging terms) of:
            //	RhoA = (Zx - Zo) / (Zx + Zo);

            // Check for division by 0, which implies infinite impedance.
            if (G == Complex.One)
            {
                Zx = new Complex(1.7E308, 1.7E308);
                return (false);
            }

            // Compute Zx
            tempZx = Zo * (Complex.One + G) / (Complex.One - G);

            Complex temp2Zx = new Complex(-tempZx.Real, tempZx.Imaginary);

            if (tempZx.Real < 0)
                Zx = temp2Zx;
            else
                Zx = tempZx;               

            return (true);
        }

        // Computes inductance (uH) from a complex impedance and frequency (Hz)
        public static bool ComputeInductance(double ImZx, double frequency, ref double Ind)
        {
            if (frequency == 0.0 || ImZx < 0)       // imaginary term must be positive for inductance
                return (false);
            Ind = ImZx * 1e6 / (2.0 * Math.PI * frequency);
            return (true);
        }

        // Computes capacitance (pf) from a complex impedance and frequency (Hz)
        public static bool ComputeCapacitance(double ImZx, double frequency, ref double Cap)
        {
            if ((frequency == 0.0) || (ImZx >= 0.0))  // imaginary term must be negative for capacitance
                return (false);
            Cap = -1.0e12 / (2.0 * Math.PI * frequency * ImZx);
            return (true);
        }

        // Compute parallel from series.
        public static bool ComputeParallelFromSeries(double Rs, double Xs, ref double Rp, ref double Xp)
        {
            if (Rs == 0 || Xs == 0)
                return (false);
            else
            {
                Rp = (Rs * Rs + Xs * Xs) / Rs;
                Xp = (Rs * Rs + Xs * Xs) / Xs;
                return (true);
            }
        }

        // Computes SWR given Z
        public static bool ComputeSWR(Complex Z, Complex Zo, ref double SWR)
        {
            // calculate Gamma
            Complex G = (Z - Zo) / (Z + Zo);

            double Rho = G.Magnitude;

            if (Rho == 0)
                return (false);
            else
            {
                SWR = (1.0 + Rho) / (1.0 - Rho);
                return (true);
            }
        }

        // Computes Return Loss [RL] given Z
        public static bool ComputeRL(Complex Z, Complex Zo, ref double RL)
        {
            // calculate Gamma
            Complex G = (Z - Zo) / (Z + Zo);

            double Rho = G.Magnitude;

            if (Rho == 0)
                return (false);
            else
            {
                RL = -20.0 * Math.Log10(Rho);
                return (true);
            }
        }

        // Convert Z to text 
        public static void ZtoText(Complex Z, ref string Z_text, ref string Rseries)
        {
            float Real = (float)Z.Real;
            float Imag = (float)Z.Imaginary;
            string sign = null;

            // Convert value to display to a string and include sign of Imaginary term
            if (Imag > 0)
                sign = " + j";
            else
            {
                sign = " - j";
                Imag *= -1;
            }

            // only display decimal places if required
            string dpr, dpi = null;
            dpr = Real % 1 == 0 ? "N0" : "N2";
            dpi = Imag % 1 == 0 ? "N0" : "N2";

            Z_text = Real.ToString(dpr) + sign + Imag.ToString(dpi);  // use ToString("Nx")  where x is number of decimal places to display
            Rseries = Real.ToString(dpr);
        }

        // Computes an actual reflection coefficient from a measured reflection 
        // coefficient and error terms.
        public static void ComputeReflCoeff(Complex RhoM, Complex e00, Complex e11, Complex Deltae, ref Complex RhoA)
        {
            RhoA = (RhoM - e00) / (RhoM * e11 - Deltae);
        }
    }
}
