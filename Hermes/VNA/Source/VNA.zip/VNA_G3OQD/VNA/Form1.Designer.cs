﻿namespace HermesVNAApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.buttonOnOff = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Calibrate = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.nbrSteps = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.endFreq = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.startFreq = new System.Windows.Forms.TextBox();
            this.Measure = new System.Windows.Forms.Button();
            this.Results = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.freq = new System.Windows.Forms.TextBox();
            this.RLtext = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.SWR_text = new System.Windows.Forms.TextBox();
            this.Unitsp = new System.Windows.Forms.Label();
            this.Typep = new System.Windows.Forms.Label();
            this.Xp = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.Rp = new System.Windows.Forms.TextBox();
            this.Units = new System.Windows.Forms.Label();
            this.Type = new System.Windows.Forms.Label();
            this.Xs = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Rs = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Imp = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Hermes_IP = new System.Windows.Forms.TextBox();
            this.Hermes_MAC = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.PC_IP = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.codeVersion = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.I_average = new System.Windows.Forms.TextBox();
            this.Q_average = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveZplotFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveS1PFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.loadMeasureFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMeasureFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.autoLoad = new System.Windows.Forms.CheckBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.leftScale = new System.Windows.Forms.ComboBox();
            this.rightScale = new System.Windows.Forms.ComboBox();
            this.adcLED = new System.Windows.Forms.Button();
            this.txLevel = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.modeRefChart = new System.Windows.Forms.RadioButton();
            this.modeRefSmith = new System.Windows.Forms.RadioButton();
            this.modeTrans = new System.Windows.Forms.RadioButton();
            this.groupDisplay = new System.Windows.Forms.GroupBox();
            this.splineButton = new System.Windows.Forms.RadioButton();
            this.logXAxis = new System.Windows.Forms.CheckBox();
            this.dotsButton = new System.Windows.Forms.RadioButton();
            this.autoRange = new System.Windows.Forms.CheckBox();
            this.lineButton = new System.Windows.Forms.RadioButton();
            this.Attenuator = new System.Windows.Forms.CheckBox();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.setStartFreq = new System.Windows.Forms.TextBox();
            this.setEndFreq = new System.Windows.Forms.TextBox();
            this.startLable = new System.Windows.Forms.Label();
            this.endLable = new System.Windows.Forms.Label();
            this.mhz1Lable = new System.Windows.Forms.Label();
            this.mhz2Lable = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label23 = new System.Windows.Forms.Label();
            this.cbAttemptFastConnect = new System.Windows.Forms.CheckBox();
            this.smithPictureBox1 = new HermesVNAApplication.SmithPictureBox();
            this.groupBox1.SuspendLayout();
            this.Results.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txLevel)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.smithPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonOnOff
            // 
            this.buttonOnOff.BackColor = System.Drawing.SystemColors.Control;
            this.buttonOnOff.Location = new System.Drawing.Point(688, 32);
            this.buttonOnOff.Name = "buttonOnOff";
            this.buttonOnOff.Size = new System.Drawing.Size(75, 23);
            this.buttonOnOff.TabIndex = 0;
            this.buttonOnOff.Text = "ON";
            this.buttonOnOff.UseVisualStyleBackColor = false;
            this.buttonOnOff.Click += new System.EventHandler(this.buttonOnOff_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Calibrate);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.nbrSteps);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.endFreq);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.startFreq);
            this.groupBox1.Location = new System.Drawing.Point(643, 78);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(163, 147);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Calibrate";
            // 
            // Calibrate
            // 
            this.Calibrate.Enabled = false;
            this.Calibrate.Location = new System.Drawing.Point(45, 111);
            this.Calibrate.Name = "Calibrate";
            this.Calibrate.Size = new System.Drawing.Size(75, 23);
            this.Calibrate.TabIndex = 12;
            this.Calibrate.Text = "Calibrate";
            this.Calibrate.UseVisualStyleBackColor = true;
            this.Calibrate.Click += new System.EventHandler(this.Calibrate_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Steps";
            // 
            // nbrSteps
            // 
            this.nbrSteps.Location = new System.Drawing.Point(60, 74);
            this.nbrSteps.Name = "nbrSteps";
            this.nbrSteps.Size = new System.Drawing.Size(32, 20);
            this.nbrSteps.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "End";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(124, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "MHz";
            // 
            // endFreq
            // 
            this.endFreq.Location = new System.Drawing.Point(60, 47);
            this.endFreq.Name = "endFreq";
            this.endFreq.Size = new System.Drawing.Size(60, 20);
            this.endFreq.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Start";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(124, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "MHz";
            // 
            // startFreq
            // 
            this.startFreq.Location = new System.Drawing.Point(60, 20);
            this.startFreq.Name = "startFreq";
            this.startFreq.Size = new System.Drawing.Size(60, 20);
            this.startFreq.TabIndex = 0;
            // 
            // Measure
            // 
            this.Measure.Enabled = false;
            this.Measure.Location = new System.Drawing.Point(688, 321);
            this.Measure.Name = "Measure";
            this.Measure.Size = new System.Drawing.Size(75, 23);
            this.Measure.TabIndex = 6;
            this.Measure.Text = "Measure";
            this.Measure.UseVisualStyleBackColor = true;
            this.Measure.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Measure_MouseDown);
            // 
            // Results
            // 
            this.Results.Controls.Add(this.label22);
            this.Results.Controls.Add(this.label2);
            this.Results.Controls.Add(this.freq);
            this.Results.Controls.Add(this.RLtext);
            this.Results.Controls.Add(this.label15);
            this.Results.Controls.Add(this.label14);
            this.Results.Controls.Add(this.label13);
            this.Results.Controls.Add(this.SWR_text);
            this.Results.Controls.Add(this.Unitsp);
            this.Results.Controls.Add(this.Typep);
            this.Results.Controls.Add(this.Xp);
            this.Results.Controls.Add(this.label12);
            this.Results.Controls.Add(this.label11);
            this.Results.Controls.Add(this.Rp);
            this.Results.Controls.Add(this.Units);
            this.Results.Controls.Add(this.Type);
            this.Results.Controls.Add(this.Xs);
            this.Results.Controls.Add(this.label10);
            this.Results.Controls.Add(this.label9);
            this.Results.Controls.Add(this.Rs);
            this.Results.Controls.Add(this.label8);
            this.Results.Controls.Add(this.Imp);
            this.Results.Location = new System.Drawing.Point(643, 350);
            this.Results.Name = "Results";
            this.Results.Size = new System.Drawing.Size(163, 226);
            this.Results.TabIndex = 7;
            this.Results.TabStop = false;
            this.Results.Text = "Results";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(108, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(29, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "MHz";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(22, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "f = ";
            // 
            // freq
            // 
            this.freq.Location = new System.Drawing.Point(45, 14);
            this.freq.Name = "freq";
            this.freq.ReadOnly = true;
            this.freq.Size = new System.Drawing.Size(57, 20);
            this.freq.TabIndex = 20;
            // 
            // RLtext
            // 
            this.RLtext.Location = new System.Drawing.Point(45, 196);
            this.RLtext.Name = "RLtext";
            this.RLtext.ReadOnly = true;
            this.RLtext.Size = new System.Drawing.Size(57, 20);
            this.RLtext.TabIndex = 19;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(108, 199);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(20, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "dB";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 199);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "RL";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 173);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "SWR";
            // 
            // SWR_text
            // 
            this.SWR_text.Location = new System.Drawing.Point(45, 170);
            this.SWR_text.Name = "SWR_text";
            this.SWR_text.ReadOnly = true;
            this.SWR_text.Size = new System.Drawing.Size(57, 20);
            this.SWR_text.TabIndex = 14;
            // 
            // Unitsp
            // 
            this.Unitsp.AutoSize = true;
            this.Unitsp.Location = new System.Drawing.Point(108, 147);
            this.Unitsp.Name = "Unitsp";
            this.Unitsp.Size = new System.Drawing.Size(21, 13);
            this.Unitsp.TabIndex = 13;
            this.Unitsp.Text = "uH";
            // 
            // Typep
            // 
            this.Typep.AutoSize = true;
            this.Typep.Location = new System.Drawing.Point(16, 147);
            this.Typep.Name = "Typep";
            this.Typep.Size = new System.Drawing.Size(28, 13);
            this.Typep.TabIndex = 12;
            this.Typep.Text = "Lp =";
            // 
            // Xp
            // 
            this.Xp.Location = new System.Drawing.Point(45, 144);
            this.Xp.Name = "Xp";
            this.Xp.ReadOnly = true;
            this.Xp.Size = new System.Drawing.Size(57, 20);
            this.Xp.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 121);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "Rp =";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(108, 121);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 9;
            this.label11.Text = "Ohms";
            // 
            // Rp
            // 
            this.Rp.Location = new System.Drawing.Point(45, 118);
            this.Rp.Name = "Rp";
            this.Rp.ReadOnly = true;
            this.Rp.Size = new System.Drawing.Size(57, 20);
            this.Rp.TabIndex = 8;
            // 
            // Units
            // 
            this.Units.AutoSize = true;
            this.Units.Location = new System.Drawing.Point(108, 95);
            this.Units.Name = "Units";
            this.Units.Size = new System.Drawing.Size(21, 13);
            this.Units.TabIndex = 7;
            this.Units.Text = "uH";
            // 
            // Type
            // 
            this.Type.AutoSize = true;
            this.Type.Location = new System.Drawing.Point(15, 95);
            this.Type.Name = "Type";
            this.Type.Size = new System.Drawing.Size(30, 13);
            this.Type.TabIndex = 6;
            this.Type.Text = "Ls = ";
            // 
            // Xs
            // 
            this.Xs.Location = new System.Drawing.Point(45, 92);
            this.Xs.Name = "Xs";
            this.Xs.ReadOnly = true;
            this.Xs.Size = new System.Drawing.Size(57, 20);
            this.Xs.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Rs = ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(108, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Ohms";
            // 
            // Rs
            // 
            this.Rs.Location = new System.Drawing.Point(45, 66);
            this.Rs.Name = "Rs";
            this.Rs.ReadOnly = true;
            this.Rs.Size = new System.Drawing.Size(57, 20);
            this.Rs.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 13);
            this.label8.TabIndex = 1;
            this.label8.Text = "Z = ";
            // 
            // Imp
            // 
            this.Imp.Location = new System.Drawing.Point(45, 40);
            this.Imp.Name = "Imp";
            this.Imp.ReadOnly = true;
            this.Imp.Size = new System.Drawing.Size(108, 20);
            this.Imp.TabIndex = 0;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(828, 84);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 13);
            this.label16.TabIndex = 8;
            this.label16.Text = "Hermes IP";
            // 
            // Hermes_IP
            // 
            this.Hermes_IP.Location = new System.Drawing.Point(890, 81);
            this.Hermes_IP.Name = "Hermes_IP";
            this.Hermes_IP.ReadOnly = true;
            this.Hermes_IP.Size = new System.Drawing.Size(99, 20);
            this.Hermes_IP.TabIndex = 13;
            // 
            // Hermes_MAC
            // 
            this.Hermes_MAC.Location = new System.Drawing.Point(890, 107);
            this.Hermes_MAC.Name = "Hermes_MAC";
            this.Hermes_MAC.ReadOnly = true;
            this.Hermes_MAC.Size = new System.Drawing.Size(99, 20);
            this.Hermes_MAC.TabIndex = 14;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(815, 110);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 13);
            this.label17.TabIndex = 15;
            this.label17.Text = "Hermes MAC";
            // 
            // PC_IP
            // 
            this.PC_IP.Location = new System.Drawing.Point(890, 54);
            this.PC_IP.Name = "PC_IP";
            this.PC_IP.Size = new System.Drawing.Size(99, 20);
            this.PC_IP.TabIndex = 16;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(850, 57);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(34, 13);
            this.label18.TabIndex = 17;
            this.label18.Text = "PC IP";
            // 
            // codeVersion
            // 
            this.codeVersion.Location = new System.Drawing.Point(890, 133);
            this.codeVersion.Name = "codeVersion";
            this.codeVersion.ReadOnly = true;
            this.codeVersion.Size = new System.Drawing.Size(40, 20);
            this.codeVersion.TabIndex = 18;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(815, 136);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(69, 13);
            this.label19.TabIndex = 19;
            this.label19.Text = "Code version";
            // 
            // I_average
            // 
            this.I_average.Location = new System.Drawing.Point(890, 425);
            this.I_average.Name = "I_average";
            this.I_average.ReadOnly = true;
            this.I_average.Size = new System.Drawing.Size(99, 20);
            this.I_average.TabIndex = 20;
            // 
            // Q_average
            // 
            this.Q_average.Location = new System.Drawing.Point(890, 451);
            this.Q_average.Name = "Q_average";
            this.Q_average.ReadOnly = true;
            this.Q_average.Size = new System.Drawing.Size(99, 20);
            this.Q_average.TabIndex = 21;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(831, 429);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 22;
            this.label20.Text = "I Average";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(826, 454);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(58, 13);
            this.label21.TabIndex = 23;
            this.label21.Text = "Q Average";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1009, 24);
            this.menuStrip1.TabIndex = 42;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripSeparator1,
            this.saveZplotFileToolStripMenuItem,
            this.saveS1PFileToolStripMenuItem,
            this.toolStripSeparator2,
            this.loadMeasureFileToolStripMenuItem,
            this.saveMeasureFileToolStripMenuItem,
            this.toolStripSeparator3,
            this.printToolStripMenuItem,
            this.toolStripSeparator4,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem2.Text = "Load Calibration File";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(182, 22);
            this.toolStripMenuItem3.Text = "Save Calibration File";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(179, 6);
            // 
            // saveZplotFileToolStripMenuItem
            // 
            this.saveZplotFileToolStripMenuItem.Name = "saveZplotFileToolStripMenuItem";
            this.saveZplotFileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.saveZplotFileToolStripMenuItem.Text = "Save Zplot File";
            this.saveZplotFileToolStripMenuItem.Click += new System.EventHandler(this.saveZplotFileToolStripMenuItem_Click);
            // 
            // saveS1PFileToolStripMenuItem
            // 
            this.saveS1PFileToolStripMenuItem.Name = "saveS1PFileToolStripMenuItem";
            this.saveS1PFileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.saveS1PFileToolStripMenuItem.Text = "Save S1P File";
            this.saveS1PFileToolStripMenuItem.Click += new System.EventHandler(this.saveS1PFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(179, 6);
            // 
            // loadMeasureFileToolStripMenuItem
            // 
            this.loadMeasureFileToolStripMenuItem.Name = "loadMeasureFileToolStripMenuItem";
            this.loadMeasureFileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.loadMeasureFileToolStripMenuItem.Text = "Load Measure File";
            this.loadMeasureFileToolStripMenuItem.Click += new System.EventHandler(this.loadMeasureFileToolStripMenuItem_Click);
            // 
            // saveMeasureFileToolStripMenuItem
            // 
            this.saveMeasureFileToolStripMenuItem.Name = "saveMeasureFileToolStripMenuItem";
            this.saveMeasureFileToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.saveMeasureFileToolStripMenuItem.Text = "Save Measure File";
            this.saveMeasureFileToolStripMenuItem.Click += new System.EventHandler(this.saveMeasureFileToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(179, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(179, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "VNA Files | *.csv";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "VNA files | *.csv| S Parameter |*.s1p";
            // 
            // autoLoad
            // 
            this.autoLoad.AutoSize = true;
            this.autoLoad.Location = new System.Drawing.Point(862, 159);
            this.autoLoad.Name = "autoLoad";
            this.autoLoad.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.autoLoad.Size = new System.Drawing.Size(127, 17);
            this.autoLoad.TabIndex = 43;
            this.autoLoad.Text = "Auto Load Calibration";
            this.autoLoad.UseVisualStyleBackColor = true;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(849, 321);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(140, 23);
            this.progressBar1.TabIndex = 44;
            // 
            // leftScale
            // 
            this.leftScale.ForeColor = System.Drawing.Color.Blue;
            this.leftScale.FormattingEnabled = true;
            this.leftScale.Items.AddRange(new object[] {
            "Rs",
            "SWR",
            "Xs",
            "Zmag",
            "Theta",
            "RL",
            "Phase",
            "Rp",
            "Xp",
            "Ls(uH)",
            "Cs(pf)",
            "Lp(uH)",
            "Cp(pf)"});
            this.leftScale.Location = new System.Drawing.Point(21, 27);
            this.leftScale.Name = "leftScale";
            this.leftScale.Size = new System.Drawing.Size(58, 21);
            this.leftScale.TabIndex = 46;
            this.leftScale.Text = "SWR";
            this.leftScale.SelectedIndexChanged += new System.EventHandler(this.leftScale_SelectedIndexChanged);
            // 
            // rightScale
            // 
            this.rightScale.ForeColor = System.Drawing.Color.Red;
            this.rightScale.FormattingEnabled = true;
            this.rightScale.Items.AddRange(new object[] {
            "(none)",
            "Rs",
            "SWR",
            "Xs",
            "Zmag",
            "Theta",
            "RL",
            "Phase",
            "Rp",
            "Xp",
            "Ls(uH)",
            "Cs(pf)",
            "Lp(uH)",
            "Cp(pf)"});
            this.rightScale.Location = new System.Drawing.Point(522, 27);
            this.rightScale.Name = "rightScale";
            this.rightScale.Size = new System.Drawing.Size(56, 21);
            this.rightScale.TabIndex = 47;
            this.rightScale.Text = "(none)";
            this.rightScale.SelectedIndexChanged += new System.EventHandler(this.rightScale_SelectedIndexChanged);
            // 
            // adcLED
            // 
            this.adcLED.Location = new System.Drawing.Point(890, 202);
            this.adcLED.Name = "adcLED";
            this.adcLED.Size = new System.Drawing.Size(99, 23);
            this.adcLED.TabIndex = 48;
            this.adcLED.Text = "ADC Overload";
            this.adcLED.UseVisualStyleBackColor = true;
            // 
            // txLevel
            // 
            this.txLevel.BackColor = System.Drawing.SystemColors.Control;
            this.txLevel.Location = new System.Drawing.Point(849, 367);
            this.txLevel.Maximum = 32767;
            this.txLevel.Name = "txLevel";
            this.txLevel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txLevel.Size = new System.Drawing.Size(140, 45);
            this.txLevel.TabIndex = 49;
            this.txLevel.TickStyle = System.Windows.Forms.TickStyle.None;
            this.txLevel.Value = 32767;
            this.txLevel.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(897, 396);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 50;
            this.label1.Text = "Tx Level";
            this.label1.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.modeRefChart);
            this.groupBox3.Controls.Add(this.modeRefSmith);
            this.groupBox3.Controls.Add(this.modeTrans);
            this.groupBox3.Location = new System.Drawing.Point(643, 230);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(163, 85);
            this.groupBox3.TabIndex = 51;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Mode";
            // 
            // modeRefChart
            // 
            this.modeRefChart.AutoSize = true;
            this.modeRefChart.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.modeRefChart.Location = new System.Drawing.Point(24, 61);
            this.modeRefChart.Name = "modeRefChart";
            this.modeRefChart.Size = new System.Drawing.Size(101, 17);
            this.modeRefChart.TabIndex = 2;
            this.modeRefChart.Text = "Reflection Chart";
            this.modeRefChart.UseVisualStyleBackColor = true;
            this.modeRefChart.CheckedChanged += new System.EventHandler(this.modeRefChart_CheckedChanged);
            // 
            // modeRefSmith
            // 
            this.modeRefSmith.AutoSize = true;
            this.modeRefSmith.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.modeRefSmith.Location = new System.Drawing.Point(23, 40);
            this.modeRefSmith.Name = "modeRefSmith";
            this.modeRefSmith.Size = new System.Drawing.Size(102, 17);
            this.modeRefSmith.TabIndex = 1;
            this.modeRefSmith.Text = "Reflection Smith";
            this.modeRefSmith.UseVisualStyleBackColor = true;
            this.modeRefSmith.CheckedChanged += new System.EventHandler(this.modeRefSmith_CheckedChanged);
            // 
            // modeTrans
            // 
            this.modeTrans.AutoSize = true;
            this.modeTrans.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.modeTrans.Location = new System.Drawing.Point(21, 19);
            this.modeTrans.Name = "modeTrans";
            this.modeTrans.Size = new System.Drawing.Size(104, 17);
            this.modeTrans.TabIndex = 0;
            this.modeTrans.Text = "Transmission      ";
            this.modeTrans.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.modeTrans.UseVisualStyleBackColor = true;
            this.modeTrans.CheckedChanged += new System.EventHandler(this.modeTrans_CheckedChanged);
            // 
            // groupDisplay
            // 
            this.groupDisplay.Controls.Add(this.splineButton);
            this.groupDisplay.Controls.Add(this.logXAxis);
            this.groupDisplay.Controls.Add(this.dotsButton);
            this.groupDisplay.Controls.Add(this.autoRange);
            this.groupDisplay.Controls.Add(this.lineButton);
            this.groupDisplay.Location = new System.Drawing.Point(812, 230);
            this.groupDisplay.Name = "groupDisplay";
            this.groupDisplay.Size = new System.Drawing.Size(191, 69);
            this.groupDisplay.TabIndex = 0;
            this.groupDisplay.TabStop = false;
            this.groupDisplay.Text = "Display";
            // 
            // splineButton
            // 
            this.splineButton.AutoSize = true;
            this.splineButton.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.splineButton.Location = new System.Drawing.Point(131, 15);
            this.splineButton.Name = "splineButton";
            this.splineButton.Size = new System.Drawing.Size(54, 17);
            this.splineButton.TabIndex = 7;
            this.splineButton.Text = "Spline";
            this.splineButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.splineButton.UseVisualStyleBackColor = true;
            this.splineButton.CheckedChanged += new System.EventHandler(this.splineButton_CheckedChanged);
            // 
            // logXAxis
            // 
            this.logXAxis.AutoSize = true;
            this.logXAxis.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.logXAxis.Location = new System.Drawing.Point(111, 41);
            this.logXAxis.Name = "logXAxis";
            this.logXAxis.Size = new System.Drawing.Size(74, 17);
            this.logXAxis.TabIndex = 54;
            this.logXAxis.Text = "Log x Axis";
            this.logXAxis.UseVisualStyleBackColor = true;
            this.logXAxis.CheckedChanged += new System.EventHandler(this.logXAxis_CheckedChanged);
            // 
            // dotsButton
            // 
            this.dotsButton.AutoSize = true;
            this.dotsButton.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.dotsButton.Location = new System.Drawing.Point(68, 14);
            this.dotsButton.Name = "dotsButton";
            this.dotsButton.Size = new System.Drawing.Size(47, 17);
            this.dotsButton.TabIndex = 6;
            this.dotsButton.Text = "Dots";
            this.dotsButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.dotsButton.UseVisualStyleBackColor = true;
            this.dotsButton.CheckedChanged += new System.EventHandler(this.dotsButton_CheckedChanged);
            // 
            // autoRange
            // 
            this.autoRange.AutoSize = true;
            this.autoRange.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.autoRange.Location = new System.Drawing.Point(6, 40);
            this.autoRange.Name = "autoRange";
            this.autoRange.Size = new System.Drawing.Size(83, 17);
            this.autoRange.TabIndex = 53;
            this.autoRange.Text = "Auto Range";
            this.autoRange.UseVisualStyleBackColor = true;
            this.autoRange.CheckedChanged += new System.EventHandler(this.autoRange_CheckedChanged);
            // 
            // lineButton
            // 
            this.lineButton.AutoSize = true;
            this.lineButton.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lineButton.Checked = true;
            this.lineButton.Location = new System.Drawing.Point(6, 15);
            this.lineButton.Name = "lineButton";
            this.lineButton.Size = new System.Drawing.Size(45, 17);
            this.lineButton.TabIndex = 5;
            this.lineButton.TabStop = true;
            this.lineButton.Text = "Line";
            this.lineButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lineButton.UseVisualStyleBackColor = true;
            this.lineButton.CheckedChanged += new System.EventHandler(this.lineButton_CheckedChanged);
            // 
            // Attenuator
            // 
            this.Attenuator.AutoSize = true;
            this.Attenuator.Enabled = false;
            this.Attenuator.Location = new System.Drawing.Point(886, 182);
            this.Attenuator.Name = "Attenuator";
            this.Attenuator.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Attenuator.Size = new System.Drawing.Size(103, 17);
            this.Attenuator.TabIndex = 55;
            this.Attenuator.Text = "20dB Attenuator";
            this.Attenuator.UseVisualStyleBackColor = true;
            this.Attenuator.CheckedChanged += new System.EventHandler(this.Attenuator_CheckedChanged);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 0;
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(21, 54);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series2";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(595, 522);
            this.chart1.TabIndex = 52;
            this.chart1.Text = "chart1";
            this.chart1.Visible = false;
            this.chart1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseClick);
            this.chart1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chart1_MouseMove);
            // 
            // setStartFreq
            // 
            this.setStartFreq.Location = new System.Drawing.Point(56, 550);
            this.setStartFreq.Name = "setStartFreq";
            this.setStartFreq.Size = new System.Drawing.Size(60, 20);
            this.setStartFreq.TabIndex = 13;
            this.setStartFreq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.setStartFreq_KeyPress);
            this.setStartFreq.Leave += new System.EventHandler(this.setStartFreq_Leave);
            // 
            // setEndFreq
            // 
            this.setEndFreq.Location = new System.Drawing.Point(444, 551);
            this.setEndFreq.Name = "setEndFreq";
            this.setEndFreq.Size = new System.Drawing.Size(60, 20);
            this.setEndFreq.TabIndex = 57;
            this.setEndFreq.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.setEndFreq_KeyPress);
            this.setEndFreq.Leave += new System.EventHandler(this.setEndFreq_Leave);
            // 
            // startLable
            // 
            this.startLable.AutoSize = true;
            this.startLable.BackColor = System.Drawing.Color.White;
            this.startLable.Location = new System.Drawing.Point(21, 553);
            this.startLable.Name = "startLable";
            this.startLable.Size = new System.Drawing.Size(29, 13);
            this.startLable.TabIndex = 13;
            this.startLable.Text = "Start";
            // 
            // endLable
            // 
            this.endLable.AutoSize = true;
            this.endLable.BackColor = System.Drawing.Color.White;
            this.endLable.Location = new System.Drawing.Point(412, 554);
            this.endLable.Name = "endLable";
            this.endLable.Size = new System.Drawing.Size(26, 13);
            this.endLable.TabIndex = 13;
            this.endLable.Text = "End";
            // 
            // mhz1Lable
            // 
            this.mhz1Lable.AutoSize = true;
            this.mhz1Lable.BackColor = System.Drawing.Color.White;
            this.mhz1Lable.Location = new System.Drawing.Point(122, 554);
            this.mhz1Lable.Name = "mhz1Lable";
            this.mhz1Lable.Size = new System.Drawing.Size(29, 13);
            this.mhz1Lable.TabIndex = 23;
            this.mhz1Lable.Text = "MHz";
            // 
            // mhz2Lable
            // 
            this.mhz2Lable.AutoSize = true;
            this.mhz2Lable.BackColor = System.Drawing.Color.White;
            this.mhz2Lable.Location = new System.Drawing.Point(510, 555);
            this.mhz2Lable.Name = "mhz2Lable";
            this.mhz2Lable.Size = new System.Drawing.Size(29, 13);
            this.mhz2Lable.TabIndex = 58;
            this.mhz2Lable.Text = "MHz";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(658, 61);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 13);
            this.label23.TabIndex = 59;
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label23.Visible = false;
            // 
            // cbAttemptFastConnect
            // 
            this.cbAttemptFastConnect.AutoSize = true;
            this.cbAttemptFastConnect.Location = new System.Drawing.Point(805, 32);
            this.cbAttemptFastConnect.Name = "cbAttemptFastConnect";
            this.cbAttemptFastConnect.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbAttemptFastConnect.Size = new System.Drawing.Size(184, 17);
            this.cbAttemptFastConnect.TabIndex = 60;
            this.cbAttemptFastConnect.Text = "Attempt fast connect using last IP";
            this.cbAttemptFastConnect.UseVisualStyleBackColor = true;
            this.cbAttemptFastConnect.CheckedChanged += new System.EventHandler(this.cbAttemptFastConnect_CheckedChanged);
            // 
            // smithPictureBox1
            // 
            this.smithPictureBox1.Location = new System.Drawing.Point(21, 54);
            this.smithPictureBox1.Name = "smithPictureBox1";
            this.smithPictureBox1.Size = new System.Drawing.Size(520, 520);
            this.smithPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.smithPictureBox1.TabIndex = 56;
            this.smithPictureBox1.TabStop = false;
            this.smithPictureBox1.Visible = false;
            this.smithPictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.smithPictureBox1_MouseClick);
            this.smithPictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.smithPictureBox1_MouseMove);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 596);
            this.Controls.Add(this.cbAttemptFastConnect);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.mhz2Lable);
            this.Controls.Add(this.mhz1Lable);
            this.Controls.Add(this.endLable);
            this.Controls.Add(this.startLable);
            this.Controls.Add(this.setEndFreq);
            this.Controls.Add(this.setStartFreq);
            this.Controls.Add(this.smithPictureBox1);
            this.Controls.Add(this.Attenuator);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.groupDisplay);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txLevel);
            this.Controls.Add(this.adcLED);
            this.Controls.Add(this.rightScale);
            this.Controls.Add(this.leftScale);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.autoLoad);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.Q_average);
            this.Controls.Add(this.I_average);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.codeVersion);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.PC_IP);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.Hermes_MAC);
            this.Controls.Add(this.Hermes_IP);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.Results);
            this.Controls.Add(this.Measure);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonOnOff);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Hermes Vector Network Analyser";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Results.ResumeLayout(false);
            this.Results.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txLevel)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupDisplay.ResumeLayout(false);
            this.groupDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.smithPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOnOff;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Calibrate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox nbrSteps;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox endFreq;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox startFreq;
        private System.Windows.Forms.Button Measure;
        private System.Windows.Forms.GroupBox Results;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Imp;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Rs;
        private System.Windows.Forms.Label Units;
        private System.Windows.Forms.Label Type;
        private System.Windows.Forms.TextBox Xs;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox Rp;
        private System.Windows.Forms.Label Unitsp;
        private System.Windows.Forms.Label Typep;
        private System.Windows.Forms.TextBox Xp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox SWR_text;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox RLtext;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Hermes_IP;
        private System.Windows.Forms.TextBox Hermes_MAC;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox PC_IP;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox codeVersion;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.CheckBox autoLoad;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ToolStripMenuItem saveZplotFileToolStripMenuItem;
        private System.Windows.Forms.ComboBox leftScale;
        private System.Windows.Forms.ComboBox rightScale;
        private System.Windows.Forms.Button adcLED;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        //private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        public System.Windows.Forms.TrackBar txLevel;
        public System.Windows.Forms.RadioButton dotsButton;
        public System.Windows.Forms.RadioButton splineButton;
        public System.Windows.Forms.RadioButton lineButton;
        public System.Windows.Forms.CheckBox autoRange;
        public System.Windows.Forms.CheckBox logXAxis;
        public System.Windows.Forms.TextBox I_average;
        public System.Windows.Forms.TextBox Q_average;
        public System.Windows.Forms.RadioButton modeRefChart;
        public System.Windows.Forms.RadioButton modeRefSmith;
        public System.Windows.Forms.RadioButton modeTrans;
        public System.Windows.Forms.GroupBox groupDisplay;
        private System.Windows.Forms.CheckBox Attenuator;
        private System.Windows.Forms.ToolStripMenuItem loadMeasureFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMeasureFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private SmithPictureBox smithPictureBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox freq;
        private System.Windows.Forms.Label startLable;
        private System.Windows.Forms.Label endLable;
        private System.Windows.Forms.Label mhz1Lable;
        private System.Windows.Forms.Label mhz2Lable;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem saveS1PFileToolStripMenuItem;
        public System.Windows.Forms.TextBox setStartFreq;
        public System.Windows.Forms.TextBox setEndFreq;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.CheckBox cbAttemptFastConnect;
    }
}

