﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace HermesVNAApplication
{
    class InputBox
    {
            /// <summary>
            /// Displays a dialog with a prompt and textbox where the user can enter information
            /// </summary>
            /// <param name="title">Dialog title</param>
            /// <param name="promptText">Dialog prompt</param>
            /// <param name="value">Sets the initial value and returns the result</param>
            /// <returns>Dialog result</returns>
            /// 
            public static DialogResult Show(string title, string promptText, ref string value)
            {
                Form form = new Form();
                Label label = new Label();
                TextBox textBox = new TextBox();
                Button buttonOk = new Button();
                Button buttonCancel = new Button();

                form.Text = title;
                label.Text = promptText;
                textBox.Text = value;

                buttonOk.Text = "OK";
                buttonCancel.Text = "Cancel";
                buttonOk.DialogResult = DialogResult.OK;
                buttonCancel.DialogResult = DialogResult.Cancel;

                label.SetBounds(9, 20, 372, 13);            // was (9, 20, 372, 13);
                textBox.SetBounds(12, 80, 20, 20);          // was  (12, 36, 372, 20);
                buttonOk.SetBounds(15, 110, 75, 23);        // was (228, 72, 75, 23);
                buttonCancel.SetBounds(100, 110, 75, 23);   // was (309, 72, 75, 23);

                label.AutoSize = true;
                textBox.Anchor = textBox.Anchor | AnchorStyles.Right;
                buttonOk.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
                buttonCancel.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;

                form.ClientSize = new Size(200, 150);  // was 396, 107
                form.Controls.AddRange(new Control[] { label, textBox, buttonOk, buttonCancel });
                form.ClientSize = new Size(Math.Max(200, label.Right + 10), form.ClientSize.Height);  // was 300
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.StartPosition = FormStartPosition.CenterScreen;
                form.MinimizeBox = false;
                form.MaximizeBox = false;
                form.AcceptButton = buttonOk;
                form.CancelButton = buttonCancel;

                DialogResult dialogResult = form.ShowDialog();
                value = textBox.Text;
                return dialogResult;
            
        }




    }
}
