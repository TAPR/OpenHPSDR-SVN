﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Numerics;      // for complex numbers 
using System.Windows.Forms.DataVisualization.Charting;  // need this for the chart

namespace HermesVNAApplication
{
    /// <summary>
    /// this is an extension method class, that extends the Charting.Chart class to do special things for the VNA chart.
    /// Formerly, this was a derived class with the Charting.Chart as its base class.  There were times that the IDE
    /// didn't always show the designer view correctly!
    /// 
    /// For an extension method class, the class must be static. the methods must be static.  AND the
    /// first parameter of any extension method must be 'this Chart chart1' or similar.  That is:
    /// 'this' is a keyword that identifies that it's an extension method, and what follows (Chart chart1) is the
    /// thing that it extends, in this case a 'Chart' object, called 'chart1' inside the method when the method needs to
    /// refer to the object instance being extended.
    /// 
    /// How do you call an extension method?  By putting the name of the object (like 'chart1') in front of the method, like you
    /// would when calling a normal method on a specific object instance.  (Chart is the object type or 'abstract object'.  'chart1'
    /// is the name of the specific instance of the Chart object type that we are acting on.  Note that the name of the parameter here in
    /// the method signature (ie: 'chart1') does NOT mean that you can only use it on an object instance named 'chart1'.
    /// </summary>
    public static class VNAChart
    {
        public static double assignGraphData(this Chart chart1, string Scale, double SWR, Complex Impedance, Complex RhoA, double Rpar, double Xpar, double RL,
                                             double Ls, double Lp, double Cs, double Cp, Complex Trans)
        {

            switch (Scale)
            {
                case "SWR":
                    {
                        return (SWR);
                    }

                case "Xs":
                    {
                        return (Impedance.Imaginary);
                    }

                case "Rs":
                    {
                        return (Impedance.Real);
                    }

                case "Zmag":
                    {
                        return (Math.Sqrt((Impedance.Real * Impedance.Real) + (Impedance.Imaginary + Impedance.Imaginary)));
                    }

                case "Theta":
                    {
                        return (RhoA.Phase);
                    }

                case "RL":
                    {
                        return (-RL);
                    }

                case "Phase":
                    {
                        return (RhoA.Phase * 180 / Math.PI);
                    }

                case "Rp":
                    {
                        return (Rpar);
                    }


                case "Xp":
                    {
                        return (Xpar);
                    }

                case "Ls(uH)":
                    {
                        return (Ls);
                    }

                case "Cs(pf)":
                    {
                        return (Cs);
                    }

                case "Lp(uH)":
                    {
                        return (Lp);
                    }

                case "Cp(pf)":
                    {
                        return (Cp);
                    }

                case "|G| dB":
                    {
                        return Trans.Real;
                    }

                case "Phase [degrees]":
                    {
                        return Trans.Imaginary;
                    }

                default: return (0);
            }
        }

        public static void drawGraph(this Chart chart1, Form1 form, string LHStext, string RHStext, int steps, Complex[,] displayData)
        {
            double tempFreq = 0.0f;

            chart1.Series[0].Points.Clear();   // clear any previous data on the chart
            chart1.Series[1].Points.Clear();

            for (int x = 0; x < steps + 1; x++)    // have tested for (int x = 0; x < displayData.Length/2; x++)            
            {
                tempFreq = (displayData[x, 0].Real / 1e6);
                chart1.Series[0].Points.AddXY(tempFreq, displayData[x, 1].Real);
                if (RHStext != "(none)")
                    chart1.Series[1].Points.AddXY(tempFreq, displayData[x, 1].Imaginary);
            }

            // set chart type and colours
            SeriesChartType type = SeriesChartType.FastLine;    // default - connect data points using a line

            if (form.dotsButton.Checked || steps == 0)
            {
                type = SeriesChartType.Point;                   // draw data points as dots if selected or just a single frequency measurement
            }
            else if (form.splineButton.Checked)
            {
                type = SeriesChartType.Spline;                  // connect data points using a spline
            }

            chart1.Series[0].ChartType = type;
            chart1.Series[1].ChartType = type;

            chart1.Series[0].Color = Color.Blue;
            chart1.Series[1].Color = Color.Red;

            // set up secondary Y axis
            chart1.Series[0].YAxisType = AxisType.Primary;
            chart1.Series[1].YAxisType = AxisType.Secondary;                                // this is the magic that makes the Y2 scale independant if Y.
            chart1.ChartAreas[0].AxisY2.LineColor = Color.Transparent;
            // ChartAreas[0].AxisY2.MajorGrid.Enabled = true;                        // true if you want to make the Y2 lines visible
            chart1.ChartAreas[0].AxisY2.MajorGrid.LineDashStyle = ChartDashStyle.Dash;      // makes the Y2 axis a dash


            // User selects Auto Range or normal
            if (form.autoRange.Checked)
            {
                chart1.ChartAreas[0].AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;
                chart1.ChartAreas[0].AxisY.IntervalAutoMode = IntervalAutoMode.VariableCount;
                chart1.ChartAreas[0].AxisY2.IntervalAutoMode = IntervalAutoMode.VariableCount;
                chart1.ChartAreas[0].AxisY.IsStartedFromZero = false;   // this prevents the graph from starting from zero if all the values are positive
                chart1.ChartAreas[0].AxisY2.IsStartedFromZero = false;
            }
            else
            {
                chart1.ChartAreas[0].AxisX.IntervalAutoMode = IntervalAutoMode.FixedCount;
                chart1.ChartAreas[0].AxisY.IntervalAutoMode = IntervalAutoMode.FixedCount;
                chart1.ChartAreas[0].AxisY2.IntervalAutoMode = IntervalAutoMode.FixedCount;
                chart1.ChartAreas[0].AxisY.IsStartedFromZero = true;   // force graph to start from 0 if all values are positive 
                chart1.ChartAreas[0].AxisY2.IsStartedFromZero = true;
            }


            // Enable secondary Y axis if required
            if (RHStext != "(none)")
            {
                chart1.ChartAreas[0].AxisY2.Enabled = AxisEnabled.True;
                chart1.ChartAreas[0].AxisY2.Title = RHStext;
            }
            else
            {
                chart1.ChartAreas[0].AxisY2.Enabled = AxisEnabled.False;
            }


            chart1.ChartAreas[0].AxisY.Title = LHStext;           // display Y axsis legend

            chart1.ChartAreas[0].AxisX.Title = "Frequency (MHz)";  // display X axsis legend

            // set left and right title colours
            chart1.ChartAreas[0].AxisY.TitleForeColor = Color.Blue;
            chart1.ChartAreas[0].AxisY2.TitleForeColor = Color.Red;

            // Enable all elements
            chart1.ChartAreas[0].AxisX.MinorGrid.Enabled = true;
            chart1.ChartAreas[0].AxisX.MinorTickMark.Enabled = true;

            // Set Grid lines and tick marks interval
            chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 10;
            chart1.ChartAreas[0].AxisX.MajorTickMark.Interval = 1;
            chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 2;
            chart1.ChartAreas[0].AxisX.MinorTickMark.Interval = 1;

            // Set Line Color
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Black;
            chart1.ChartAreas[0].AxisX.MinorGrid.LineColor = Color.LightGray;

            // Set Line Style
            chart1.ChartAreas[0].AxisX.MajorTickMark.LineDashStyle = ChartDashStyle.Solid;

            // Set Line Widths
            chart1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 2;
            chart1.Series[0].BorderWidth = 2;                       // sets graph line width (that's why its called boarder!)
            chart1.Series[1].BorderWidth = 2;

            if (form.logXAxis.Checked)
            {
                chart1.ChartAreas[0].AxisX.IsLogarithmic = true;
            }
            else
            {
                chart1.ChartAreas[0].AxisX.IsLogarithmic = false;
            }

            // set scales depending on display data  
            switch (LHStext)
            {
                case "|G| dB":
                    {
                        if (form.autoRange.Checked)
                        {
                            // Auto scale
                            chart1.ChartAreas[0].AxisY.Minimum = Double.NaN;
                            chart1.ChartAreas[0].AxisY.Maximum = Double.NaN;
                            chart1.ChartAreas[0].AxisY.Interval = Double.NaN;
                            break;
                        }
                        else
                        {
                            chart1.ChartAreas[0].AxisY.Maximum = 10;
                            chart1.ChartAreas[0].AxisY.Minimum = -110;
                            chart1.ChartAreas[0].AxisY.Interval = 10;
                            chart1.ChartAreas[0].AxisY2.Interval = 30;
                            chart1.ChartAreas[0].AxisY2.Maximum = 180;
                            chart1.ChartAreas[0].AxisY2.Minimum = -180;
                        }
                        break;
                    }

                case "SWR":
                    {
                        if (form.autoRange.Checked)
                            chart1.ChartAreas[0].AxisY.Minimum = 1;
                        else
                            chart1.ChartAreas[0].AxisY.Minimum = 0;

                        chart1.ChartAreas[0].AxisY.Maximum = Double.NaN;
                        chart1.ChartAreas[0].AxisY.Interval = Double.NaN;
                        break;
                    }

                case "Rs":
                case "Xs":
                case "Zmag":
                case "Theta":
                case "Phase":
                case "Rp":
                case "Xp":
                case "Ls(uh)":
                case "Cs(pf)":
                case "Lp(uh)":
                case "Cp(pf)":
                    {
                        // Auto scale
                        chart1.ChartAreas[0].AxisY.Minimum = Double.NaN;
                        chart1.ChartAreas[0].AxisY.Maximum = Double.NaN;
                        chart1.ChartAreas[0].AxisY.Interval = Double.NaN;
                        break;
                    }

                case "RL":
                    {
                        if (form.autoRange.Checked)
                        {
                            // Auto scale
                            chart1.ChartAreas[0].AxisY.Minimum = Double.NaN;
                            chart1.ChartAreas[0].AxisY.Maximum = Double.NaN;
                            chart1.ChartAreas[0].AxisY.Interval = Double.NaN;
                        }
                        else
                        {
                            chart1.ChartAreas[0].AxisY.Maximum = 0;
                            chart1.ChartAreas[0].AxisY.Minimum = -100;
                            chart1.ChartAreas[0].AxisY.Interval = 10;
                        }
                        break;
                    }
            }

            switch (RHStext)
            {
                case "Phase [degrees]":
                    {
                        if (form.autoRange.Checked)
                        {
                            // Auto scale
                            chart1.ChartAreas[0].AxisY2.Minimum = Double.NaN;
                            chart1.ChartAreas[0].AxisY2.Maximum = Double.NaN;
                            chart1.ChartAreas[0].AxisY2.Interval = Double.NaN;
                        }
                        else
                        {
                            chart1.ChartAreas[0].AxisY2.Minimum = -180;
                            chart1.ChartAreas[0].AxisY2.Maximum = 180;
                            chart1.ChartAreas[0].AxisY2.Interval = 30;
                        }
                        break;
                    }


                case "SWR":
                    {
                        if (form.autoRange.Checked)
                            chart1.ChartAreas[0].AxisY2.Minimum = 1;
                        else
                            chart1.ChartAreas[0].AxisY2.Minimum = 0;

                        chart1.ChartAreas[0].AxisY2.Maximum = Double.NaN;
                        chart1.ChartAreas[0].AxisY2.Interval = Double.NaN;
                        break;
                    }

                case "(none)":
                case "Rs":
                case "Xs":
                case "Zmag":
                case "Theta":
                case "Phase":
                case "Rp":
                case "Xp":
                case "Ls(uh)":
                case "Cs(pf)":
                case "Lp(uh)":
                case "Cp(pf)":
                    {
                        // Auto scale
                        chart1.ChartAreas[0].AxisY2.Minimum = Double.NaN;
                        chart1.ChartAreas[0].AxisY2.Maximum = Double.NaN;
                        chart1.ChartAreas[0].AxisY2.Interval = Double.NaN;
                        break;
                    }

                case "RL":
                    {
                        if (form.autoRange.Checked)
                        {
                            // Auto scale
                            chart1.ChartAreas[0].AxisY2.Minimum = Double.NaN;
                            chart1.ChartAreas[0].AxisY2.Maximum = Double.NaN;
                            chart1.ChartAreas[0].AxisY2.Interval = Double.NaN;
                        }
                        else
                        {
                            chart1.ChartAreas[0].AxisY2.Maximum = 0;
                            chart1.ChartAreas[0].AxisY2.Minimum = -100;
                            chart1.ChartAreas[0].AxisY2.Interval = 10;
                        }
                        break;
                    }
            }
        }
    }
}
