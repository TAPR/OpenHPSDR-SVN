﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics; 

namespace HermesVNAApplication
{
    class Hermes
    {

        public static bool Discovery( Socket socket, ref string HermesIP, ref string HermesMAC, EndPoint iep)
        {

            socket.SendBufferSize = 1024;

            // set up HPSDR Hermes discovery packet
            byte[] Hermes_discovery = new byte[63];
            Array.Clear(Hermes_discovery, 0, Hermes_discovery.Length);

            byte[] Hermes_discovery_preamble = new byte[] { 0xEF, 0xFE, 0x02 };
            Hermes_discovery_preamble.CopyTo(Hermes_discovery, 0);

            bool have_Hermes = false;            // true when we find an Hermes
            int time_out = 0;
            bool exit = false;                  // true when we need to exit the while loop

            // send every second until we either find an Hermes board or exceed the number of attempts

            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);

            // need this so we can Broadcast on the socket
            IPEndPoint broadcast = new IPEndPoint(IPAddress.Broadcast, 1024);
            string receivedIP = "";   // the IP address Hermes obtains; assigned, from DHCP or APIPA (169.254.x.y)

            while (!have_Hermes && !exit)            // #### djm should loop for a while in case there are multiple Hermes boards
            {

                // send a broadcast to the port 1024
                socket.SendTo(Hermes_discovery, broadcast);

                // now listen on  send port for any Hermes cards
                Console.WriteLine("Ready to receive.... ");
                int recv;
                byte[] data = new byte[100];

                bool data_available;

                // Poll the port to see if data is available
                data_available = socket.Poll(100000, SelectMode.SelectRead);  // wait 100 msec  for time out    

                if (data_available)
                {
                    recv = socket.ReceiveFrom(data, ref iep);                 // recv has number of bytes we received
                    //string stringData = Encoding.ASCII.GetString(data, 0, recv); // use this to print the received data

                    // Console.WriteLine("raw Discovery data = " + BitConverter.ToString(data, 0, recv));

                    // get Hermes MAC address from the payload
                    byte[] MAC = { 0, 0, 0, 0, 0, 0 };
                    Array.Copy(data, 3, MAC, 0, 6);
                    HermesMAC = BitConverter.ToString(MAC);

                    // check for HPSDR frame ID and type 2
                    if (data[0] == 0xEF && data[1] == 0xFE && data[2] == 0x02)
                    {
                        Console.WriteLine("\nFound a Hermes");
                        have_Hermes = true;

                        // get Hermes IP address from the IP Header
                        string Hermes_IP_Port = iep.ToString();
                        // remove :port# from end of string 
                        string[] Split = Hermes_IP_Port.Split(':');
                        receivedIP = Convert.ToString(Split[0]);
                    }
                }
                else
                {
                    Console.WriteLine("No data  from Hermes");
                    if ((++time_out) > 5)
                    {
                        Console.WriteLine("Time out!");
                        exit = true;
                        return false;
                    }
                }
            }

            HermesIP = receivedIP;

            return true;
        }


        // Send Start or Stop signal to Hermes
        public static bool start_stop(Socket socket, string Hermes_IP_address, byte run)
        {
            byte[] Ether_Type = new byte[] { 0xEF, 0xFE };
            byte[] HPSDR_Frame_type = new byte[] { 0x04 };
            byte run_state = run;

            // create an array to hold the data to send to the Network 
            // room for: Ether_Type data, HPSDR_Frame_type data, run_state, plus 60 null bytes
            byte[] data_to_send = new byte[Ether_Type.Length + HPSDR_Frame_type.Length + 1 + 60];
            data_to_send.Initialize();  // set to all zeroes, as zero is the default value for a byte

            // concatenate all the data into one array
            // get rid of unneeded 'Array.Resize' operations
            Ether_Type.CopyTo(data_to_send, 0);   // concatenate the data 
            HPSDR_Frame_type.CopyTo(data_to_send, Ether_Type.Length);
            data_to_send[Ether_Type.Length + HPSDR_Frame_type.Length] = run_state;

            // set IP address and port of the Hermes card we wish to communicate 
            IPEndPoint HermesEP = new IPEndPoint(IPAddress.Parse(Hermes_IP_address), 1024);

            try
            {
                //Send the UDP/IP packet out the network device
                int rc = socket.SendTo(data_to_send, HermesEP);
                return (true);
            }
            catch (Exception d)
            {
                Console.WriteLine("-- " + d.Message);
                return (false);
            }
        }
    }
}
