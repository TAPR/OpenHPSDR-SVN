﻿/*
 * Hermes VNA Software  - (C) 2012  Phil Harman VK6APH
 * 
 *  This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * 
 * This program is intended to be used with a Hermes SDR running FPGA code V1.7 or greater.
 * Hermes is switched into VNA mode by setting the following C&C bit:
 * 
 *      when C0 = 0x12   then C2[7]  if set enables VNA mode
 * 

 * The RF level provided at the Tx output is determined currently by the I signal sent to the Hermes Tx CORDIC.
 * The I signal is sent directly to the input of the Tx CORDIC within the Hermes FPGA code. The maximum I value is 19,274, rather than 2^15 -1, 
 * which takes into account the gain of the CORDIC.
 * 
 * The level could also  be set using the Drive Level. This is currently set to zero to ensure the user can't accidently overload/damage the Hermes input stages.
 * 
 * With VNA mode enabled the phase word that Hermes calculates, based on the frequency sent by the PC, is used by both the Rx and 
 * Tx CORDICs. This ensure phase coherence between the Tx and Rx signals.  The Hermes sampling rate is set at 48ksps. 
 * 
 * When taking a measurement, the decimated i.e. CIC and CFIR filtered, 24 bit, I & Q samples from Hermes are accumulated and the average of 1024 samples
 * used as the basis for VNA calculations.
 * 
 * 
 * 
 * Calibration file data format:
 * In Transmission mode the format is - "True" or "False"  (20dB attenuator setting)
 *                                      frequency1(Hz),0,0,0,0,0,0,0,calmag, calphase
 *                                      frequency2(Hz),0,0,0,0,0,0,0,calmag, calphase  etc
 * 
 * In Reflection mode the format is  - "True" or "False"  (20dB attenuator setting)
 *                                     frequency1(Hz),0, caldata1, caldata2, caldata3, caldata4, caldata5, caldata6,0,0
 *                                     frequency2(Hz),0, caldata1, caldata2, caldata3, caldata4, caldata5, caldata6,0,0  etc
 * 
 * Data is saved in CSV format.
 * 
 * Zlog data file format is -           "Zplots Generic Data"
 *                                      "Freq(MHz),Rs,Xs"
 *                                      frequency1(Hz),Impedance.Real,Impedance.Imaginary
 *                                      frequency2(Hz),Impedance.Real,Impedance.Imaginary  etc  
 * 
 * 
 * Measurement file data format:
 * In Transmission mode the format is - "Transmission"
 *                                      "x:\xxxx\.....\xxxx.csv"  (Path and name of calibration file used to make these measurements)
 *                                      frequency1(Hz),I_average, Q_average
 *                                      frequency2(Hz),I_average, Q_average  etc
 * 
 * In Reflection mode the format is  -  "Reflection"
 *                                      "x:\xxxx\.....\xxxx.csv"  (Path and name of calibration file used to make these measurements)
 *                                      frequency1(Hz), RhoA.Real, RhoA.Imaginary
 *                                      frequency2(Hz), RhoA.Real, RhoA.Imaginary  etc 
 * 
 * 
 * A number of settings are saved in VNA.ini when closing the program.
 * The format of the file is  -        "xxx.xxx.xxx.xxx"               (last PC IP address used)
 *                                     "Transmission" or "Reflection"  (last mode used)
 *                                     "x:\xxxxx\.....\xxxx.csv"       (Path and name of last calibration file used)
 *                                     "True" or "False"               (use last calibration file)  
 *                                     
 * VNA.ini is saved  in  C:\Users\<User Name>\AppData\Roaming\OpenHPSDR\VNA  (Win 7)
 *  
 * 
 * When 'ON' is clicked the code will do a Hermes discovery on the IP address from VNA.ini. If a Hermes is not 
 * found then it will attempt a discovery on all IP addresses found on the PC's network adapters.
 * 
 * 
 * 
 * How to draw the static lines for a Smith Chart:
 * Given a Normalised Resistance R' then the diameter of the real circle is  =  1/(1 + R') 
 * and for a normalised Reactance X' the diameter of the imaginary circle is = (X'^-0.5)^2  i.e. (1/SQRT(X'))^2
 * 

 * 
 * To do:
 * - Add slider to scale Smith Chart display
 * - Try effect of reducing averaging and its effect on noise floor. Checked noise floor using KK = -115dBm  with Tx not connected
 * - show more details of graph legends e.g. Rs (ohms), RL (dB) etc
 *
 * 
 * 
 * Future Possible Features:
 * - Conversion of S21 to S11 - see http://www.wetterlin.org/sam/SA/S21ImpedHTML/ImpedMeasS21.htm
 * 
 *    S11 = (Ro/2) * S21/(1-S21)   where Ro is characteristic impedance (usually 50 ohms) and S21 is complex

 * 
 * Versions:
 * V1.0.0 - 2012 Sept 24 - Initial release
 * V1.1.0 -           27 - Added lines joining dots on Smith Chart and Globalization
 * V1.2.0 -           28 - Added test for valid Measure file when opening
 *                       - When loading Measure file prompts to search if can't find associated Calibration file
 * V1.3.0 -           30 - Added mouse over on Smith Chart display to show frequency (if Calibrated) and Z 
 * V1.4.0 -      Oct   1 - Fixed bug where reading a second Measure file displayed previous Measure file data
 *                       - Added mouse over on Graphs and frequency on Smith Chart when mouse over.
 *                     3 - Fixed bug where initial display of Transmission data had wrong units when using Mouser over.
 *                       - Fixed bug where loading a Reflection Measurement file after a Transmission file did not display any data.
 *                       - Added frequency to Results table.
 *                       - When left mouse click on data point display all data.
 *                       - Allow user to change graph start and end display frequencies if within calibration range.
 *                       - Require re-calibration if calibration values are changed between measurements
 *                       - Disable log frequency scale if inappropriate range.
 *                     5 - Fixed 180 degree phase error in Transmission mode.
 *                       - Don't display any existing Reflection Results when changing to Transmission mode.
 *                       - Fixed bug that did not select correct Calibration mode if Calibration file loaded before checking ON
 *                     6 - If Calibration file loaded before clicking ON do not select last used mode from VNA.ini
 *                       - If Calibration file  already loaded prompt before auto-loading an associated file. 
 *                     7 - Added nfi to reading of Measure and Calibration files to fix language bug.  
 *                       - Fixed bug where Start and End selections not being initially displayed if in Transmission mode.
 *                     8 - Fixed bug where Start and End frequencies not being displayed when Calibration file loaded.
 *                       - Added  nfi where ever Convert was being used
 *                     9 - Fixed bug where Calibration file was not being loaded when Auto Load Calibration was checked
 * V1.5.0             11 - Removed dependance on Calibration file when displaying a  Measure file.  <frequency><data> now held in 
 *                         freqAndRohA (for Smith Chart), freqAndRohA (for Reflection graphs) and freqAndTrans (for transmission graphs)
 *                       - Enable user set Start and End frequencies to be set and change displayed data
 *                       - Fixed bug whereby Phase was not displayed the first time it was viewed
 *                    15 - Removed dependance on Calibration file Start and End frequencies when Measuring. User can select range within Calibration range.
 *                       - Added calFileLength variable that is set to the number of entries in a Calibration file
 *                    18 - When reading a Measure file use List<string> so can specify length of file and simplify 'for' loops
 *                       - When doing a Measure first clear any exsiting data so old data does not get displayed
 *                       - Increased Transmission range to +10 to -110dB and phase +/- 180 in 30 degree steps
 *                       - Set default min Transmission range to -110dB
 * V1.5.1             21 - Removed test for loaded Calibration file types so can switch modes without restarting the code
 * V1.5.2             22 - Added Repeat mode when right click Measure button.
 *                       - added "Nx" before  nfi to try and fix language issues
 *                    23 - fixed bug where Ls and Lp  was not being displayed - was using uh and not uH as the string test
 *                       - fixed bug where if right click Measure when not calibrated button turns green
 *                       - removed nfi from ToString() when writing data for ZPlot files to see if that fixes reading issues
 *                       - added save as S1P file, tests OK with Zplot and RFSim99
 * V1.5.3             24 - when Calibrating added check that a mode had been selected.
 * V1.5.4             25 - added check for Measurement and Calibration done before saving files
 *                       - Added nfi to Calibration range check 
 * V1.5.5             27 - fixed bug where log x would not work after a Transmission Measurement
 * V1.5.7                - released
 * V1.5.8             28 - Force file extension to be either .csv or .s1p
 * V1.5.9             29 - Fixed bug where log/normal selection did not show correct frequency range
 *                       - Try to fix issues with use of , instead of . in European languages. Removed nfi from all data input and display where marked  // $$$
 * V1.5.10            30 - Fixed bug in change of user Start frequency. Used length of file in drawGraph() to set display limits.
 *                    31 - Changed drawGraph() so that it uses setStartFreq and setEndFreq to determine the x axis to display.
 *                       - Replaced steps <= with  .Length in numerious places
 * V1.6.0       Nov   11 - First Formal release
 * V1.6.1       Jun    4 - New Ethernet code - derived from Kiss Konsole
 * 
 * 
 *          BUGs:

 *                     
 *          socket.ReceiveBufferSize = 2000
 *          move duplicate generation of arrays to a method.
 *          move duplicated generation of mhz1Lable.Visible = true  etc to a method;
 *          





 * 
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;   // use View > Output to see debug messages
using System.Numerics;      // for complex numbers 
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using System.Windows.Forms.DataVisualization.Charting;  // need this for the chart
using System.Drawing.Printing;
using System.Globalization;  // so we don't have country issues with '.' and ',' in *.csv files


namespace HermesVNAApplication
{
    public partial class Form1 : Form
    {

        // so we are region independent in terms of ',' and '.' for floats. also 'true' and 'false' are an issue
        // NumberFormatInfo.InvariantInfo uses . as a decimal separator

        NumberFormatInfo nfi = NumberFormatInfo.InvariantInfo;

        public static int adapterSelected = 1;                  // from Setup form, the number of the Network Adapter to use
        public static string Network_interfaces = null;         // holds a list with the description of each Network Adapter
        public static string Hermes_IP_address = "";            // Start() copies above value here, so it won't change until re-starting.
        public static string EthernetHostIPAddress = "";
        public static bool DoFastEthernetConnect = false; 
        public static string numberOfIPAdapters;
                      
        public bool Ethernet_thread_running = false; // set when thread is running
        public string Serial_Number;
        private Thread Ethernet_thread;	        // runs the loop facility
        const int rbufSize = 2048;
        const int iqsize = 1024;
        const int EP4BufSize = 8192;
        byte[] rbuf = new byte[rbufSize];   // EP6 samples read buffer 
        int loop_count = 0;                 // delay until we read FPGA code version from Hermes
        int Hermes_version;                 // Version number of Hermes FPGA code

        int sample_no = 0;

        int SampleRate = 48000;             // sample rate is fixed at 48kHz
        const byte sync = 0x7F;
        byte rc0, rc1, rc2, rc3, rc4;       // Command & Control bytes received from Hermes
        public int BandGain = 50;           // Determines gain for Penelope, set by what ever band selected
        float scaleOut = (float)Math.Pow(2, 15);  // scale factor to convert DSP output to 16-bit short int audio output sample

        byte[] to_Hermes = new byte[1024 + 8];    // array to send to Hermes via Ethernet, includes the 8 bytes before the data

        public byte OC_data = 0;

        volatile bool read_ready;           // set when we have read 1024 samples from Ethernet port

        const int outbufferSize = 1024;

        byte[] frequency = new byte[4];     // holds Tx and Rx frequency when in simplex mode and Tx when in Duplex   
        byte Drive_Level = 0;               // sets Hermes power output
        UInt16 PowerOut = 0;                // holds Hermes power out from ADC

        float[] SignalBuffer_I = new float[1024];
        float[] SignalBuffer_Q = new float[1024];

        // get a socket to send and receive on
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

        byte[] data = new byte[1032];

//        public string Network_interfaces = null;  // holds a list with the description of each Network Adapter
//        public int adapterSelected = 1;           // Defaults to first adapter if only one found

//        public string Hermes_IP_address = null;
        public static string HermesMAC;

        int Ethernet_count = 0;
        public string versionString = null;  // change for each release in AssemblyInfo.cs

        byte[] Filtered_Ethernet = new byte[1024];
        bool have_Hermes = false;            // true when we find an Hermes
        bool Calibrated = false;             // true when we have done a calibration at the set frequency.

        // initialise calibration error terms
        Complex e00 = new Complex(0, 0);
        Complex e11 = new Complex(0, 0);
        Complex Deltae = new Complex(0, 0);

        // set up an array to hold the measured Calibration values. Frequency will be held as the real part of the first entry e.g [0].Real
        // e00 is [1], e11 is [2], Deltae is [3] and  [4].Real is Transmission Mag and [4].Imaginary is Transmission Phase 
        public Complex[,] Calibration_data = null;

        int steps = 0;                      // number of frequency steps to take

        Complex[] Z = null;                 // holds the Z after taking a reading(s)

        string lastIP = null;               // IP address of the PC that was last used
        string lastHermesIP = null;               // IP address of the PC that was last used
        string lastMode = null;             // last mode used
        string lastCalFile = null;          // name of last Calibration file used

        bool Measured = false;              // set when a measurement has been taken
        double VSWR = 0;
        double[] SWR = null;
        Complex Zo = new Complex(50, 0);    // normalise to 50 ohms
        Complex[] RhoA = null;              // create complex variable (Rho Actual) and allow for 1000 steps 

        double[] Rpar = null;
        double[] Xpar = null;
        double[] RL = null;
        double[] Ls = null;
        double[] Lp = null;
        double[] Cs = null;
        double[] Cp = null;
        double[] lhsData = null;
        double[] rhsData = null;

        Complex[] graphData = null;
        Complex[] Impedance = null;

        bool haveCalfile = false;           // false when using a Measure file and no associated Calibration file
        bool transMode = false;             // set when a Transmission Measure file is being used
        bool run = true;
        string app_data_path = null;        // path to VNA.ini 
        string VNAPath = null;              // path to VNA.ini + VNA.ini
        string doc_data_path = null;        // path to saved files

        Complex[,] freqAndRhoA  = null;     // holds frequency and Rho actual for Smith Chart
        Complex[,] freqAndTrans = null;     // holds frequency, |G| and phase for Transmission Graph display
        Complex[,] freqAndChart = null;     // holds frequency and data for Reflection Graphs

        int calFileLength = 0;              // holds number of entries in a Calibration file. 
        int freqAndRhoA_length = 0;
        int freqAndChart_length = 0;
        int freqAndTrans_length = 0;

        bool measureReady = true;           // true when we can make a measurement
        

        public Form1()
        {
            InitializeComponent();
            Debug.Indent();                 // Indent Debug messages to make them easier to see
            txLevel.Maximum = 255;          // set max Tx level of slider control
            txLevel.Value   = 255;
            // don't display graphs
            smithPictureBox1.Visible = false;
            SetVNAChartVisible(false, false);
            // turns off the legends
            chart1.Legends[0].Enabled = false;

            // don't enable  the graph buttons
            groupDisplay.Enabled = false;

            // don't enable the Results group 
            Results.Enabled = false;

            // retrieve the version of this program (assembly)
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            System.Reflection.AssemblyName assemblyName = assembly.GetName();
            System.Version version = assemblyName.Version;
            versionString = string.Format("V{0}.{1}.{2}", version.Major, version.Minor, version.Build);
            this.Text = "Hermes Vector Network Analyser  - " + versionString  + "  4 June 2013";

            // determine where a default appDataDir would be located
            app_data_path =  Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) +  "\\OpenHPSDR\\VNA\\";
            VNAPath = app_data_path + "VNA.ini";

            // set a default documents path
            doc_data_path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\OpenHPSDR\\VNA\\";
            openFileDialog1.InitialDirectory = doc_data_path;
            saveFileDialog1.InitialDirectory = doc_data_path;

            buttonOnOff.BackColor = Color.LightGreen;

            // read the lines in the config file if it exists
            if (File.Exists(VNAPath))
            {
                try
                {
                    List<string> setup = ReadVNAini();
                    lastIP = setup[0];
                    lastHermesIP = setup[1];
                    lastMode = setup[2];
                    lastCalFile = setup[3];
                    autoLoad.Checked = Convert.ToBoolean(setup[4], nfi);
                    cbAttemptFastConnect.Checked = Convert.ToBoolean(setup[5], nfi);
                }
                catch (System.Exception ex)
                {
                    File.Delete(VNAPath);    // If error loading, delete old or corrupted ini file and start again.
                }
            }

            // if the documents directory does not already exist then create it
            if (!Directory.Exists(doc_data_path))
            {
                try
                {
	                Directory.CreateDirectory(doc_data_path);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Error creating user document directory " + doc_data_path);
                }
            }

            if (!Directory.Exists(app_data_path))
            {
                try
                {
                    Directory.CreateDirectory(app_data_path);
                }
                catch (System.Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Error creating user settings directory (where vna.ini is stored) " + app_data_path);
                }
            }    
       
            // pass this form to smithPictureBox1
            smithPictureBox1.SetForm(this);

         // Measure.Enabled = true;   // **** test 
         //  Calibrate.Enabled = true; // **** test 

           timer1.Enabled = false;
        }

        // make the start/stop (On/Off) button have the 'off' state display, where the button text is 'On' and color is normal
        void SetOffState()
        {
            Calibrate.Enabled = false;
            Measure.Enabled = false;
            Attenuator.Enabled = false;
            buttonOnOff.BackColor = Color.LightGreen;
            buttonOnOff.Text = "ON";
        }

        void buttonOnOff_Click(object sender, EventArgs e)
        {
            smithPictureBox1.Visible = false;
            SetVNAChartVisible(false, false);

            // if we are presently ON then toggle to OFF
            if (buttonOnOff.Text == "OFF")
            {
                StopEthernetThread();
                SetOffState();
                WriteVNAini();
                progressBar1.Value = 0;
                return;
            }
            int trys = 0;
            label23.Visible = false;
            while (!have_Hermes)

            {
                
                if (DoFastEthernetConnect)
                {
                    EthernetHostIPAddress = lastIP;
                    Hermes_IP_address = lastHermesIP;
                }

                // if a Calibration file has not already been loaded then select last mode 
                if (!haveCalfile)
                {
                    // select last mode used from VNA.ini
                    if (lastMode == "Reflection")
                    {
                        transMode = false;
                        modeRefChart.Checked = true;      
                    }
                    else
                    {
                        transMode = true;
                        modeTrans.Checked = true;     
                    }
                }

                byte[] data = new byte[1032];

                byte[] Filtered_Ethernet = new byte[1024];

                //            string localIP = null;
                //            string[] IP_array = null;
                //            int number_of_adapters = 0;

                if (EthernetDevice.Start())
                    have_Hermes = true; 
                trys++;
                if (trys > 1)
                {
                    label23.Text = "    " + trys.ToString() + " Attemps to find Hermes";
                    label23.Visible = true;
                    Application.DoEvents();
                }

                if (have_Hermes)
                {
                    Hermes_IP.Text = Hermes_IP_address;
                    Hermes_MAC.Text = HermesMAC;
                    PC_IP.Text = EthernetHostIPAddress;
                    if (trys > 1)
                    {
                        label23.Text = "Hermes found after " + trys.ToString() + " Attemps";
                        label23.Visible = true;
                    }
                    
                    break;
                }
                else
                {
                    StopEthernetThread();
                    SetOffState();
                    
                    // no Hermes board found so warn user and return
                 if (trys > 9)
                    {
                        MessageBox.Show("No Hermes board found (After 10 attempts).\r\n\r\n" + "Check Hermes is connected and powered.\r\n\r\n"
                        + "Can also try recycling Hermes Power...");
                        return;
                    }
                }        
            }

            // get number of network adapters, their name and IP address 
            // !!!!            number_of_adapters = Ethernet.GetNetworkInterfaces(ref localIP, ref IP_array);
            //            bool result = EthernetDevice.DiscoverHermesOnPort(ref  HermesDevice mhdList, ref localIP, ref IP_array);

            /*            IPAddress adapterAddr;
                        IPEndPoint iep;
                        bool IP_found = false;

                        if (!have_Hermes)
                        {
                            if (lastIP != "")
                            {
                                // check that the last IP used still exists in the list of available IP addresses
                                for (int x = 0; x < number_of_adapters; x++)
                                {
                                    if (lastIP == IP_array[x])
                                    {
                                        IP_found = true;
                                        break;
                                    }
                                    else
                                        IP_found = false;
                                }
                            }

                            // if it still exists then try and use it
                            if (IP_found)
                            {
                                adapterAddr = IPAddress.Parse(lastIP);
                                iep = new IPEndPoint(adapterAddr, 0);
                                // Do a Hermes Discovery to look for a board on the last used IP address
                                if (Hermes.Discovery(socket, ref Hermes_IP_address, ref HermesMAC, iep))
                                {
                                    Hermes_IP.Text = Hermes_IP_address;
                                    Hermes_MAC.Text = HermesMAC;
                                    have_Hermes = true;
                                    IP_found = true;
                                }
                                else
                                    IP_found = false;

                            }

                            // if can't find it then do a discovery on all the IP addresses
                            if (lastIP == "" || !IP_found)
                            {
                                for (int x = 0; x < number_of_adapters; x++)
                                {
                                    adapterAddr = IPAddress.Parse(IP_array[x]);
                                    iep = new IPEndPoint(adapterAddr, 0);

                                    // do an discovery on this adapter
                                    if (Hermes.Discovery(socket, ref Hermes_IP_address, ref HermesMAC, iep))
                                    {
                                        Hermes_IP.Text = Hermes_IP_address;
                                        Hermes_MAC.Text = HermesMAC;
                                        have_Hermes = true;
                                        // remove :port# from end of iep  and display 
                                        string[] Split = iep.ToString().Split(':');
                                        PC_IP.Text = Convert.ToString(Split[0],nfi);
                                        break;
                                    }
                                }
                            }

                            if (!have_Hermes)
                            {
                                StopEthernetThread();
                                SetOffState();

                                // no Hermes board found so warn user and return
                                MessageBox.Show("No Hermes board found  - Check Hermes is connected and powered");
                                return;
                            }

                        }
            */
            // we have a connection to a Hermes so enable everything.
            buttonOnOff.BackColor = Color.Pink;
            buttonOnOff.Text = "OFF";
            Attenuator.Enabled = true;
            Calibrate.Enabled = true;
            Measure.Enabled = true;

            socket.ReceiveBufferSize = 2000;        // use smaller buffer so we always read latest data
            socket.Blocking = true;

            Debug.WriteLine("Starting Ethernet Thread");

            // start thread to read Hermes data from Ethernet. EthernetLoop then calls Process_Data
            Ethernet_thread = new Thread(new ThreadStart(EthernetLoop));
            Ethernet_thread.Name = "Ethernet Loop";
            Ethernet_thread.Priority = ThreadPriority.Highest; // run Ethernet thread at high priority
            Ethernet_thread.Start();
            Ethernet_thread_running = true;

            Drive_Level = 0x00;
            // send a frame to Hermes selecting sample rate and Attenuator setting
            EthernetDevice.Ethernet_send(0, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);
            Thread.Sleep(20);
            EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);   // send frequency
            Thread.Sleep(20);
            EthernetDevice.Ethernet_send(2, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);  // Select VNA mode & send drive level

            // reset the sequence_number to match what Hermes does following a Discovery
            // sequence_number = 0; last_sequence_number = 0xFFFFFFFF;

            // start data from Hermes so we can read the code version
            if (!Hermes.start_stop(socket, Hermes_IP_address, 0x01)) // send start signal to Hermes, bit 0 is start/stop, bit 1 is wide spectrum
            {
                StopEthernetThread();
                SetOffState();

                MessageBox.Show("Error - write to Ethernet socket failed");
                return;
            }

            // get version # of  Hermes software revision
            while (loop_count < 10)     // wait for at least 10 reads so Hermes data is stable
            {
                Thread.Sleep(20);        // so we don't sit in too tight a loop
            }

            //if (!Hermes.start_stop(socket, Hermes_IP_address, 0x00)) // send stop signal to Hermes
            //{
            //    StopEthernetThread();
            //    SetOffState();

            //    MessageBox.Show("Error - write to Ethernet socket failed");
            //    return;
            //}

            // Convert Code version to a string
            string codever = ((float)Hermes_version / 10.0f).ToString("N1", nfi);

            if (Hermes_version >= 18)
                codeVersion.Text = codever;
            else
            {
                StopEthernetThread();
                SetOffState();

                MessageBox.Show("Error in Code Versions\nHermes code version should be 1.8 or higher\nActual version = " + codever);
                return;
            }

            // check if a Calibration file was loaded before ON was Clicked
            if (haveCalfile)
                Calibrated = true;


            // if autoLoad is checked then prompt to load the Calibration file specified in VNA.ini 
            if (autoLoad.Checked)
            {
                if (Calibrated) // if a Calibration file is already loaded then prompt to replace it or keep the present one
                {
                    if (MessageBox.Show("Calibration File alreay loaded - Replace?", "Load associated Calibration file", MessageBoxButtons.YesNo) == DialogResult.No)
                    {
                        if ((lastCalFile != null) && (lastCalFile.Length > 0))
                            readCalibrationFile(lastCalFile);  // load Calibration data
                    }
                    else  // search for a replacement Calibration file
                    {
                        toolStripMenuItem2_Click(this, EventArgs.Empty);
                    }
                }
                else   // load the calibration file
                {
                    readCalibrationFile(lastCalFile);  // load Calibration data    **** if this file read fails then we need to stop *****
                }
            }

        }


        void DisplayResults(Complex Z, double frequency)
        {
            // display the frequency these values were measured at
            freq.Text = (frequency/1e6).ToString("N6");  // $$$

            // display in Rs + Xs format
            string Z_text = null;
            string Rseries = null;

            // convert Z to a string
            VNA.ZtoText(Z, ref Z_text, ref Rseries);

            // display
            Imp.Text = Z_text;
            Rs.Text = Rseries;

            // calculate inductance or capacitance and display
            double Ind = 0, Cap = 0;

            if (Z.Imaginary > 0)
            {
                VNA.ComputeInductance(Z.Imaginary, frequency, ref Ind);
                Xs.Text = Ind.ToString("N2");  // $$$
                Type.Text = "Ls =";
                Units.Text = "uH";
            }
            else if (Z.Imaginary != 0)
            {
                VNA.ComputeCapacitance(Z.Imaginary, frequency, ref Cap);
                Xs.Text = Cap.ToString("N2");  // $$$
                Type.Text = "Cs =";
                Units.Text = "pf";
            }
            else
            {
                Xs.Text = "";
            }

            // calculate parallel equivalent resistance and inductance or capacitance
            if (Z.Imaginary == 0)
            {
                Rp.Text = Rs.Text;
                Xp.Text = null;
            }

            else
            {
                {
                    VNA.ComputeParallelFromSeries(Z.Real, Z.Imaginary, ref Rpar[steps], ref  Xpar[steps]);
                    Rp.Text = Rpar[steps].ToString("N2");  // $$$
                }

                if (Z.Imaginary > 0)
                {
                    VNA.ComputeInductance(Xpar[steps], frequency, ref Ind);
                    Xp.Text = Ind.ToString("N2"); // $$$
                    Typep.Text = "Lp =";
                    Unitsp.Text = "uH";
                }
                else
                {
                    VNA.ComputeCapacitance(Xpar[steps], frequency, ref Cap);
                    Xp.Text = Cap.ToString("N2");  // $$$
                    Typep.Text = "Cp =";
                    Unitsp.Text = "pf";
                }
            }

            // calculate and display SWR
            if (VNA.ComputeSWR(Z, Zo, ref  VSWR))
            {
                SWR_text.Text = VSWR.ToString("N2") + ":1"; // $$$
            }
            else
            {
                SWR_text.Text = "1:1";
            }

            // calculate and display Return Loss (RL)
            if (VNA.ComputeRL(Z, Zo, ref RL[steps]))
            {
                RLtext.Text = RL[steps].ToString("N2"); // $$$
            }
            else
            {
                Font font = new Font("Microsoft Sans Serif", 14);  // change size of font so symbol can be seen
                RLtext.Font = font;
                RLtext.Text = ((char)0x221E).ToString();  // infinity symbol :) // $$$
            }
        }

        // This thread reads data from Hermes
        public void EthernetLoop()                 
        {
            while (true) // do this forever 
            {
                bool data_available = false;

                // Poll the port to see if data is available 
                data_available = socket.Poll(100000, SelectMode.SelectRead);  // wait 100msec  for time out 

                if (data_available)
                {
                    // check received data is for EP6, if not return
                    int recv = socket.Receive(data);          // data holds the UDP Payload

                    if (data[3] == 0x06)
                    {

                        // get the sequence number
                        // Hermes_sequ_number = ((uint)(data[4] << 24) | (uint)(data[5] << 16) | (uint)(data[6] << 8) | (uint)data[7]);

                        // if (Hermes_sequ_number != unchecked(last_sequence_number + 1))
                        //     Debug.WriteLine("Sequence error! last = " + last_sequence_number + " current = " + Hermes_sequ_number);

                        // last_sequence_number = Hermes_sequ_number;

                        if (++Ethernet_count == 2) // we have two 1024 byte frames so concatenate and send to Process_Data
                        {
                            Ethernet_count = 0;  // reset Ethernet frame counter
                            // add to previous frame
                            Array.Copy(data, 8, rbuf, 1024, 1024);

                            // we now have 2048 samples so process them
                            Process_Data(ref rbuf);
                        }
                        // only one frame so save this one and wait for the next
                        else
                        {
                            Array.Copy(data, 8, rbuf, 0, 1024);
                        }
                    }
                }
            } // for ever 
        } // USB_loop 


        float[] tempSignalBuffer_Q = new float[1024];
        float[] tempSignalBuffer_I = new float[1024];

        public void Process_Data(ref byte[] rbuf)  
        {
            #region how Process_Data works
            /*
             * 
             Process_Data  capitalizes on the fact that the USB data from Ozy is well ordered and
             consistent as it arrives from the USB bulk read with respect to where sync pulses and Cn, I, Q,
             and L,R values are located in the array. A simple initial check for the presence of sync pulses
             at the beginning of rbuf is all that is done to establish that the data within rbuf is likely
             to be valid Rx data.

            C0 bits 7-3 is command and control "address"
            C0 bit 0 is PTT from Penelope
            C0 bit 1 is "dash"
            C0 bit 2 is "dot" 

            when C0 "address" == 00000xxx then
            C1 bit 0 is Mercury ADC overload bit
               bit 1 is Hermes IO1 input
               bit 2 is Hermes IO2 input
               bit 3 is Hermes IO3 input
               bit 4 is Hermes IO4 input
            C2 is Mercury software serial number
            C3 is Penelope software serial number
            C4 is Ozy software serial number

            when C0 is binary 00001xxx then 
            C1 is bits 15-8 of Penelope or Hermes forward power (only 12 bits used) AIN5
            C2 is bits 7-0 of Penelope or Hermes forward power AIN5
            C3 – Bits 15-8 of Forward Power from Alex or Apollo (AIN1)
            C4 – Bits 7-0  of Forward Power from Alex or Apollo (AIN1)

            when C0 is binary 00010xxx  then 
            C1 – Bits 15-8 of Reverse Power from Alex or Apollo (AIN2)
            C2 - Bits 7-0  of Reverse Power from Alex or Apollo (AIN2)
            C3 – Bits 15-8 of AIN3 from Penny or Hermes
            C4 – Bits 7-0  of AIN3 from Penny or Hermes

            when C0 is binary 00011xxx then
            C1 – Bits 15-8 of AIN4 from Penny or Hermes
            C2 - Bits 7-0  of AIN4 from Penny or Hermes
            C3 – Bits 15-8 of AIN6 from Penny or Hermes (13.8v supply on Hermes)
            C4 – Bits 7-0  of AIN6 from Penny or Hermes (13.8v supply on Hermes)


            For a full description of the USB protocol see the document in \trunk\Documents.
            
            If the force flag is set then we send C&C data to Ozy even if we don't have 
            valid I&Q or Microphone  audio. This is so that Ozy knows what clocks to use
            and will start sending data. 
              
             */

            #endregion

            byte[] temp = new byte[4];
            float scaleIn = (float)(1.0 / Math.Pow(2, 23));     // scale factor for converting 24-bit int from ADC to float
            UInt16 tempVolts = 0;

            // check that sync pulses are present in the front of rbuf
            if ((rbuf[0] == sync) && (rbuf[1] == sync) && (rbuf[2] == sync))
            {
                // sync is valid
            }
            else
            {
                Debug.WriteLine(String.Format("Sync Failed - rbuf = \t{0}\t{1}\t{2}", rbuf[0], rbuf[1], rbuf[2]));
                return;
            }

            for (int frame = 0; frame < 4; frame++)
            {
                int coarse_pointer = frame * 512; //512 bytes total in each frame
                rc0 = rbuf[coarse_pointer + 3];
                rc1 = rbuf[coarse_pointer + 4];
                rc2 = rbuf[coarse_pointer + 5];
                rc3 = rbuf[coarse_pointer + 6];
                rc4 = rbuf[coarse_pointer + 7];

                if ((rc0 & 0xf8) == 0)   // then C0 = 0000_0xxx
                {
                    // check for ADC overload - if so then change indicator colour
                    adcLED.BackColor = ((rc1 & 0x01) == 1) ? Color.Red : Control.DefaultBackColor;

                    // get serial # of Hermes software revisions
                    if (loop_count == 9)  // wait for 10 reads so Hermes data is stable
                    {
                        Hermes_version = (int)rc4;        // Version number of Hermes FPGA code
                        Debug.WriteLine("Hermes version = \t" + Hermes_version);
                    }
                    if (loop_count < 10)
                        loop_count++;
                }

                if ((rc0 & 0xF8) == 24)  // then C0 = 0001_1xxx
                    tempVolts = (UInt16)((UInt16)(rc3 << 8) + (UInt16)rc4);

                // get Hermes RF Power output
                if ((rc0 & 0xF8) == 8)  // then C0 = 0000_1xxx
                    PowerOut = (UInt16)((UInt16)(rc1 << 8) + (UInt16)rc2);

                // get the I, and Q data from rbuf, convert to float, & put into SignalBuffer
                for (int i = 8; i < 512; i += 8)
                {
                    int k = coarse_pointer + i;
                    // get I & Q,  I, use the following rather than BitConverter.ToInt32 since uses much less CPU

                    // get an Q sample
                    tempSignalBuffer_Q[sample_no] = scaleIn * (float)((rbuf[k + 2] << 8) | (rbuf[k + 1] << 16) | (rbuf[k] << 24));

                    // get a I sample
                    tempSignalBuffer_I[sample_no] = scaleIn * (float)((rbuf[k + 5] << 8) | (rbuf[k + 4] << 16) | (rbuf[k + 3] << 24));

                    // This single sample is now complete.
                    // The routine will generate 504 such samples from each rbuf that is processed.
                    // now check if all 1024 samples that we need have been acquired

                    if (++sample_no >= 1024)
                    {
                        sample_no = 0;
                        Thread.MemoryBarrier();
                        lock (readReadyLock)
                        {
                            if (!read_ready)
                            {
                                // do the copying here, making sure that it's a real copy
                                // this is done ONLY IF read_ready is false, meaning that we are looking
                                // for data on the application thread.
                                Array.Copy(tempSignalBuffer_I, SignalBuffer_I, tempSignalBuffer_I.Length);
                                Array.Copy(tempSignalBuffer_Q, SignalBuffer_Q, tempSignalBuffer_Q.Length);

                                // we have accumulated 1024 samples, so indicate that we have read enough samples
                                read_ready = true;  // flag used to indicate we have valid data
                            }
                        }
                    }
                }
            }
        }

        private void StopEthernetThread()
        {
            if (Ethernet_thread_running)
            {
                if (!Hermes.start_stop(socket, Hermes_IP_address, 0x00)) // send stop signal to Hermes
                    MessageBox.Show("Error - write to Ethernet socket failed");
                Ethernet_thread.Abort();  // stop Ethernet thread
                Ethernet_thread_running = false;
                Ethernet_thread = null;
            }
        }

        private void loadCalFileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            // Show the dialog and read the file.
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string fileName = openFileDialog1.FileName;
                readCalibrationFile(fileName);       
            }
        }
         
        // read the Measure file and display results
        private void readMeasureFile(string fileName)
        {
            Calibrated = false;
            haveCalfile = false;

            try
            {
                 List<string> MeasureData = File.ReadAllLines(fileName).ToList();  // read all lines of the file 

                 string[] getMode = MeasureData[0].Split(',');    // read the first string of the first line in case there are any trailing ','

                 string mode = getMode[0];

                 // read the first line of the file to determine measurement type 
                 if (mode != "Transmission" && mode != "Reflection")
                 {
                     MessageBox.Show("Not a Measure File!");
                     return;
                 }

                fileName = MeasureData[1];

                // check that the Calibration file exists and if so prompt user to load it
                if (File.Exists(fileName))
                {
                    if ( autoLoad.Checked || MessageBox.Show("Load associated Calibration File?", "Load Calibration", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        // load the file 
                        readCalibrationFile(fileName);
                        Calibrated = true;
                        haveCalfile = true;
                    }
                    else
                        haveCalfile = false;           // clear flag indicating no Calibration file is being used
                }
                else
                {
                    haveCalfile = false;               // clear flag indicating no Calibration file is being used
                }

                if (mode == "Transmission")
                    transMode = true;
                else
                    transMode = false;

                MeasureData.RemoveRange(0, 2);         // trim the none VNA data from the start of the file 

                string[] measureArray = new string[MeasureData.Count];

                int length = MeasureData.Count;

                // create arrays to hold the Measured data
                freqAndRhoA = new Complex[length, 2];
                freqAndChart = new Complex[length, 2];
                freqAndTrans = new Complex[length, 2];
                freqAndRhoA_length = length;
                freqAndChart_length = length;
                freqAndTrans_length = length;
                Z = new Complex[length];
                SWR = new double[length];
                RhoA = new Complex[length];
                Rpar = new double[length];
                Xpar = new double[length];
                RL = new double[length];
                Ls = new double[length];
                Lp = new double[length];
                Cs = new double[length];
                Cp = new double[length];
                lhsData = new double[length];
                rhsData = new double[length];
                graphData = new Complex[length];
                Impedance = new Complex[length];

                // read the measurement data  into either freqAndTrans or freqAndRhoA files
                for (int x = 0; x < length; x++)
                {
                    // split each line on a ','
                    measureArray = MeasureData[x].Split(',');              

                    if (transMode)
                    {
                        Complex tempTrans = new Complex(Convert.ToDouble(measureArray[1], nfi), Convert.ToDouble(measureArray[2], nfi));
                        Complex tempFreq = new Complex(Convert.ToDouble(measureArray[0], nfi), 0);
                        freqAndTrans[x, 0] = tempFreq.Real;   // get the frequency from the Measure file
                        freqAndTrans[x, 1] = tempTrans;       // get Transmission data from the Measure file
                    }
                    else
                    {
                        Complex tempRhoA = new Complex(Convert.ToDouble(measureArray[1], nfi), Convert.ToDouble(measureArray[2], nfi));
                        Complex tempFreq = new Complex(Convert.ToDouble(measureArray[0], nfi), 0);
                        freqAndRhoA[x, 0] = tempFreq.Real;   // get the frequency from the Measure file 
                        freqAndRhoA[x, 1] = tempRhoA;        // get RhoA from the Measure file
                    }
                }

                Measured = true;
                steps = length - 1;

                // display User Start & End Frequencies
                if (transMode)
                {
                    setStartFreq.Text = Convert.ToString(freqAndTrans[0, 0].Real / 1e6); // $$$
                    setEndFreq.Text = Convert.ToString(freqAndTrans[steps, 0].Real / 1e6); // $$$
                }
                else
                {
                    setStartFreq.Text = Convert.ToString(freqAndRhoA[0, 0].Real / 1e6); // $$$
                    setEndFreq.Text = Convert.ToString(freqAndRhoA[steps, 0].Real / 1e6); // $$$
                }

                // keep the Start and End frequencies in case we need to recover them
                previousStartFreq = setStartFreq.Text;
                previousEndFreq = setEndFreq.Text;

                // if Calibrated display Start and End Frequencies  plus number of steps from associated Calibration file
                if (Calibrated)
                {
                    startFreq.Text = Convert.ToString(Calibration_data[0, 0].Real / 1e6); // $$$
                    endFreq.Text = Convert.ToString(Calibration_data[steps, 0].Real / 1e6); // $$$
                    nbrSteps.Text = steps.ToString();  // $$$
                }
                else  // clear any previous Calibration data
                {
                    startFreq.Text = "";
                    endFreq.Text = "";
                    nbrSteps.Text = "";
                }

                // have the data so display it 
                if (transMode)
                {
                    setStartFreq.Visible = true;
                    setEndFreq.Visible = true;
                    startLable.Visible = true;
                    endLable.Visible = true;
                    mhz1Lable.Visible = true;
                    mhz2Lable.Visible = true;
                    modeTrans.Checked = true;
                    groupDisplay.Enabled = true;
                    SetVNAChartVisible(true, false);
                    leftScale.Text = "|G| dB";
                    rightScale.Text = "Phase [degrees]";

                    updateChart(freqAndTrans);

                }
                else  // format data for Smith Chart and Graph
                {
                    leftScale.Text = "SWR";
                    rightScale.Text = "(none)";
                    modeRefSmith.Checked = true;
                    groupDisplay.Enabled = false; 
                    SetVNAChartVisible(false, false);
                    smithPictureBox1.Visible = true;
                    smithPictureBox1.SetSteps(length, this.Font);

                    for (int x = 0; x < length; x++)                
                    {
                        calculateResults(x);
                    }

                    // display all results at the last frequency
                    DisplayResults(Z[length - 1], Convert.ToDouble(freqAndRhoA[length - 1, 0].Real));  

                    smithPictureBox1.Invalidate();          // display Smith Chart data 
                }

                startPoint = 0;         // reset start and end points for reading through freqAndxxxx file
                endPoint = steps;       
            }

            catch (IOException)
            {
                MessageBox.Show("Can't open Measurement File");
                Calibrated = false;
                return;
            }
        }

        private object readReadyLock = new object();

        private void GetDataBuffer()
        {
            lock (readReadyLock)
            {
                read_ready = false;
            }

            Thread.MemoryBarrier();

            // loop here until we have  1024 I & Q samples available
            while (true)
            {
                lock (readReadyLock)
                {
                    if (read_ready)
                    {
                        break;
                    }
                }

                // this ensures that read_ready is re-read each time the loop is performed
                Thread.MemoryBarrier();
            }
        }

        // read I & Q from Hermes
        public void getGamma(ref double Real, ref double Imag, float[] SignalBuffer_I, float[] SignalBuffer_Q)
        {
            // K9TRV thinks that this should be done TWICE!  That ensures that you have 'fresh' data, not
            // partly fresh and partly stale.  Otherwise, you need a mechanism to tell ProcessData to simply
            // dump the data on the ground until we want to collect it...
#if false
            read_ready = false;
            Thread.MemoryBarrier();
            while (!read_ready) // loop here until we have  1024 I & Q samples available
            {
                // this ensures that read_ready is re-read each time the loop is performed
                Thread.MemoryBarrier();
            }

#else
            // get one buffer.  THis may be partially old data
            GetDataBuffer();

            // Get a fresh buffer of data.  This is the one that we most likely want
            GetDataBuffer();
#endif

            float I_sample = 0;
            float Q_sample = 0;

            //average the 1024 I & Q samples
            for (int x = 0; x < 1024; x++)
            {
                I_sample += SignalBuffer_I[x];
                Q_sample += SignalBuffer_Q[x];
            }

            I_sample /= 1024;
            Q_sample /= 1024;

            // display average I and Q values
            I_average.Text = I_sample.ToString("N4"); // $$$
            Q_average.Text = Q_sample.ToString("N4"); // $$$

            Real = I_sample;
            Imag = Q_sample;
        }

        // read the Calibration file and display start and stop frequencies and steps 
        private void readCalibrationFile(string fileName)
        {
            transMode = false;

            Measured = false;       // clear mesured flag since loading new calibration file

            try
            {
                List<string> CalData = File.ReadAllLines(fileName).ToList();  // read all lines of the file 

                string[] getAtten = CalData[0].Split(',');    // read the first string of the first line in case there are any trailing ','

                // first verify we have a valid Calibration file
                if(getAtten[0] == "Reflection" || getAtten[0] == "Transmission")
                {
                    MessageBox.Show("Not a valid Calibration file!");
                    haveCalfile = false;
                    return;                
                }

                if (getAtten[0] == "True")
                    Attenuator.Checked = true;
                else
                    Attenuator.Checked = false;

                // create the Calibration_data array
                Calibration_data = new Complex[CalData.Count - 1, 5];

                // remove the first line from the file since this does not contain any Calibration data 
                CalData.RemoveAt(0);

                // read calibration data from file 
                for (int x = 0; x < CalData.Count; x++)
                {
                    // split each line on a ','
                    string[] calArray = CalData[x].Split(',');                            // calArray[0] = frequency, calArray[1] = e00.Real etc
                    double temp_freq = Convert.ToDouble(calArray[0], nfi);
                    Complex tempFrequency = new Complex(temp_freq, 0);

                    double e00_real = Convert.ToDouble(calArray[1], nfi);
                    double e00_imag = Convert.ToDouble(calArray[2], nfi);
                    Complex temp_e00 = new Complex(e00_real, e00_imag);

                    double e11_real = Convert.ToDouble(calArray[3], nfi);
                    double e11_imag = Convert.ToDouble(calArray[4], nfi);
                    Complex temp_e11 = new Complex(e11_real, e11_imag);

                    double Deltae_real = Convert.ToDouble(calArray[5], nfi);
                    double Deltae_imag = Convert.ToDouble(calArray[6], nfi);
                    Complex temp_Deltae = new Complex(Deltae_real, Deltae_imag);

                    double Trans_Mag = Convert.ToDouble(calArray[7], nfi);                // Transmission Mag
                    double Trans_Phase = Convert.ToDouble(calArray[8], nfi);              // Transmission Phase (degrees)
                    Complex temp_Trans = new Complex(Trans_Mag, Trans_Phase);

                    // store in calibration array
                    Calibration_data[x, 0] = temp_freq;
                    Calibration_data[x, 1] = temp_e00;
                    Calibration_data[x, 2] = temp_e11;
                    Calibration_data[x, 3] = temp_Deltae;
                    Calibration_data[x, 4] = temp_Trans;

                    steps = x;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Can't open Calibration File " + fileName);
                Calibrated = false;
                return;
            }

            haveCalfile = true;         // set have a valid Calibration file flag

            Calibrated = true;

            calFileLength =  steps + 1;   // save the number of entries in the Calibration file

            //save the path and name of the Calibration file so it is available for a Measure save.
            lastCalFile = fileName;

            // display start freq, stop freq and steps from file.               
            startFreq.Text = (Calibration_data[0, 0].Real / 1e6).ToString("N4");  // $$$
            if (steps > 0)
            {
                nbrSteps.Text = steps.ToString();  // $$$
                endFreq.Text = (Calibration_data[steps, 0].Real / 1e6).ToString("N4");  // $$$
            }
            else
            {
                nbrSteps.Text = null;
                endFreq.Text = null;
            }

            // select Transmission or Reflection mode depending of type of calibration file used
            if (Calibration_data[0, 4] == 0)
                modeRefSmith.Checked = true;
            else
            {
                transMode = true;
                modeTrans.Checked = true;
            }

            // set the user Start and End frequencies to those in the Calibration file 
            setEndFreq.Text = endFreq.Text;
            previousEndFreq = setEndFreq.Text;
            setStartFreq.Text = startFreq.Text;
            previousStartFreq = setStartFreq.Text;

            // save the name of the last used calibration file in VNA.ini when we exit the program
            lastCalFile = fileName;

        }

        private void writeCalibrationFile(string filename)
        {
            if (!Calibrated)
            {
                MessageBox.Show("Need to Calibrate first!");
                return;
            }
            
            // save calibration values as a line in CSV format in the path and file name selected

            List<string> calData = new List<string>();

            calData.Add(Attenuator.Checked.ToString(nfi));  // save the state of the 20dB attenuator

            for (int x = 0; x < calFileLength; x++)
            {
                calData.Add(Calibration_data[x, 0].Real.ToString(nfi)
                                + "," + Calibration_data[x, 1].Real.ToString(nfi) + "," + Calibration_data[x, 1].Imaginary.ToString(nfi)
                                + ',' + Calibration_data[x, 2].Real.ToString(nfi) + ',' + Calibration_data[x, 2].Imaginary.ToString(nfi)
                                + ',' + Calibration_data[x, 3].Real.ToString(nfi) + ',' + Calibration_data[x, 3].Imaginary.ToString(nfi)
                                + ',' + Calibration_data[x, 4].Real.ToString(nfi) + ',' + Calibration_data[x, 4].Imaginary.ToString(nfi));  // append a new line each time
            }


            try
            {
	            File.WriteAllLines(filename, calData);  // save the calibration data
            }
            catch (System.Exception ex)
            {
            	// an error occurred.  report it so that user can send an error report to us
                MessageBox.Show(ex.ToString(), "Unable to write calibration file " + filename);
            }

            // save the name of the calibration file in VNA.ini when we close the program
            lastCalFile = filename;
        }

        private void writeCalibrationFile()
        {
            if (!Calibrated)
            {
                MessageBox.Show("Need to Calibrate first!");
                return;
            }

            // force the file extension to be .csv
            saveFileDialog1.Filter = "VNA files | *.csv";

            // save the file name 
            saveFileDialog1.InitialDirectory = doc_data_path;       
            DialogResult result = saveFileDialog1.ShowDialog(); // Save the dialog

            if (result == DialogResult.Cancel)                  // user cancelled the save so return
                return;

            // Get file name.
            string file = saveFileDialog1.FileName;

            writeCalibrationFile(file);
        }

        // save the calibration data to a file
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            writeCalibrationFile();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        // Calibrate the VNA over the specified frequencies. Save the number of entries in the Calibration table in 
        // calFileLenght since we will need this value else where. 
        private void Calibrate_Click(object sender, EventArgs e)
        {
            
            // check a mode has been selected
            if (!modeRefChart.Checked && !modeRefSmith.Checked && !modeTrans.Checked)
            {
                MessageBox.Show("Need to select a Mode!");
                return;
            }
            
            // check for parameter errors
            if (startFreq.Text == "")
            {
                MessageBox.Show("No Start Frequency Entered!");
                return;
            }

            double Real = 0;
            double Imag = 0;

            // convert start, stop and steps to integers (Hz)
            if (endFreq.Text != "" && (nbrSteps.Text == "" || nbrSteps.Text == "0"))
            {
                MessageBox.Show("You need to enter number of steps");
                return;
            }

            if (nbrSteps.Text == "" || endFreq.Text == "")
                steps = 0;
            else
                steps = Convert.ToInt16(nbrSteps.Text);

            if (steps > 1000)
            {
                MessageBox.Show("Max number of Steps is 1000");
                return; 
            }

            double start = Convert.ToDouble(startFreq.Text);
            start *= 1e6;    // convert to Hz

            if (start > 60000000 || start < 100000)
            {
                MessageBox.Show("Start frequency must be  100kHz <> 60MHz");
                return;
            }

            double end;
            if (steps == 0 || endFreq.Text == "")
            {
                end = start;
            }
            else
            {
                end = Convert.ToDouble(endFreq.Text);
                end *= 1e6;    // convert to Hz
            }


            if (end < start || start > 60000000)
            {
                MessageBox.Show("End frequency must be > start & < 60MHz");
                return;
            }

            int frequencyStep = 0;

            // create the Calibration_data array
            Calibration_data = new Complex[steps + 1, 5];

            calFileLength = steps + 1;

            progressBar1.Maximum = steps;

            // clear current calibration data
            for (int x = 0; x < calFileLength; x++)
            {
                for (int y = 0; y < 5; y++)
                    Calibration_data[x, y] = Complex.Zero;
            }

            // calculate frequency step
            if (steps == 0)
                frequencyStep = 0;
            else
                frequencyStep = (((int)end - (int)start) / steps);

            // save frequency data in the Calibration_data array
            for (int x = 0; x < calFileLength; x++)
            {
                Complex freq = new Complex(start + (frequencyStep * x), 0);
                Calibration_data[x, 0] = freq;
            }


            //if (!Hermes.start_stop(socket, Hermes_IP_address, 0x01)) // send start signal to Hermes
            //{
            //    MessageBox.Show("Error - write to Ethernet socket failed");
            //    return;
            //}

            Thread.Sleep(50);                                     // delay to let data stabilise

            // set calibration standards - perfect for now
            Complex A1 = new Complex(1, 0);         // perfect Open   - Real & Imaginary values 
            Complex A2 = new Complex(-1, 0);        // perfect Short
            Complex A3 = new Complex(0, 0);         // perfect Load (50 ohms)

            Complex M1 = new Complex(0, 0);
            Complex M2 = new Complex(0, 0);
            Complex M3 = new Complex(0, 0);

            // now either do Reflection or Transmission Calibration

            double TransMagnitude = 0;
            double TransPhase = 0;

            if (modeTrans.Checked)
            {
                transMode = true;
                
                // Get Real and Imaginary from Hermes, with through connection, for all frequency steps
                if (MessageBox.Show("Calibrate using Through Connection", "Calibration", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                    return;

                for (int x = 0; x < calFileLength; x++)
                {
                    // format frequency ready for Hermes
                    frequency = BitConverter.GetBytes(Convert.ToInt32(Calibration_data[x, 0].Real, nfi));
                    EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);

                    Thread.Sleep(40);   // 40 mS delay so that data from Hermes is stable
                    getGamma(ref Real, ref Imag, SignalBuffer_I, SignalBuffer_Q);

                    // convert into Magnitude and Phase (degrees)
                    TransMagnitude = Math.Sqrt(Real * Real + Imag * Imag);
                    TransPhase = Math.Atan2(Imag, Real) * 180 / Math.PI;
                    Complex Trans_temp = new Complex(TransMagnitude, TransPhase);  // Real = Magnitude, Imaginary = Phase
                    // save the data
                    Calibration_data[x, 4] = Trans_temp;
                    progressBar1.Value = x;
                }

                //if (!Hermes.start_stop(socket, Hermes_IP_address, 0x00)) // send stop signal to Hermes
                //{
                //    MessageBox.Show("Error - write to Ethernet socket failed");
                //    return;
                //}

                Calibrated = true;
            }

            else // do Reflection Calibration process
            {
                transMode = false;

                // Get Gamma for M1 - Open load - for all frequency steps
                if (MessageBox.Show("Calibrate using Open Circuit", "Calibration", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                    return;

                for (int x = 0; x < calFileLength; x++)
                {
                    // format frequency ready for Hermes
                    frequency = BitConverter.GetBytes(Convert.ToInt32(Calibration_data[x, 0].Real, nfi));
                    EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);

                    Thread.Sleep(40);
                    getGamma(ref Real, ref Imag, SignalBuffer_I, SignalBuffer_Q);

                    Complex M1_temp = new Complex(Real, Imag);
                    Calibration_data[x, 1] = M1_temp;
                    progressBar1.Value = x;
                }

                // Get Gamma for M2 - Short load - for all frequency steps
                if (MessageBox.Show("Calibrate using Short Circuit", "Calibration", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                    return;
                progressBar1.Value = 0;

                for (int x = 0; x < calFileLength; x++)
                {
                    // format frequency ready for Hermes
                    frequency = BitConverter.GetBytes(Convert.ToInt32(Calibration_data[x, 0].Real, nfi));
                    EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);

                    Thread.Sleep(40);
                    getGamma(ref Real, ref Imag, SignalBuffer_I, SignalBuffer_Q);

                    Complex M2_temp = new Complex(Real, Imag);
                    Calibration_data[x, 2] = M2_temp;
                    progressBar1.Value = x;
                }

                // Get Gamma for M3 - Open load - for all frequency steps
                if (MessageBox.Show("Calibrate using 50 ohm Load", "Calibration", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                    return;
                progressBar1.Value = 0;

                for (int x = 0; x < calFileLength; x++)
                {
                    // format frequency ready for Hermes
                    frequency = BitConverter.GetBytes(Convert.ToInt32(Calibration_data[x, 0].Real, nfi));
                    EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);

                    Thread.Sleep(40);
                    getGamma(ref Real, ref Imag, SignalBuffer_I, SignalBuffer_Q);

                    Complex M3_temp = new Complex(Real, Imag);
                    Calibration_data[x, 3] = M3_temp;
                    progressBar1.Value = x;
                }

                //if (!Hermes.start_stop(socket, Hermes_IP_address, 0x00)) // send stop signal to Hermes
                //{
                //    MessageBox.Show("Error - write to Ethernet socket failed");
                //    return;
                //}

                // Over the frequency range compute One-Port Calibration method error terms from three independent 
                // measurements of calibration standards, Open, Short and Load 

                for (int x = 0; x < calFileLength; x++)   
                {
                    M1 = Calibration_data[x, 1]; M2 = Calibration_data[x, 2]; M3 = Calibration_data[x, 3];
                    bool returned = VNA.ComputeOnePortCalibrationErrorTerms(M1, A1, M2, A2, M3, A3, ref e00, ref e11, ref Deltae);

                    if (returned)
                    {
                        Calibrated = true;
                        Calibration_data[x, 1] = e00;
                        Calibration_data[x, 2] = e11;
                        Calibration_data[x, 3] = Deltae;
                    }
                    else
                    {
                        Calibrated = false;
                        MessageBox.Show(" OSL One-Port Calibration failed");
                        return;
                    }
                }

                calFileLength = steps + 1;          // save Calibration file length for when we save the file.
            }

            // prompt user to save the calibration data
            if (MessageBox.Show("Save calibration data?", "Calibration Complete", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                writeCalibrationFile();
            }

            // set user Start and End frequencies to the limits of the new Calibration file
            setStartFreq.Text = (Calibration_data[0, 0].Real / 1e6).ToString("N2");   // $$$
            setEndFreq.Text = (Calibration_data[steps, 0].Real / 1e6).ToString("N2"); // $$$
        }


        private void saveZplotFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // NOTE:  ZPlot data is NOT forced to use a '.' for the decimal place. This is so Excel can read the 
            //        file in the correct language format.             
            
            if (!Measured)
            {
                MessageBox.Show("Need to Measure first!");
                return;
            }
            
            if (modeTrans.Checked)
            {
                MessageBox.Show(" Can only save Zplot data in Reflection mode");
                return;
            }

            // force the file extension to be .csv
            saveFileDialog1.Filter = "VNA files | *.csv";

            // save the file name 
            saveFileDialog1.InitialDirectory = doc_data_path;   
            DialogResult result = saveFileDialog1.ShowDialog();         // Save the dialog

            if (result == DialogResult.Cancel)                          // user cancelled the save so return
                return;

            else
            {
                // Get file name.
                string file = saveFileDialog1.FileName;
                // save calibration values as a line in CSV format in the directory and file name selected

                List<string> calData = new List<string>();

                calData.Add("Zplots Generic Data");
                calData.Add("Freq(MHz)" + ',' + "Rs" + ',' + "Xs");

               // for (int x = 0; x <= steps; x++)
                for (int x = 0; x < freqAndRhoA_length; x++)   // was <= steps 
                {
                    calData.Add((freqAndRhoA[x, 0] / 1e6).Real.ToString() + ',' + Impedance[x].Real.ToString() + ',' + Impedance[x].Imaginary.ToString());
                }

                try
                {
	                File.WriteAllLines(file, calData);  // save the calibration data
                }
                catch (System.Exception ex)
                {
                	// error writing file
                    MessageBox.Show(ex.ToString(), "Unable to save Z-Plot file " + file);
                }
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            ExitAppProcessing();
        }


        public List<string> ReadVNAini()
        {
            // read the file into an array so we can process each entry
            List<string> setup = File.ReadAllLines(VNAPath).ToList();

            return setup;
        }

        public void WriteVNAini()
        {
            if (have_Hermes)
            {
                // save the current settings to VNA.ini
                List<string> lines = new List<string>();        // create a List<string> to hold all the output lines

                // each line of the output file, in output order
                lines.Add(PC_IP.Text);
                lines.Add(Hermes_IP.Text);
                if (modeTrans.Checked)
                {
                    lines.Add("Transmission");
                }
                else
                {
                    lines.Add("Reflection");
                }

                // path and name of last Calibration file used
                lines.Add(lastCalFile);
                // status of auto load Calibration file
                lines.Add(autoLoad.Checked.ToString(nfi));
                lines.Add(cbAttemptFastConnect.Checked.ToString(nfi));

                // write all the lines
                try
                {
                    File.WriteAllLines(VNAPath, lines);
                }
                catch (System.Exception ex)
                {
                    // error writing vna.ini file
                    MessageBox.Show(ex.ToString(), "Error writing VNA.ini file " + VNAPath);
                }
            }
        }

        // display data relating to LHS selection
        private void leftScale_SelectedIndexChanged(object sender, EventArgs e)
        {
            displayGraphData();
        }

        // display data relating to RHS selection
        private void rightScale_SelectedIndexChanged(object sender, EventArgs e)
        {
            displayGraphData();
        }


        private void displayGraphData()
        {
            if (!Calibrated && haveCalfile)
            {
                MessageBox.Show("VNA not Calibrated!");
                return;
            }

            if (!Measured)
            {
                MessageBox.Show("Need to make a measurement first!");
                return;
            }

            for (int x = 0; x < freqAndRhoA_length; x++)
            {
                // get the left graph data
                lhsData[x] = chart1.assignGraphData(leftScale.Text, SWR[x], Impedance[x], freqAndRhoA[x,1], Rpar[x], Xpar[x], RL[x], Ls[x], Lp[x], Cs[x], Cp[x], freqAndTrans[x, 1]);

                // get the right graph data
                rhsData[x] = chart1.assignGraphData(rightScale.Text, SWR[x], Impedance[x], freqAndRhoA[x,1], Rpar[x], Xpar[x], RL[x], Ls[x], Lp[x], Cs[x], Cp[x], freqAndTrans[x, 1]);

                Complex graphDataTemp = new Complex(lhsData[x], rhsData[x]);

                if (transMode)
                {
                    freqAndTrans[x, 0] = freqAndTrans[x, 0].Real;       // add the frequency data
                    freqAndTrans[x, 1] = graphDataTemp;                 // add the chart data to the frequency data
                }
                else
                {
                    freqAndChart[x, 0] = freqAndRhoA[x, 0].Real;        // add the frequency data
                    freqAndChart[x, 1] = graphDataTemp;                 // add the chart data to the frequency data
                }
            }

            // draw chart
            if (transMode)
            {
                leftScale.Text = "|G| dB";
                rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }
            else
                updateChart(freqAndChart);
        }

        private void lineButton_CheckedChanged(object sender, EventArgs e)
        {
            if (modeTrans.Checked)
            {
                leftScale.Text = "|G| dB"; rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }
            else
                updateChart(freqAndChart);
        }

        private void dotsButton_CheckedChanged(object sender, EventArgs e)
        {
            if (modeTrans.Checked)
            {
                leftScale.Text = "|G| dB"; rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }
            else
                updateChart(freqAndChart);
        }

        private void splineButton_CheckedChanged(object sender, EventArgs e)
        {
            if (modeTrans.Checked)
            {
                leftScale.Text = "|G| dB"; rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }
            else
                updateChart(freqAndChart);
        }

        private void autoRange_CheckedChanged(object sender, EventArgs e)
        {
            if (modeTrans.Checked)
            {
                leftScale.Text = "|G| dB"; rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }
            else
                updateChart(freqAndChart);
        }

        private void logXAxis_CheckedChanged(object sender, EventArgs e)
        {
            if (modeTrans.Checked)
            {
                leftScale.Text = "|G| dB"; rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);

            }
            else
                updateChart(freqAndChart);
        }

        private void modeRefChart_CheckedChanged(object sender, EventArgs e)
        {
           // return if not selected
            if (!modeRefChart.Checked)
                return;

            // remove all other displays except this one
            SetVNAChartVisible(false, false);
            smithPictureBox1.Visible = false;
            smithPictureBox1.clearSmithChart();
            // clear any tooltips
            toolTip1.Hide(smithPictureBox1);

            if (transMode)
            {
                MessageBox.Show("Not a Reflection Measurement File or not Calibrated in this Mode");
                return;
            }
            
            // display the user Start and End Freq.
            setStartFreq.Visible = true;

            startLable.Visible = true;
            endLable.Visible = true;
            mhz1Lable.Visible = true;
            mhz2Lable.Visible = true;
            previousStartFreq = setStartFreq.Text;
            previousEndFreq = setEndFreq.Text;
            
            if (Measured)
            {
                // check the correct Calibration file has been loaded if one is being used
                if (haveCalfile)
                {
                    if (!checkCalibrationFile())
                        return;
                }

                if (previousStartFreq == "")
                    setStartFreq.Text = Convert.ToString(freqAndRhoA[0, 0].Real / 1e6); // $$$
                else
                    setStartFreq.Text = previousStartFreq;

                setEndFreq.Visible = true;

                if (previousEndFreq == "")
                    setEndFreq.Text = Convert.ToString(freqAndRhoA[steps, 0].Real / 1e6); // $$$
                else
                    setEndFreq.Text = previousEndFreq;


                Results.Enabled = true;
                SetVNAChartVisible(true, true);

                smithPictureBox1.Visible = false;
                if (modeRefSmith.Checked)
                    groupDisplay.Enabled = false;    // disable graph type selection buttons
                else
                    groupDisplay.Enabled = true;     // enable graph type selection buttons

                Point smithEndFreq = new Point(444 + 75, 551);
                Point smithEndLable = new Point(412 + 75, 555);
                Point smithMHzLable = new Point(510 + 75, 555);

                // locate right hand user frequency on chart
                setEndFreq.Location = smithEndFreq;
                endLable.Location = smithEndLable;
                mhz2Lable.Location = smithMHzLable;              

                updateChart(freqAndChart);
            }
            else
            {
                SetVNAChartVisible(false, false);
            }           
        }

        private void modeRefSmith_CheckedChanged(object sender, EventArgs e)
        {
            if (!modeRefSmith.Checked)
                return;
            
            // remove all other displays except this one
            SetVNAChartVisible(false, false);
            smithPictureBox1.Visible = false;
            smithPictureBox1.clearSmithChart();
            // clear any tooltips
            toolTip1.Hide(smithPictureBox1);

            if (transMode)
            {
                MessageBox.Show("Not a Reflection Measurement File  or not Calibrated in this Mode");
                return;
            }
            

            if (Measured)
            {
                // check the correct Calibration file has been loaded if one is being used
                if (haveCalfile)
                {
                    if (!checkCalibrationFile())
                        return;
                }

                setStartFreq.Text = previousStartFreq;

                setEndFreq.Text = previousEndFreq;

                Results.Enabled = true;
                if (modeRefSmith.Checked)
                    groupDisplay.Enabled = false;    // disable graph type selection buttons
                else
                    groupDisplay.Enabled = true;     // enable graph type selection buttons

                SetVNAChartVisible(false, false);

                smithPictureBox1.Visible = true;
                smithPictureBox1.SetSteps(freqAndRhoA_length, this.Font);

                Point smithEndFreq  = new Point(444, 551);
                Point smithEndLable = new Point(412, 555);
                Point smithMHzLable = new Point(510, 555);

                // locate right hand user frequency on chart
                setEndFreq.Location = smithEndFreq;
                endLable.Location   = smithEndLable;
                mhz2Lable.Location  = smithMHzLable;


                updateSmithChart();                 // draws Smith Chart from user Start and End frequencies
            }

        }

        private void modeTrans_CheckedChanged(object sender, EventArgs e)
        {
            if (!modeTrans.Checked)
                return;

            // clear the Smith Chart from the screen
            smithPictureBox1.clearSmithChart();
            smithPictureBox1.Visible = false;

            // clear the chart from the screen
            SetVNAChartVisible(false, false);

            // clear any tool tips
            toolTip1.Hide(smithPictureBox1);

            // don't display the Results group
            Results.Enabled = false;

            // clear any previous range data
            chart1.ChartAreas[0].AxisX.Minimum = Double.NaN;
            chart1.ChartAreas[0].AxisX.Maximum = Double.NaN;

            // remove any Reflection results since we are in Transmission mode
            freq.Text = null;
            Imp.Text = null;
            Rs.Text = null;
            Xs.Text = null;
            Xp.Text = null;
            Rp.Text = null;
            SWR_text.Text = null;
            RLtext.Text = null;

            if (!transMode)
            {
                MessageBox.Show("Not a Transmission Measurement File or not Calibrated in this Mode");
                return;
            }
                  
            // display the user Start end End Freq.
            setStartFreq.Visible = true;
            setEndFreq.Visible = true;

            if (Measured)
            {
                // we may have arrived here from a Reflection measurement by user error so don't overwrite the Start and End freq in case we need to return
                if (freqAndTrans[0, 0].Real != 0.0)
                    setStartFreq.Text = Convert.ToString(freqAndTrans[0, 0].Real / 1e6);  // $$$

                if (freqAndTrans[freqAndTrans_length - 1 , 0].Real != 0.0)
                    setEndFreq.Text = Convert.ToString(freqAndTrans[freqAndTrans_length - 1, 0].Real / 1e6);  // $$$
            }

            startLable.Visible = true;
            endLable.Visible = true;
            mhz1Lable.Visible = true;
            mhz2Lable.Visible = true;
            previousStartFreq = setStartFreq.Text;
            previousEndFreq = setEndFreq.Text;
            
            if (Measured)
            {
                // check the correct Calibration file has been loaded if one is being used
                if (haveCalfile)
                {
                    if (!checkCalibrationFile())
                        return;
                }
                else
                {
                    // check if a Transmission Measure file and no calibration file
                    if (!transMode)
                    {
                        SetVNAChartVisible(false, false);
                        smithPictureBox1.Visible = false;
                        MessageBox.Show("Not a Transmission Measurement File");
                        return;
                    }
                }

                // VNAChart is visible BUT left/right scales are NOT
                SetVNAChartVisible(true, false);

                groupDisplay.Enabled = true;                 // enable graph type selection buttons

                Point smithEndFreq = new Point(444 + 75, 551);
                Point smithEndLable = new Point(412 + 75, 555);
                Point smithMHzLable = new Point(510 + 75, 555);

                // locate right hand user frequency on chart
                setEndFreq.Location = smithEndFreq;
                endLable.Location = smithEndLable;
                mhz2Lable.Location = smithMHzLable;
                leftScale.Text = "|G| dB";
                rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }
            else
            {
                SetVNAChartVisible(false, false);
                smithPictureBox1.Visible = false;
            }
        }

        void SetVNAChartVisible(bool isVisible, bool areScalesVisible)
        {
            leftScale.Visible = areScalesVisible;
            rightScale.Visible = areScalesVisible;
            chart1.Visible = isVisible;
            chart1.Enabled = isVisible;
        }

        // returns true if the appropriate Calibration file has been loaded
        private bool checkCalibrationFile()
        {
            if (!Calibrated)
            {
                MessageBox.Show("VNA is not Calibrated or wrong file type");
                Measure.BackColor = Control.DefaultBackColor;
                return false;
            }

            else  if (modeTrans.Checked & Calibration_data[0, 4] == 0)
            {
                MessageBox.Show("VNA is not Calibrated or wrong file type");
                Measure.BackColor = Control.DefaultBackColor;
                return false;
            }

            else if (modeRefChart.Checked & Calibration_data[0, 4] != 0)
            {
                MessageBox.Show("VNA is not Calibrated or wrong file type");
                Measure.BackColor = Control.DefaultBackColor;
                return false;
            }

            else
                return true;
        }

        private void Attenuator_CheckedChanged(object sender, EventArgs e)
        {
            if (Calibrated)
            {
                // if Attenuator is deselected warn user
                if (!Attenuator.Checked)
                    MessageBox.Show("Make sure you don't overload the VNA input!\n You may need to re-calibrate");
                else
                    MessageBox.Show("You may need to re-calibrate");
            } 
  
            // send the new Attenuator status to Hermes 
            EthernetDevice.Ethernet_send(0, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);
        }

        private void loadMeasureFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Show the dialog and read the file.
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                string fileName = openFileDialog1.FileName;
                readMeasureFile(fileName);
            }
        }

        private void saveMeasureFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // save measurement data in a file. Format is mode (trans or ref) on first line then last used Calibration file then frequency + data in CSV format
            // save the file name 

            if (!Measured)
            {
                MessageBox.Show("No Measurement data available to save");
                return;
            }
            
            string mode = null;

            // force the file extension to be .csv
            saveFileDialog1.Filter = "VNA files | *.csv";

            DialogResult result = saveFileDialog1.ShowDialog(); // Save the dialog

            if (result == DialogResult.Cancel)                  // user cancelled the save so return
                return;

            else
            {
                // Get file name.
                string file = saveFileDialog1.FileName;
                // save Measurement data as a line in CSV format in the directory and file name selected

                List<string> measureData = new List<string>();

                Complex[] Data = new Complex[1001];

                if (modeTrans.Checked)
                    mode = "Transmission";
                else
                    mode = "Reflection";

                measureData.Add(mode);

                // save name of last Calibration file and path
                measureData.Add(lastCalFile);

                for (int x = 0; x < freqAndTrans_length; x++)
                {
                   if (modeTrans.Checked)
                       measureData.Add(freqAndTrans[x, 0].Real.ToString(nfi) + "," + freqAndTrans[x,1].Real.ToString(nfi) + "," + freqAndTrans[x,1].Imaginary.ToString(nfi));
                   else
                       measureData.Add(freqAndRhoA[x, 0].Real.ToString(nfi) + "," + freqAndRhoA[x, 1].Real.ToString(nfi) + "," + freqAndRhoA[x, 1].Imaginary.ToString(nfi)); 
                }

                try
                {
	                File.WriteAllLines(file, measureData);  // save the calibration data
                }
                catch (System.Exception ex)
                {
                	// error writing measurement data
                    MessageBox.Show(ex.ToString(), "Error writing measurement file " + file);
                }
            }
        }

        private void calculateVNAData(int x)
        {

            // calculate impedance from G and Zo
            VNA.ComputeComplexImpedance(freqAndRhoA[x,1], Zo, ref Impedance[x]);

            // convert Impedance  into SWR
            VNA.ComputeSWR(Impedance[x], Zo, ref SWR[x]);

            // Calculate Return Loss
            if (!VNA.ComputeRL(Impedance[x], Zo, ref RL[x]))
                RL[x] = 1e10;

            // Calculate equivalent parallel Z
            VNA.ComputeParallelFromSeries(Impedance[x].Real, Impedance[x].Imaginary, ref Rpar[x], ref  Xpar[x]);

            // Calculate series inductance Ls
            VNA.ComputeInductance(Impedance[x].Imaginary, freqAndRhoA[x, 0].Real, ref Ls[x]);

            // Calculate parallel inductance Lp
            VNA.ComputeInductance(Xpar[x], freqAndRhoA[x, 0].Real, ref Lp[x]);  

            // Calculate series capacitance Cs
            VNA.ComputeCapacitance(Impedance[x].Imaginary, freqAndRhoA[x, 0].Real, ref Cs[x]);

            // Calculate parallel capacitance Cp
            VNA.ComputeCapacitance(Xpar[x], freqAndRhoA[x, 0].Real, ref Cp[x]);

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExitAppProcessing();
        }

        private void ExitAppProcessing()
        {
            // save settings in VNA.ini
            WriteVNAini();
            StopEthernetThread();
            socket.Close();

            Application.Exit();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs ea)
        {
            if (chart1.Visible == false && smithPictureBox1.Visible == false)
            {
                MessageBox.Show("Nothing to print!");
                return;
            }

            DialogResult dr = printDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                try
                {
                    Control controlToPrint;

                    // print the smith chart if selected, otherwise, print the chart
                    if (modeRefSmith.Checked)
                    {
                        controlToPrint = smithPictureBox1;
                    }
                    else
                    {
                        controlToPrint = chart1;
                    }

                    var bitmap = new Bitmap(controlToPrint.Width, controlToPrint.Height);

                    controlToPrint.DrawToBitmap(bitmap, new Rectangle(0, 0, controlToPrint.Width, controlToPrint.Height));

                    var pd = new PrintDocument();

                    // using 'fancy, new' "lambda" construct to create an anonymous function, so that
                    // we don't have to write a separate function body to hold the 'DrawImage' invocation.
                    pd.PrintPage += (s, e) => e.Graphics.DrawImage(bitmap, 100, 100);
                    pd.Print();
                }
                catch
                {
                    // an error occurred.  ignore it	
                }
            }
        }

        int lastx = -1;
        int lasty = -1;
        Complex clickZ = new Complex(0,0);
        double clickFreq = 0.0d;

        private void smithPictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            // When the Smith Chart is displayed and the mouse is over a measured value
            // display the Frequency and Impedance at that point.
            
            // NOTE:  Displaying a tooltip triggers a MouseMove event so need to 
            // check if the mouse has actually moved.
                
            int x, y;
            x = e.X;        // current mouse positions
            y = e.Y;

            // check if the mouse has really moved and the Smith Chart is visible, if not return
            if (lastx == x && lasty == y || !smithPictureBox1.Visible)
                return;

            double locateX; 
            double locateY;
            int lowX;
            int lowY;
            int highX;
            int highY;

            Complex Z = new Complex(0,0);
            string text = null;
            float tempFreq;

            int unity_circle_dia = Math.Min(smithPictureBox1.Height, smithPictureBox1.Width) - 40;
            int halfWidth = smithPictureBox1.Width / 2;

            toolTip1.Hide(smithPictureBox1);        // the mouse has moved so hide any previous toolTip

            // search through the location of the RhoA points and see if the mouse is close to one. If so display frequency and Z
            for (int i = startPoint; i <= endPoint; i++)
            {
                locateX = halfWidth + (unity_circle_dia / 2) * freqAndRhoA[i,1].Real;         // get x location of point on Smith Chart and reference to origin of PictureBox
                locateY = halfWidth - (unity_circle_dia / 2) * freqAndRhoA[i,1].Imaginary;    // ditto for y location

                // allow the mouse to be within a few pixels of the measurement point
                lowX =  (int)locateX - 3;
                lowY =  (int)locateY - 3;
                highX = (int)locateX + 3;
                highY = (int)locateY + 3;

                if (x >= lowX && x <= highX && y >= lowY && y <= highY)   // check if mouse is close to a measured value 
                {
                    toolTip1.Active = true;
                    // get Z at this point
                    VNA.ComputeComplexImpedance(freqAndRhoA[i,1], Zo, ref Z);
                    // form string to display 
                    tempFreq = (float)freqAndRhoA[i, 0].Real / 1e6f;
                    text = "Frequency = " + tempFreq.ToString("N2") + "MHz\n" + "R = " + Z.Real.ToString("N2") + "  X = " + Z.Imaginary.ToString("N2");  // $$$
                    toolTip1.Show(text, smithPictureBox1, (int)locateX + 10, (int)locateY + 10);     // offset the toolTip slightly so the mouse pointer does not obscure it
                    clickFreq = freqAndRhoA[i, 0].Real;
                    break;
                }
                else
                    toolTip1.Active = false;
            }

            lastx = x;  // save Mouse location so we can check if it moves
            lasty = y;
            clickZ = Z;  // save Z at this point so we can use it if the user clicks here


        }

        private void chart1_MouseMove(object sender, MouseEventArgs e)
        {
            // When a Graph is displayed and the mouse is over a measured value
            // display the Frequency and value at that point.

            // NOTE:  Displaying a tooltip triggers a MouseMove event so need to 
            // check if the mouse has actually moved.

            int x, y;
            x = e.X;        // current mouse positions
            y = e.Y;

            // check if the mouse has really moved and the Smith Chart is visible, if not return
            if (lastx == x && lasty == y || !chart1.Visible)
                return;

            double locateX;
            double locateY;
            int lowX;
            int lowY;
            int highX;
            int highY;
            Complex Z = new Complex(0, 0);

            var leftData = chart1.Series[0].Points;     // get all the data for drawing the LHS graph
            var rightData = chart1.Series[1].Points;    // ditto for RHS data

            ChartArea area = chart1.ChartAreas[0];

            string text = null;

            toolTip1.Hide(chart1);        // the mouse has moved so hide any previous toolTip

            // search through the location of the points and see if the mouse is close to one. If so display frequency and graph value
            for (int i = 0; i < displaySteps; i++)  
            {
                locateX = area.AxisX.ValueToPixelPosition(leftData[i].XValue);           // get x location of point on the Graph and convert to a pixel x location
                locateY = area.AxisY.ValueToPixelPosition(leftData[i].YValues[0]);       // ditto for y location

                // allow the mouse to be within a few pixels of the measurement point
                lowX = (int)locateX - 3;
                lowY = (int)locateY - 3;
                highX = (int)locateX + 3;
                highY = (int)locateY + 3;

                if (x >= lowX && x <= highX && y >= lowY && y <= highY)   // check if mouse is close to a measured value 
                {
                    toolTip1.Active = true;
                    // get Z at this point
                    if (transMode)               
                    {
                        VNA.ComputeComplexImpedance(freqAndTrans[i,1], Zo, ref Z);
                        clickFreq = freqAndTrans[i, 0].Real;
                    }
                    else  // its reflection mode
                    {
                        VNA.ComputeComplexImpedance(freqAndRhoA[startPoint + i,1], Zo, ref Z);
                        clickFreq = freqAndRhoA[startPoint + i, 0].Real;
                    }

                    // form string to display 
                    text = "Frequency = " + leftData[i].XValue.ToString("N4") + "MHz\n" + leftScale.Text + " = " + leftData[i].YValues[0].ToString("N2");  // $$$
                    toolTip1.Show(text, smithPictureBox1, (int)locateX + 10, (int)locateY + 10);     // offset the toolTip slightly so the mouse pointer does not obscure it
                    break;
                }

                // if the second graph is visible repeat for this scale
                else if (rightScale.Text != "(none)" || transMode)
                {
                    locateX = area.AxisX.ValueToPixelPosition(rightData[i].XValue);           // get x location of point on the Graph and convert to a pixel x location
                    locateY = area.AxisY2.ValueToPixelPosition(rightData[i].YValues[0]);      // ditto for y location

                    // allow the mouse to be within a few pixels of the measurement point
                    lowX = (int)locateX - 3;
                    lowY = (int)locateY - 3;
                    highX = (int)locateX + 3;
                    highY = (int)locateY + 3;

                    if (x >= lowX && x <= highX && y >= lowY && y <= highY)   // check if mouse is close to a measured value 
                    {
                        toolTip1.Active = true;
                        // get Z at this point
                        if (transMode)                   
                        {
                            VNA.ComputeComplexImpedance(freqAndTrans[i, 1], Zo, ref Z);
                            clickFreq = freqAndTrans[i, 0].Real;
                        }
                        else  // its reflection mode
                        {
                            VNA.ComputeComplexImpedance(freqAndRhoA[i, 1], Zo, ref Z);
                            clickFreq = freqAndRhoA[i, 0].Real;
                        }
                        // form string to display 
                        text = "Frequency = " + rightData[i].XValue.ToString("N2") + "MHz\n" + rightScale.Text + " = " + rightData[i].YValues[0].ToString("N2");  // $$$
                        toolTip1.Show(text, smithPictureBox1, (int)locateX + 10, (int)locateY + 10);     // offset the toolTip slightly so the mouse pointer does not obscure it
                        break;
                    }
                }
                else
                    toolTip1.Active = false;
            }

            lastx = x;  // save Mouse location so we can check if it moves
            lasty = y;
            clickZ = Z;  // save Z at this point so we can use it if the user clicks here

        }

        private void smithPictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
           // if a toolTip is active and the user left Mouse clicks then show all Values
            if (toolTip1.Active)
            {
                DisplayResults(clickZ, clickFreq);
            }
        }

        private void chart1_MouseClick(object sender, MouseEventArgs e)
        {
            // if a toolTip is active and the user left Mouse clicks then show all Values in Reflection mode
            if (toolTip1.Active && !transMode)
            {
                DisplayResults(clickZ, clickFreq);
            }
        }


        private void setStartFreq_KeyPress(object sender, KeyPressEventArgs e)
        {
           // allow the user to set the start frequency of the display
            if (e.KeyChar == (char)Keys.Enter)
                setStartFreq_Leave(this, EventArgs.Empty);
        }

        private void setEndFreq_KeyPress(object sender, KeyPressEventArgs e)
        {
           // allow the user to set the end frequency of the display
            if (e.KeyChar == (char)Keys.Enter)
                setEndFreq_Leave(this, EventArgs.Empty);
        }


        string previousEndFreq;

        private void setEndFreq_Leave(object sender, EventArgs e)
        {
           
            // allow the user to set the end frequency of the display
                double end = 0.0d;
                // check the data is valid 
                try
                {
                    end = Convert.ToDouble(setEndFreq.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("Error: invalid entry");
                    setEndFreq.Text = previousEndFreq;
                    return;
                }

                if (modeTrans.Checked)   // check higher frequency is not greater than the Measured range 
                {
                    if (Calibrated)
                    {
                        if (end <= Calibration_data[0, 0].Real / 1e6 || end <= Convert.ToDouble(setStartFreq.Text))
                        {
                            MessageBox.Show("Error: End Frequency < or = Start Frequency");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                        else if (end > Calibration_data[Calibration_data.Length/5 - 1, 0].Real / 1e6)
                        {
                            MessageBox.Show("Error: End Frequency out of Measured range");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                    }
                    else
                    {
                        if (end <= freqAndTrans[0, 0].Real / 1e6 || end <= Convert.ToDouble(setStartFreq.Text))
                        {
                            MessageBox.Show("Error: End Frequency < or = Start Frequency");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                        else if (end > freqAndTrans[freqAndTrans_length - 1, 0].Real / 1e6)
                        {
                            MessageBox.Show("Error: End Frequency out of Measured range");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                    }

                    leftScale.Text = "|G| dB";
                    rightScale.Text = "Phase [degrees]";

                    if (Measured)
                        updateChart(freqAndTrans);   // send new frequency to the Transmission chart

                }

                else if (modeRefSmith.Checked)
                {
                    if (Calibrated)
                    {
                        if (end <= Calibration_data[0, 0].Real / 1e6 || end <= Convert.ToDouble(setStartFreq.Text))
                        {
                            MessageBox.Show("Error: End Frequency < or = Start Frequency");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                        else if (end > Calibration_data[Calibration_data.Length/5 - 1, 0].Real / 1e6)
                        {
                            MessageBox.Show("Error: End Frequency out of Measured range");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                    }
                    else
                    {
                        if (end <= freqAndRhoA[0, 0].Real / 1e6 || end <= Convert.ToDouble(setStartFreq.Text))
                        {
                            MessageBox.Show("Error: End Frequency < or = Start Frequency");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                        else if (end > freqAndRhoA[freqAndRhoA_length - 1, 0].Real / 1e6)
                        {
                            MessageBox.Show("Error: End Frequency out of Measured range");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                    }

                    updateSmithChart();     // we are in Smith Chart mode so need to update
                }

                else
                {
                    if (Calibrated)
                    {
                        if (end <= Calibration_data[0, 0].Real / 1e6 || end <= Convert.ToDouble(setStartFreq.Text))
                        {
                            MessageBox.Show("Error: End Frequency < or = Start Frequency");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                        else if (end > Calibration_data[Calibration_data.Length/5 - 1, 0].Real / 1e6)
                        {
                            MessageBox.Show("Error: End Frequency out of Measured range");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                    }
                    else
                    {
                        if (end <= freqAndChart[0, 0].Real / 1e6 || end <= Convert.ToDouble(setStartFreq.Text))
                        {
                            MessageBox.Show("Error: End Frequency < or = Start Frequency");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                        else if (end > freqAndChart[freqAndRhoA_length - 1 , 0].Real / 1e6)
                        {
                            MessageBox.Show("Error: End Frequency out of Measured range");
                            setEndFreq.Text = previousEndFreq;
                            return;
                        }
                    }

                    updateChart(freqAndChart); 
                }

                previousEndFreq = setEndFreq.Text;              // save new end frequency
                   
        }


        string previousStartFreq;

        private void setStartFreq_Leave(object sender, EventArgs e)
        {
          
            // allow the user to set the start frequency of the display if range is valid 

            double start = 0.0d;
            // check the data is valid 
            try
            {
                start = Convert.ToDouble(setStartFreq.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Error: invalid entry");
                setStartFreq.Text = previousStartFreq;
                return;
            }

            // check lower frequecy is not less than the data or Calibration range
            if (modeTrans.Checked)
            {
                if (Calibrated)  // check against Calibration file data 
                {
                    if (start >= Calibration_data[steps, 0].Real / 1e6 || start >= Convert.ToDouble(setEndFreq.Text))
                    {
                        MessageBox.Show("Error: Start Frequency > or = End Frequency");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                    else if (start < Calibration_data[0, 0].Real / 1e6)
                    {

                        MessageBox.Show("Error: Start Frequency out of Measured range");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                }
                else   // check against Measure file data
                {
                    if (start >= freqAndTrans[steps, 0].Real / 1e6 || start >= Convert.ToDouble(setEndFreq.Text))
                    {
                        MessageBox.Show("Error: Start Frequency > or = End Frequency");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                    else if (start < freqAndTrans[0, 0].Real / 1e6)
                    {

                        MessageBox.Show("Error: Start Frequency out of Measured range");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                }

                leftScale.Text = "|G| dB";
                rightScale.Text = "Phase [degrees]";

                if (Measured)
                    updateChart(freqAndTrans);   // send new frequency to the Transmission chart
            }

            else if (modeRefSmith.Checked)
            {
                if (Calibrated)
                {
                    if (start >= Calibration_data[steps, 0].Real / 1e6 || start >= Convert.ToDouble(setEndFreq.Text))
                    {
                        MessageBox.Show("Error: Start Frequency > or = End Frequency");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                    else if (start < Calibration_data[0, 0].Real / 1e6)
                    {

                        MessageBox.Show("Error: Start Frequency out of Measured range");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                }
                else
                {
                    if (start >= freqAndRhoA[steps, 0].Real / 1e6 || start >= Convert.ToDouble(setEndFreq.Text))
                    {
                        MessageBox.Show("Error: Start Frequency > or = End Frequency");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                    else if (start < freqAndRhoA[0, 0].Real / 1e6)
                    {

                        MessageBox.Show("Error: Start Frequency out of Measured range");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                }

                updateSmithChart();                            // we are in Smith Chart mode so need to update
            }

            else
            {
                if (Calibrated)
                {
                    if (start >= Calibration_data[steps, 0].Real / 1e6 || start >= Convert.ToDouble(setEndFreq.Text))
                    {
                        MessageBox.Show("Error: Start Frequency > or = End Frequency");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                    else if (start < Calibration_data[0, 0].Real / 1e6)
                    {

                        MessageBox.Show("Error: Start Frequency out of Measured range");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                }
                else
                {
                    if (start >= freqAndChart[steps, 0].Real / 1e6 || start >= Convert.ToDouble(setEndFreq.Text))
                    {
                        MessageBox.Show("Error: Start Frequency > or = End Frequency");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                    else if (start < freqAndChart[0, 0].Real / 1e6)
                    {
                        MessageBox.Show("Error: Start Frequency out of Measured range");
                        setStartFreq.Text = previousStartFreq;
                        return;
                    }
                }

                updateChart(freqAndChart); 
            }

            previousStartFreq = setStartFreq.Text;
        
        }


        int startPoint = 0;
        int endPoint = 0;
        int displaySteps = 0;

        private void updateSmithChart()
        {
            if (!Measured)
                return;
            
            // The start or stop frequencies may have changed so need to create a new freqAndRohA array and display
            // find the new start frequency in the existing array

            double start = Convert.ToDouble(setStartFreq.Text);
            double end   = Convert.ToDouble(setEndFreq.Text);
            
            // look through frequencies in the freqAndRohA file and find the closest start frequency to that the user entered
            for (int i = 0; i < freqAndRhoA_length; i++)    
            {
                if (start <= freqAndRhoA[i, 0].Real / 1e6)
                {
                    startPoint = i;                            // this will be the starting point we plot from
                    break;
                }
            }

            // now find the closest end frequecy, search over the length of the freqAndRoha array

            for (int i = 0; i < freqAndRhoA_length; i++)
            {
                if (freqAndRhoA[i, 0].Real / 1e6 >= end)
                {
                    endPoint = i;                             // this will be the end point of the plot
                    break;
                }
            }

            displaySteps = (endPoint - startPoint) + 1;             // do not use steps since it's global and screws up else where

            smithPictureBox1.SetSteps(displaySteps, this.Font);     // set up arrays that the Smith Chart uses.

            Complex[,] temp = new Complex[displaySteps, 2];         // copy to temp array so we can preserve freqAndRohA 

            // trim the data before the new startPoint in RhoA
            Array.Copy(freqAndRhoA, startPoint * 2, temp, 0, (displaySteps * 2));

            for (int x = 0; x < displaySteps; x++)
            {
                smithPictureBox1.Set_Z(temp[x, 1], x);        // pass data to display to RhoAPlot[x]
            }
            
            smithPictureBox1.Invalidate();  // force display of Smith Chart data

            previousEndFreq = setEndFreq.Text;
            previousStartFreq = setStartFreq.Text;
        }


        private void updateChart(Complex[,] dataToDisplay)
        {
            // The start or stop frequencies may have changed so need to create a new freqAndTrans array and display
            // find the new start frequency in the existing array

            // set length of array 
            int length = dataToDisplay.Length / 2;   // Complex array so divide by 2

            double start = Convert.ToDouble(setStartFreq.Text);
            double end = Convert.ToDouble(setEndFreq.Text);

            // look through frequencies in the dataToDisplay file and find the closest start frequency to that the user entered
            for (int i = 0; i < length; i++)
            {
                if (dataToDisplay[i, 0].Real / 1e6 >= start)
                {
                    startPoint = i;                            // this will be the starting point we plot from
                    break;
                }
            }

            // now find the closest end frequecy, search over the length of the dataToDisplay array

            for (int i = 0; i < length; i++)
            {
                if (dataToDisplay[i, 0].Real / 1e6 >= end)
                {
                    endPoint = i;                             // this will be the end point of the plot
                    break;
                }
            }

            displaySteps = (endPoint - startPoint) + 1;             

            Complex[,] temp = new Complex[displaySteps, 2];         // copy to temp array so we can preserve freqAndRohA 

            // trim the data before the new startPoint in freqAndTrans
            Array.Copy(dataToDisplay, startPoint * 2, temp, 0, (displaySteps * 2));

            previousEndFreq = setEndFreq.Text;
            previousStartFreq = setStartFreq.Text;

            // now display new data 
            chart1.drawGraph(this, leftScale.Text, rightScale.Text,temp); 
        }


        private void calculateResults(int x)
        {           
            Z[x] = smithPictureBox1.Set_Z(freqAndRhoA[x,1], x);        // pass data to display to RhoAPlot[x] and return Z
            // data required if we require Graph displays
            calculateVNAData(x);  
            // get the left graph data
            lhsData[x] = chart1.assignGraphData(leftScale.Text,  SWR[x], Impedance[x], freqAndRhoA[x,1], Rpar[x], Xpar[x], RL[x], Ls[x], Lp[x], Cs[x], Cp[x], freqAndTrans[x, 1]);
            // get the right graph data
            rhsData[x] = chart1.assignGraphData(rightScale.Text, SWR[x], Impedance[x], freqAndRhoA[x,1], Rpar[x], Xpar[x], RL[x], Ls[x], Lp[x], Cs[x], Cp[x], freqAndTrans[x, 1]);
            // form the Chart data
            Complex temp = new Complex (lhsData[x], rhsData[x]);
            freqAndChart[x, 0] = freqAndRhoA[x, 0];  // frequency
            freqAndChart[x,1]  = temp;
        }

        private bool makeMeasurement()
        {

            measureReady = false;
            
            // need to determine if a correct calibration file has been loaded
            if (!checkCalibrationFile())
                return(false);

            // get Start and End frequecies
            double start = 0;
            double end = 0;

            try
            {
                start = Convert.ToDouble(setStartFreq.Text);
                end = Convert.ToDouble(setEndFreq.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Error reading Start or End Frequency");
                return(false);
            }

            // check if the range of frequencies we wish to measure over are covered by the current Calibration file
            bool foundStartFrequency = false;
            bool foundEndFrequency = false;

            // look through frequencies in the Calibration_data file and find the closest start frequency to that the user entered
            for (int i = 0; i < calFileLength; i++)
            {
                if (start <= Calibration_data[i, 0].Real / 1e6)
                {
                    startPoint = i;                            // this will be the starting point we plot from
                    foundStartFrequency = true;
                    break;
                }
            }

            // now find the closest end frequecy, search over the length of the Calibration_data array
            for (int i = 0; i < calFileLength; i++)
            {
                if (Calibration_data[i, 0].Real / 1e6 >= end)
                {
                    endPoint = i;                             // this will be the end point of the plot
                    foundEndFrequency = true;
                    break;
                }
            }

            // if we don't get a match then warn user and exit
            if (!foundStartFrequency || !foundEndFrequency)
            {
                MessageBox.Show("Calibration file does not cover requested Measurement range");
                return(false);
            }

            Measured = false;

            progressBar1.Value = 0;
            progressBar1.Maximum = endPoint - startPoint;

            double Real = 0; double Imag = 0;

            steps = endPoint - startPoint;

            //if (!Hermes.start_stop(socket, Hermes_IP_address, 0x01)) // send start signal to Hermes
            //{
            //    MessageBox.Show("Error - write to Ethernet socket failed");
            //    return;
            //}

            if (modeTrans.Checked)
            {

                // display the graph type selection buttons
                groupDisplay.Enabled = true;

                Results.Enabled = false;

                displaySteps = (endPoint - startPoint) + 1;                        
                freqAndTrans_length = displaySteps;

                // create array to hold measurement data
                freqAndTrans = new Complex[freqAndTrans_length, 2];

                // take measurements over range of frequencies specified and display
                for (int x = startPoint, y = 0; x <= endPoint; x++, y++)
                {
                    // convert measurement frequency to an array of bytes ready to send to Hermes
                    frequency = BitConverter.GetBytes(Convert.ToInt32(Calibration_data[x, 0].Real));

                    EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);

                    Thread.Sleep(40);   // delay so that the frequency is stable

                    // read Real and Imaginary of Z to be measured
                    getGamma(ref Real, ref Imag, SignalBuffer_I, SignalBuffer_Q);

                    double TransMagnitudeMeasured = Math.Sqrt(Real * Real + Imag * Imag);
                    double TransPhaseMeasured = Math.Atan2(Imag, Real) * 180 / Math.PI;

                    // Use calibration data to calculate actual Magnitude
                    double TransMagnitudeActual = TransMagnitudeMeasured / Calibration_data[x, 4].Real;

                    // convert Magnitude to dBs
                    double TransMagdB = -110;
                    if (TransMagnitudeActual != 0.0f)
                        TransMagdB = 20 * Math.Log10(TransMagnitudeActual);

                    // Use calibration data to calculate actual Phase
                    double TransPhaseActual = TransPhaseMeasured - Calibration_data[x, 4].Imaginary;

                    // limit phase to +/- 180 degrees
                    double angle = TransPhaseActual;

                    if (angle > 180.0f) angle = -(360.0f - angle);
                    if (angle < -180.0f) angle = (360.0f + angle);

                    Complex transTemp = new Complex(TransMagdB, angle);  // Real = Magnitude, Imaginary = phase

                    // save frequency and data in freqAndTrans array
                    freqAndTrans[y, 0] = Calibration_data[x, 0].Real;
                    freqAndTrans[y, 1] = transTemp;

                    progressBar1.Value = y;
                }

                // display result 
                Measured = true;
                SetVNAChartVisible(true, false);
                smithPictureBox1.Visible = false;
                leftScale.Text = "|G| dB";
                rightScale.Text = "Phase [degrees]";
                updateChart(freqAndTrans);
            }

            else  // its Reflection
            {

                Results.Enabled = true;
                displaySteps = (endPoint - startPoint) + 1;  

                // check if display is for the Smith Chart or Graph
                if (modeRefSmith.Checked)
                {
                    groupDisplay.Enabled = false;
                    SetVNAChartVisible(false, false);
                    smithPictureBox1.Visible = true;
                    smithPictureBox1.SetSteps(displaySteps, this.Font); // Draw the Smith Chart graphics
                }

                freqAndRhoA_length = displaySteps;
                freqAndChart_length = displaySteps;
                freqAndTrans_length = displaySteps;
                int length = displaySteps;

                // create arrays to hold measurement data
                freqAndRhoA = new Complex[freqAndRhoA_length, 2];
                freqAndChart = new Complex[freqAndChart_length, 2];
                freqAndTrans = new Complex[freqAndTrans_length, 2];
                Z = new Complex[length];
                SWR = new double[length];
                RhoA = new Complex[length];
                Rpar = new double[length];
                Xpar = new double[length];
                RL = new double[length];
                Ls = new double[length];
                Lp = new double[length];
                Cs = new double[length];
                Cp = new double[length];
                lhsData = new double[length];
                rhsData = new double[length];
                graphData = new Complex[length];
                Impedance = new Complex[length];

                smithPictureBox1.SetSteps(displaySteps, this.Font);         // set up arrays that the Smith Chart uses.

                // take measurements over range of frequencies specified and display
                for (int x = startPoint, y = 0; x <= endPoint; x++, y++)                // NOTE: loop test is for  < or =  !
                {
                    progressBar1.Value = y;

                    // convert measure frequency to an array of bytes ready to send to Hermes
                    frequency = BitConverter.GetBytes(Convert.ToInt32(Calibration_data[x, 0].Real));

                    EthernetDevice.Ethernet_send(1, run, socket, Hermes_IP_address, SampleRate, txLevel.Value, OC_data, frequency, Drive_Level, Attenuator.Checked);

                    Thread.Sleep(40);   // delay so that the frequency is stable

                    // read Real and Imaginary of Z to be measured
                    getGamma(ref Real, ref Imag, SignalBuffer_I, SignalBuffer_Q);

                    // create complex variable RhoM (Rho Measured) from real and imag values user entered
                    Complex RhoM = new Complex(Real, Imag);

                    // calculate actual Rho (RhoA) using calibration data 
                    e00 = Calibration_data[x, 1];
                    e11 = Calibration_data[x, 2];
                    Deltae = Calibration_data[x, 3];

                    VNA.ComputeReflCoeff(RhoM, e00, e11, Deltae, ref  RhoA[y]);

                    // form freqAndRhoA array
                    freqAndRhoA[y, 0] = Calibration_data[x, 0].Real;   // get frequency
                    freqAndRhoA[y, 1] = RhoA[y];                       // get data 

                    calculateResults(y);
                }


                if (modeRefChart.Checked || modeRefSmith.Checked)
                    DisplayResults(Impedance[Impedance.Length - 1], freqAndRhoA[freqAndRhoA_length - 1, 0].Real);        // display the measured data for the final frequency

                if (modeRefChart.Checked)
                {
                    // enable graph type selection buttons
                    groupDisplay.Enabled = true;

                    // remove the Smith Chart from the screen
                    smithPictureBox1.Visible = false;

                    SetVNAChartVisible(true, true);
                    updateChart(freqAndChart);
                }

                else
                    smithPictureBox1.Invalidate();

            }

            Measured = true;     // set flag indicating we have a valid Measurement so we can change display values

            //  if (!Hermes.start_stop(socket, Hermes_IP_address, 0x00)) // send stop signal to Hermes
            //      MessageBox.Show("Error - write to Ethernet socket failed");

            measureReady = true;

            return (true);
        }

        private void Measure_MouseDown(object sender, MouseEventArgs e)
        {
            // right click on Measure button to enter repeat mode
            
            if (e.Button == MouseButtons.Right)
            {
                if (Measure.BackColor == Color.Green)               // if already in repeat mode then exit
                {
                    Measure.BackColor = Control.DefaultBackColor;
                    timer1.Enabled = false;
                    timer1.Stop();
                }
                else                                             // select repeat mode 
                {
                    Measure.BackColor = Color.Green;
                    timer1.Enabled = true;
                    timer1.Start();
                    timer1.Interval = 100;
                    makeMeasurement();
                }
            }
            else if (Measure.BackColor == Color.Green)           // 'twas a Left click, if in repeat mode then exit
            {
                Measure.BackColor = Control.DefaultBackColor;
                timer1.Enabled = false;
                timer1.Stop();
            }
            else                                                 // none of the above so just take a Measurement
                makeMeasurement();
        }



        private void timer1_Tick(object sender, EventArgs e)
        {
            // when ever we get a timer tick and are in repeat mode then do another Measure            
            if (Measure.BackColor == Color.Green && measureReady)
            {
                if (!makeMeasurement())                             // make a Measurement and if it fails turn repeat mode off
                {
                    timer1.Enabled = false;
                    timer1.Stop();
                    Measure.BackColor = Control.DefaultBackColor;
                }
            }
        }

        private void saveS1PFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!Measured)
            {
                MessageBox.Show("Need to Measure first!");
                return;
            }
            
            
            // save Reflection data in S1P format for inport to external programs
            if (modeTrans.Checked)
            {
                MessageBox.Show(" Can only save S1P data in Reflection mode");
                return;
            }

            // force the file extension to be .s1p
            saveFileDialog1.Filter = "S Parameter |*.s1p";
            
            // save the file name 
            saveFileDialog1.InitialDirectory = doc_data_path;
            DialogResult result = saveFileDialog1.ShowDialog();         // Save the dialog

            if (result == DialogResult.Cancel)                          // user cancelled the save so return
                return;

            else
            {
                // Get file name.
                string file = saveFileDialog1.FileName;
                // save calibration values as a line in S1P format in the directory and file name selected

                List<string> s1pData = new List<string>();

                s1pData.Add("! Hermes VNA S1P File");
                s1pData.Add("# MHZ" + ' ' + "S" + ' ' + "MA" + ' ' + "R" + ' ' + "50");

                for (int x = 0; x <= steps; x++)
                {
                    s1pData.Add((freqAndRhoA[x, 0] / 1e6).Real.ToString(nfi) + ' ' + freqAndRhoA[x,1].Magnitude.ToString(nfi) + ' ' + (freqAndRhoA[x,1].Phase * 180 / Math.PI).ToString(nfi));
                }

                try
                {
                    File.WriteAllLines(file, s1pData);  // save the S1P data
                }
                catch (System.Exception ex)
                {
                    // error writing file
                    MessageBox.Show(ex.ToString(), "Unable to save S1P file " + file);
                }
            }
        }

        public static List<NetworkInterface> foundNics = new List<NetworkInterface>();

        // this will help us figure out which entries in the found Hermes/Hermes/Griffin board list
        // are valid by finding out which replies are on the proper port!
        // This seems necessary because, for example, Phil VK6APH seems to have his Hermes board
        // show up on BOTH ethernet ports!  Likely a wiring issue for his ethernet, but
        // if we can sort that out based on which port the discovery reply came in on, and whether
        // that port is on the same subnet with the board.
        public static List<NicProperties> nicProperties = new List<NicProperties>();


        public static void GetNetworkInterfaces()
        {
            // creat a string that contains the name and speed of each Network adapter 
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();

            foundNics.Clear();
            nicProperties.Clear();

            Network_interfaces = "";
            int adapterNumber = 1;

            foreach (NetworkInterface adapter in nics)
            {
                IPInterfaceProperties properties = adapter.GetIPProperties();

                // if it's not 'up' (operational), ignore it.  (Dan Quigley, 13 Aug 2011)
                if (adapter.OperationalStatus != OperationalStatus.Up)
                    continue;

                // if it's a loopback interface, ignore it!
                if (adapter.NetworkInterfaceType == NetworkInterfaceType.Loopback)
                    continue;

                // get rid of non-ethernet addresses
                if ((adapter.NetworkInterfaceType != NetworkInterfaceType.Ethernet) && (adapter.NetworkInterfaceType != NetworkInterfaceType.GigabitEthernet))
                    continue;

                Console.WriteLine("");      // a blank line
                Console.WriteLine(adapter.Description);
                Console.WriteLine(String.Empty.PadLeft(adapter.Description.Length, '='));
                Console.WriteLine("  Interface type .......................... : {0}", adapter.NetworkInterfaceType);
                Console.WriteLine("  Physical Address ........................ : {0}", adapter.GetPhysicalAddress().ToString());
                Console.WriteLine("  Is receive only.......................... : {0}", adapter.IsReceiveOnly);
                Console.WriteLine("  Multicast................................ : {0}", adapter.SupportsMulticast);
                Console.WriteLine("  Speed    ................................ : {0}", adapter.Speed);

                // list unicast addresses
                UnicastIPAddressInformationCollection c = properties.UnicastAddresses;
                foreach (UnicastIPAddressInformation a in c)
                {
                    IPAddress addr = a.Address;
                    Console.WriteLine("  Unicast Addr ............................ : {0}", addr.ToString());
                    IPAddress mask = a.IPv4Mask;
                    Console.WriteLine("  Unicast Mask ............................ : {0}", (mask == null ? "null" : mask.ToString()));

                    NicProperties np = new NicProperties();
                    np.ipv4Address = a.Address;
                    np.ipv4Mask = a.IPv4Mask;

                    nicProperties.Add(np);
                }

                // list multicast addresses
                MulticastIPAddressInformationCollection m = properties.MulticastAddresses;
                foreach (MulticastIPAddressInformation a in m)
                {
                    IPAddress addr = a.Address;
                    Console.WriteLine("  Multicast Addr .......................... : {0}", addr.ToString());
                }

                // if the length of the network adapter name is > 31 characters then trim it, if shorter then pad to 31.
                // Need to use fixed width font - Courier New
                string speed = "  " + (adapter.Speed / 1000000).ToString() + "T";
                if (adapter.Description.Length > 31)
                {
                    Network_interfaces += adapterNumber++.ToString() + ". " + adapter.Description.Remove(31) + speed + "\n";
                }
                else
                {
                    Network_interfaces += adapterNumber++.ToString() + ". " + adapter.Description.PadRight(31, ' ') + speed + "\n";
                }

                foundNics.Add(adapter);
            }

            Console.WriteLine(Network_interfaces);

            // display number of adapters on Setup form
            Form1.numberOfIPAdapters = (adapterNumber - 1).ToString();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VNAAboutBox k = new VNAAboutBox();
            k.ShowDialog();
        }

        private void cbAttemptFastConnect_CheckedChanged(object sender, EventArgs e)
        {
            DoFastEthernetConnect = cbAttemptFastConnect.Checked;
        }

// more methods here 


    }
}

public enum DeviceType : int
{
    Hermes = 0,
    Metis = 1,
    Griffin = 2
}

public class HermesDevice
{
    public  DeviceType deviceType;   // which type of device
    public  byte codeVersion;        // reported code version type
    public  bool InUse;              // whether already in use
    public  string IPAddress;        // currently, an IPV4 address
    public  string MACAddress;       // a physical (MAC) address
    public  IPAddress hostPortIPAddress;
}

public class NicProperties
{
    public IPAddress ipv4Address;
    public IPAddress ipv4Mask;
}

