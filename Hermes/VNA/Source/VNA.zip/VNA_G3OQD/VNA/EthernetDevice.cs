﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Net.NetworkInformation;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Diagnostics;

namespace HermesVNAApplication
{
    class EthernetDevice        // !!!! : HPSDRDevice
    {
        uint sequence_number = 0;  // 32 bit unsigned integer for the sequence number
        uint last_sequence_number;
        //uint Spectrum_sequ_number = 0;
        uint last_spectrum_sequence_number;

        protected byte[] to_Device;
//        protected Form1 MainForm = null;
        public static string Network_interfaces = null;  // holds a list with the description of each Network Adapter
        public string EthernetHostIPAddress = "";


        const int toDeviceSize = 1024 + 8;             // now includes the 8 bytes before the data

        // get the name of this PC and, using it, the IP address of the first adapter
        static String strHostName = Dns.GetHostName();
        public IPAddress[] addr = Dns.GetHostEntry(Dns.GetHostName()).AddressList;

        // get a socket to send and receive on
        public static Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

        // set an endpoint
        IPEndPoint iep;

        // receive data buffer for EP6 (normal data)
        byte[] data = new byte[1032];

        int Ethernet_count = 0;

        const int HermesPort = 1024;
        const int LocalPort = 0;
        private IPEndPoint HermesEP = null;

/* !!!!        public EthernetDevice(Form1 mainForm)
            : base(mainForm, toDeviceSize)
        {
        }
*/
        private static bool DiscoverHermesOnPort(ref List<HermesDevice> mhdList, IPAddress HostIP, IPAddress targetIP)
        {
            bool result = false;

            // configure a new socket object for each Ethernet port we're scanning
            var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

            // Listen to data on this PC's IP address. Allow the program to allocate a free port.
            var iep = new IPEndPoint(HostIP, LocalPort);  // was iep = new IPEndPoint(ipa, 0);

            try
            {
                // bind to socket and Port
                socket.Bind(iep);
                socket.ReceiveBufferSize = 0xFFFF;   // no lost frame counts at 192kHz with this setting
                socket.Blocking = true;

                IPEndPoint localEndPoint = (IPEndPoint)socket.LocalEndPoint;
                Console.WriteLine("Looking for Hermes boards using host adapter IP {0}, port {1}", localEndPoint.Address, localEndPoint.Port);

                if (Hermes_Discovery(ref mhdList, iep, targetIP, socket))
                {
                    result = true;
                }

            }
            catch (System.Exception ex)
            {
                Console.WriteLine("Caught an exception while binding a socket to endpoint {0}.  Exception was: {1} ", iep.ToString(), ex.ToString());
                result = false;
            }
            finally
            {
                socket.Close();
                socket = null;
            }

            return result;
        }

        public static bool Start()
        {
            // adapterSelected ranges from 1 thru number Of Adapters.  However, we need an 'index', which
            // is adapterSelected-1.
            int adapterIndex = Form1.adapterSelected - 1;

            // get the name of this PC and, using it, the IP address of the first adapter
            IPAddress[] addr = Dns.GetHostEntry(strHostName).AddressList;

            Form1.GetNetworkInterfaces();

            List<IPAddress> addrList = new List<IPAddress>();

            // make a list of all the adapters that we found in Dns.GetHostEntry(strHostName).AddressList
            foreach (IPAddress a in addr)
            {
                // make sure to get only IPV4 addresses!
                // test added because Erik Anderson noted an issue on Windows 7.  May have been in the socket
                // construction or binding below.
                if (a.AddressFamily == AddressFamily.InterNetwork)
                {
                    addrList.Add(a);
                }
            }

            bool foundHermes = false;
            List<HermesDevice> mhd = new List<HermesDevice>();

            if (Form1.DoFastEthernetConnect && (Form1.EthernetHostIPAddress.Length > 0) && (Form1.Hermes_IP_address.Length > 0))
            {
                // if success set foundHermes to true, and fill in ONE mhd entry.
                IPAddress targetIP;
                IPAddress hostIP;
                if (IPAddress.TryParse(Form1.EthernetHostIPAddress, out hostIP) && IPAddress.TryParse(Form1.Hermes_IP_address, out targetIP))
                {
                    Console.WriteLine(String.Format("Attempting fast re-connect to host adapter {0}, Hermes IP {1}", Form1.EthernetHostIPAddress, Form1.Hermes_IP_address));

                    if (DiscoverHermesOnPort(ref mhd, hostIP, targetIP))
                    {
                        foundHermes = true;

                        // make sure that there is only one entry in the list!
                        if (mhd.Count > 0)
                        {
                            // remove the extra ones that don't match!
                            HermesDevice m2 = null;
                            foreach (var m in mhd)
                            {
                                if (m.IPAddress.CompareTo(Form1.Hermes_IP_address) == 0)
                                {
                                    m2 = m;
                                }
                            }

                            // clear the list and put our single element in it, if we found it.
                            mhd.Clear();
                            if (m2 != null)
                            {
                                mhd.Add(m2);
                            }
                            else
                            {
                                foundHermes = false;
                            }
                        }
                    }
                }
            }

            if (!foundHermes)
            {
                foreach (IPAddress ipa in addrList)
                {
                    if (DiscoverHermesOnPort(ref mhd, ipa, null))
                    {
                        foundHermes = true;
                    }
                }
            }

            if (!foundHermes)
                return false;
            int chosenDevice = 0;
//        }
/*
            if (mhd.Count > 1)
            {
                // show selection dialog.
                DeviceChooserForm dcf = new DeviceChooserForm(mhd, MainForm.HermesMAC);
                DialogResult dr = dcf.ShowDialog();
                if (dr == DialogResult.Cancel)
                {
                    MainForm.OnOffButton_Click(this, EventArgs.Empty); // Toggle ON/OFF Button to OFF
                    return;
                }

                chosenDevice = dcf.GetChosenItem();
            }
*/
            Form1.Hermes_IP_address = mhd[chosenDevice].IPAddress;
            Form1.HermesMAC = mhd[chosenDevice].MACAddress;
            Form1.EthernetHostIPAddress = mhd[chosenDevice].hostPortIPAddress.ToString();
            return foundHermes;

        }
/*
            iep = new IPEndPoint(mhd[chosenDevice].hostPortIPAddress, LocalPort);

            // bind (open) the socket so we can use the Hermes/Hermes that was found/selected
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            socket.Bind(iep);
            socket.ReceiveBufferSize = 0xFFFF;   // no lost frame counts at 192kHz with this setting
            socket.SendBufferSize = 1032;
            socket.Blocking = true;

            // create an endpoint for sending to Hermes
            HermesEP = new IPEndPoint(IPAddress.Parse(MainForm.Hermes_IP_address), HermesPort);

            IPEndPoint localEndPoint2 = (IPEndPoint)socket.LocalEndPoint;
            Console.WriteLine("Starting Ethernet Thread: host adapter IP {0}, port {1}", localEndPoint2.Address, localEndPoint2.Port);

            //// start thread to read Hermes data from Ethernet.   DataLoop merely calls Process_Data, 
            //// which calls usb_bulk_read() and rcvr.Process(),
            //// and stuffs the demodulated audio into AudioRing buffer
            loop_count = 0;         // reset count so that data will be re-collected
            Data_thread = new Thread(new ThreadStart(DataLoop));
            Data_thread.Name = "Ethernet Loop";
            Data_thread.Priority = ThreadPriority.Highest; // run USB thread at high priority
            Data_thread.Start();
            Data_thread_running = true;

            Data_send(true); // send a frame to Ozy to prime the pump
            Thread.Sleep(20);
            Data_send(true); // send a frame to Ozy to prime the pump,with freq this time 

            // reset the sequence_number to match what Hermes does following a Discovery
            sequence_number = 0;
            last_sequence_number = 0xFFFFFFFF;
            //Spectrum_sequ_number = 0;
            last_spectrum_sequence_number = 0xFFFFFFFF;

            // start data from Hermes
            Hermes_start_stop(MainForm.Hermes_IP_address, 0x03);   // bit 0 is start, bit 1 is wide spectrum

            MainForm.timer1.Enabled = true;  // start timer for bandscope update etc.

            MainForm.timer2.Enabled = true;  // used by Clip LED, fires every 100mS
            MainForm.timer2.Interval = 100;
            MainForm.timer3.Enabled = true;  // used by VOX, fires on user VOX delay setting 
            MainForm.timer3.Interval = 400;
            MainForm.timer4.Enabled = true;  // used by noise gate, fires on Gate delay setting
            MainForm.timer4.Interval = 100;

            // update the display on the SetupForm if it is being displayed
            if (MainForm.Setup_form != null)
            {
                MainForm.Setup_form.UpdateEthernetInfo();
            }
        }

        public void Stop()
        {
            if (Data_thread_running)
            {
                Data_thread.Abort();  // stop data thread

                // stop data from Hermes
                Hermes_start_stop(MainForm.Hermes_IP_address, 0x00); // stop data from Hermes
                socket.Close();
                socket = null;

                Data_thread_running = false;
            }

            if (MainForm.timer1.Enabled)
                MainForm.timer1.Stop();          // stop timer1

            MainForm.SyncLED.BackColor = SystemColors.Control;  // no sync so set LED to background
        }

        public void Close()
        {
            if (Data_thread_running)
            {
                Data_thread.Abort();  // stop data thread

                Hermes_start_stop(MainForm.Hermes_IP_address, 0x00);
                socket.Close();
                socket = null;

                Data_thread_running = false;
            }
        }

/*
        public void ProcessWideBandData(ref byte[] EP4buf)
        {
            if (MainForm.doWideBand) // display wide band spectrum
            {
                // EP4 contains 4k x 16 bit raw ADC samples
                // Actually it may contain 4 times that! (16k x 16 bit raw adc samples)
                {
                    float scaleIn = (float)(1.0 / Math.Pow(2, 15));
                    float Sample, RealAverage;

                    RealAverage = 0.0f;
                    int i, k;
                    for (i = 0, k = 0; i < Form1.EP4BufSize; i += 2, ++k)
                    {
                        // use this rather than BitConverter.ToInt16()...since its faster and less CPU intensive
                        // without the '(short)' in there, the value doesn't get sign-extended!
                        // so what should be small negative values show up as (almost) positive values?
                        Sample = scaleIn * (float)(short)((EP4buf[i + 1] << 8) | (EP4buf[i]));
                        RealAverage += Sample;
                        SamplesReal[k] = Sample;
                    }

                    RealAverage /= (float)k;
                    for (i = 0; i < k; ++i)
                    {
                        SamplesReal[i] -= RealAverage;      // Subtract average
                        SamplesImag[i] = SamplesReal[i];    // temporary -- soon will do digital down-conversion
                        // with sin & cos, so we'll actually have I & Q data to enter.
                    }

                    FullBandwidthSpectrum.Process(SamplesReal, SamplesImag, Form1.EP4BufSize / 2);
                }
            }
        }
*/
/*
        // This thread runs at program load and reads data Hermes
        private void DataLoop()
        {
            uint Hermes_sequ_number;
            uint Spectrum_sequ_number;
            bool start = false;

            while (true) // do this forever 
            {
                bool data_available = false;

                // Poll the port to see if data is available 
                data_available = socket.Poll(100000, SelectMode.SelectRead);  // wait 100msec  for time out *****

                if (data_available)
                {
                    // check received data is for EP4 or EP6, if not return
                    int recv = socket.Receive(data);          // data holds the UDP Payload

                    // check for EP6 data (receiver)
                    if ((data[3] == 0x06) && MainForm.KK_on)
                    {
                        // set flag so know we are receiving valid data used in timer to set Sync LED
                        MainForm.received_flag = true;

                        // get the sequence number
                        Hermes_sequ_number = ((uint)(data[4] << 24) | (uint)(data[5] << 16) | (uint)(data[6] << 8) | (uint)data[7]);

                        if (Hermes_sequ_number == unchecked(last_sequence_number + 1))
                        {
                            MainForm.IsInSequence = true;  // use this to set the colour of the Sync LED when the timer fires
                        }
                        else
                        {
                            MainForm.IsInSequence = false;
                            Console.WriteLine("EP6 Sequence error! last = " + last_sequence_number + " current = " + Hermes_sequ_number);
                        }

                        last_sequence_number = Hermes_sequ_number;

                        if (++Ethernet_count == 2) // we have two 1024 byte frames so concatinate and send to Process_Data
                        {
                            Ethernet_count = 0;  // reset Ethernet frame counter
                            // add to previous frame
                            Array.Copy(data, 8, rbuf, 1024, 1024);

                            // we now have 2048 samples so process them
                            Process_Data(ref rbuf);
                        }
                        // only one frame so save this one and wait for the next
                        else
                        {
                            Array.Copy(data, 8, rbuf, 0, 1024);
                        }
                    }
*/
/*
                    // check for data to EP4 i.e. wideband spectrum data
                    if ((data[3] == 0x04) && MainForm.KK_on)
                    {
                        Spectrum_sequ_number = ((uint)(data[4] << 24) | (uint)(data[5] << 16) | (uint)(data[6] << 8) | (uint)data[7]);

                        if (Spectrum_sequ_number != unchecked(last_spectrum_sequence_number + 1))
                        {
                            Console.WriteLine("EP4 (WideBand) Sequence error! last = " + last_sequence_number + " current = " + Spectrum_sequ_number);
                            // if a wideband (EP4) sequence error, discard any accumulated frames so that all the
                            // wideband data is from the same group.
                            start = false;
                        }

                        last_spectrum_sequence_number = Spectrum_sequ_number;

                        // start copying data when last 3 bits of sequence number are 0.  This is ONLY VALID if
                        // EP4BufSize = 8192 (4096 I and 4096 Q samples).
                        // if '16k I and 16k Q samples, then EP4BufSize = 32768, and the bitmask has 2 more bits in it (0x1f)
                        // AND Spectrum_count goes to 31, not 7.
                        if ((sampleMask & data[7]) == 0)
                        {
                            start = true;
                            Spectrum_count = 0;  // reset Spectrum frame counter
                        }

                        if (start)
                        {
                            Array.Copy(data, 8, EP4buf, (Spectrum_count * 1024), 1024);
                        }

                        if (Spectrum_count++ == (numWideBuffers - 1)) // we have numWideBuffers by 1024 byte frames so concatenate and process
                        {
                            start = false;
                            ProcessWideBandData(ref EP4buf);
                        }
                    } 
                }
            } 
        }

        // Send two frames of 512 bytes to Hermes/Hermes/Griffin
        // The left & right audio to be sent comes from AudioRing buffer, which is filled by ProcessData()
        protected void Data_send(bool force)
        {
            // if force is set then send C&C anyway even if no data available
            if (!force)
            {
                // ringBufferRequiredSize I words + ringBufferRequiredSize Q words plus  2x sync (6 bytes) plus 2x C&C (10 bytes) = 1024 bytes
                if (AudioRing.Count < 126)
                {
                    return;  // need enough data for 2 frames
                }
            }

            Data_send_core(2, 8);

            if (MainForm.KK_on)  // send the frames to Ozy using UDP/IP
            {
                // put the header info into the start of the to_Device buffer
                to_Device[0] = 0xEF;   // first 2 bytes are ether type
                to_Device[1] = 0xFE;
                to_Device[2] = 0x01;   // frame type = 1
                to_Device[3] = 0x02;   // end point = EP2

                // insert sequence number.  It's in 'big-endian' order (MSByte first, LSByte last)
                to_Device[4] = (byte)(sequence_number >> 24);
                to_Device[5] = (byte)((sequence_number >> 16) & 0xff);
                to_Device[6] = (byte)((sequence_number >> 8) & 0xff);
                to_Device[7] = (byte)(sequence_number & 0xff);

                try
                {
                    //Send the UDP/IP packet out the network device
                    int rc = socket.SendTo(to_Device, HermesEP);
                }
                catch (Exception d)
                {
                    Console.WriteLine("-- " + d.Message);
                }

                // increment the sequence number for next time.  Make sure it's an unchecked operation, so that
                // no ArithmeticException is thrown when it wraps back to 0 (overflow.)
                unchecked
                {
                    sequence_number++;
                }
            }
        }
        
        /* 
          * Send a UDP/IP packet to the IP address and port of the Hermes board
          * Payload is 
          *      0xEFFE,0x04,run, 60 nulls
          *    where run = 0x00 to stop data and 0x01 to start
          * 
          */

        private void Hermes_start_stop(string Hermes_IP_address, byte run)
        {
            byte[] Ether_Type = new byte[] { 0xEF, 0xFE };
            byte[] HPSDR_Frame_type = new byte[] { 0x04 };
            byte run_state = run;

            // create an array to hold the data to send to the Network 
            byte[] data_to_send = new byte[64];

            // concatenate all the data into one array
            Ether_Type.CopyTo(data_to_send, 0);   // concatinate the data

            HPSDR_Frame_type.CopyTo(data_to_send, 2);

            data_to_send[3] = run_state;

            // set IP address and port of the Hermes card we wish to communicate 
            IPEndPoint HermesEP = new IPEndPoint(IPAddress.Parse(Hermes_IP_address), HermesPort);

            try
            {
                // Send the UDP/IP packet out the network device
                int rc = socket.SendTo(data_to_send, HermesEP);
            }
            catch (Exception d)
            {
                Console.WriteLine("-- " + d.Message);
            }
        }

        /*
          Broadcast a Hermes Discovery packet and look for boards.
         
          Code Broadcasts (IP address FF.FF.FF.FF, the 'all broadcast address') a  UDP/IP PC HPSDR discovery packet on port 1024 with the following format:

              0xEFFE, 0x02, <sixty bytes of zero>
          
         It then listens on the PC *from* port for a Hermes reply with the following format:
    
              0xEFFE, 0x02, Hermes MAC address <41 bytes of zero>
          
         Hermes' IP address is obtained from the packet header.
          
        */

        private static bool Hermes_Discovery(ref List<HermesDevice> mhdList, IPEndPoint iep, IPAddress targetIP, Socket socket)
        {
            string HermesMAC;
            socket.SendBufferSize = 1024;

            // set up HPSDR Hermes discovery packet
            byte[] Hermes_discovery = new byte[63];
            Array.Clear(Hermes_discovery, 0, Hermes_discovery.Length);

            byte[] Hermes_discovery_preamble = new byte[] { 0xEF, 0xFE, 0x02 };
            Hermes_discovery_preamble.CopyTo(Hermes_discovery, 0);

            bool have_Hermes = false;            // true when we find an Hermes
            int time_out = 0;

            // set socket option so that broadcast is allowed.
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);

            // need this so we can Broadcast on the socket
            IPEndPoint broadcast = new IPEndPoint(IPAddress.Broadcast, HermesPort);
            string receivedIP = "";   // the IP address Hermes obtains; assigned, from DHCP or APIPA (169.254.x.y)

            IPAddress hostPortIPAddress = iep.Address;

            IPAddress hostPortMask = IPAddress.Broadcast;

            // find the subnet mask that goes with this host port
            foreach (NicProperties n in Form1.nicProperties)
            {
                if (hostPortIPAddress.Equals(n.ipv4Address))
                {
                    hostPortMask = n.ipv4Mask;
                    break;
                }
            }

            // send every second until we either find an Hermes board or exceed the number of attempts
            while (!have_Hermes)            // #### djm should loop for a while in case there are multiple Hermes boards
            {
                // send a broadcast to the port 1024
                socket.SendTo(Hermes_discovery, broadcast);

                // now listen on  send port for any Hermes cards
                Console.WriteLine("Ready to receive.... ");
                int recv;
                byte[] data = new byte[100];

                bool data_available;

                // await possibly multiple replies, if there are multiple Hermes/Hermes on this port,
                // which MIGHT be the 'any' port, 0.0.0.0
                do
                {
                    // Poll the port to see if data is available 
                    data_available = socket.Poll(100000, SelectMode.SelectRead);  // wait 100 msec  for time out    

                    if (data_available)
                    {
                        EndPoint remoteEP = new IPEndPoint(IPAddress.None, 0);
                        recv = socket.ReceiveFrom(data, ref remoteEP);                 // recv has number of bytes we received
                        //string stringData = Encoding.ASCII.GetString(data, 0, recv); // use this to print the received data

                        Console.WriteLine("raw Discovery data = " + BitConverter.ToString(data, 0, recv));

                        // get Hermes MAC address from the payload
                        byte[] MAC = { 0, 0, 0, 0, 0, 0 };
                        Array.Copy(data, 3, MAC, 0, 6);
                        HermesMAC = BitConverter.ToString(MAC);
                        byte codeVersion = data[9];
                        byte boardType = data[10];

                        // check for HPSDR frame ID and type 2 (not currently streaming data, which also means 'not yet in use')
                        // changed to find Hermes boards, even if alreay in use!  This prevents the need to power-cycle Hermes.
                        // (G Byrkit, 8 Jan 2012)
                        if ((data[0] == 0xEF) && (data[1] == 0xFE) && ((data[2] & 0x02) != 0))
                        {
                            Console.WriteLine("\nFound a Hermes/Hermes/Griffin.  Checking whether it qualifies");

                            // get Hermes IP address from the IPEndPoint passed to ReceiveFrom.
                            IPEndPoint ripep = (IPEndPoint)remoteEP;
                            IPAddress receivedIPAddr = ripep.Address;
                            receivedIP = receivedIPAddr.ToString();

                            Console.WriteLine("Hermes IP from IP Header = " + receivedIP);
                            Console.WriteLine("Hermes MAC address from payload = " + HermesMAC);
                            if (!SameSubnet(receivedIPAddr, hostPortIPAddress, hostPortMask))
                            {
                                // device is NOT on the subnet that this port actually services.  Do NOT add to list!
                                Console.WriteLine("Not on subnet of host adapter! Adapter IP {0}, Adapter mask {1}",
                                    hostPortIPAddress.ToString(), hostPortMask.ToString());
                            }
                            else if (receivedIPAddr.Equals(hostPortIPAddress))
                            {
                                Console.WriteLine("Rejected: contains same IP address as the host adapter; not from a Hermes/Hermes/Griffin");
                            }
                            else if (HermesMAC.Equals("00-00-00-00-00-00"))
                            {
                                Console.WriteLine("Rejected: contains bogus MAC address of all-zeroes");
                            }
                            else
                            {
                                HermesDevice mhd = new HermesDevice();
                                mhd.IPAddress = receivedIP;
                                mhd.MACAddress = HermesMAC;
                                mhd.deviceType = (DeviceType)boardType;
                                mhd.codeVersion = codeVersion;
                                mhd.InUse = false;
                                mhd.hostPortIPAddress = hostPortIPAddress;

                                if (targetIP != null)
                                {
                                    if (mhd.IPAddress.CompareTo(targetIP.ToString()) == 0)
                                    {
                                        have_Hermes = true;
                                        mhdList.Add(mhd);
                                        return true;
                                    }
                                }
                                else
                                {
                                    have_Hermes = true;
                                    mhdList.Add(mhd);
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("No data  from Port = ");
                        if ((++time_out) > 5)
                        {
                            Console.WriteLine("Time out!");
                            return false;
                        }
                    }
                } while (data_available);
            }

            return have_Hermes;
        }

        /// <summary>
        /// Determines whether the board and hostAdapter IPAddresses are on the same subnet,
        /// using subnetMask to make the determination.  All addresses are IPV4 addresses
        /// </summary>
        /// <param name="board">IP address of the remote device</param>
        /// <param name="hostAdapter">IP address of the ethernet adapter</param>
        /// <param name="subnetMask">subnet mask to use to determine if the above 2 IPAddresses are on the same subnet</param>
        /// <returns>true if same subnet, false otherwise</returns>
        public static bool SameSubnet(IPAddress board, IPAddress hostAdapter, IPAddress subnetMask)
        {
            byte[] boardBytes = board.GetAddressBytes();
            byte[] hostAdapterBytes = hostAdapter.GetAddressBytes();
            byte[] subnetMaskBytes = subnetMask.GetAddressBytes();

            if (boardBytes.Length != hostAdapterBytes.Length)
            {
                return false;
            }
            if (subnetMaskBytes.Length != hostAdapterBytes.Length)
            {
                return false;
            }

            for (int i = 0; i < boardBytes.Length; ++i)
            {
                byte boardByte = (byte)(boardBytes[i] & subnetMaskBytes[i]);
                byte hostAdapterByte = (byte)(hostAdapterBytes[i] & subnetMaskBytes[i]);
                if (boardByte != hostAdapterByte)
                {
                    return false;
                }
            }
            return true;
        }

        // Send two frames of 512 bytes to Hermes 
        public static void Ethernet_send(int state, bool run, Socket socket, string Hermes_IP_address, int SampleRate, int txLevel,
                                          byte OC_data, byte[] frequency, byte Drive_Level, bool Attenuator)
        {

            #region how Ethernet_send works
            /*          
             
             Send frames to Ozy -- frames consist of 512 bytes as follows:
             <0x7f><0x7f><0x7f><C0><C1><C2><C3><C4><Left><Left><Right><Right><I><I><Q><Q><Left>..... 

             C0 bit 0 is "PTT"
             
             if CO = 0x0000_000x then
             C1 bits:
             7      Mic source: 0 = Janus, 1 = Penelope
             6,5    boards present:  00 neither, 01 Penelope, 10 Mercury, 11 both
             4      122.88MHz source: 0 Penelope, 1 Mercury
             3,2    10MHz ref source: 00 atlas, 01 Penelope, 10 Mercury
             1,0    sampling rate:    00 48kHz, 01 96kHz, 10 192 kHz
             * 
             C2 bits:
             7-1    Penelope open collector outputs 6-0
             0      xmt mode: 1 class E, 0 all other modes

             C3 bits:
             7    Alex Rx out: 0 off, 1 on
             6,5  Alex Rx antenna: 00 none, 01 Rx1, 10 Rx2, 11 XV
             4    Mercury ADC random: 0 off, 1 on
             3    Mercury ADC dither:  0 off, 1 on
             2    Mercury preamp: 0 off, 1 on
             1,0  Alex attenuator: 00 0dB, 01 10dB, 10 20dB, 11 30dB

             C4 bits
             7-3  unused
             1,0  Alex Tx relay: 00 Tx1, 01 Tx2, 10 Tx3
             2    1 = full duplex, 0 = simplex 
             if C4[2] = 0 and C0 = 0x0000_001x then C1..C4 hold frequency in Hz for Penny and Mercury, C1 = MSB
             if C4[2] = 1 and C0 = 0x0000_001x then C1..C4 hold frequency in Hz for Penny, C1 = MSB
             if C4[2] = 1 and C0 = 0x0000_010x then C1..C4 hold frequency in Hz for Mercury, C1 = MSB
             

             For a full description of the USB protocol see the document in \trunk\Documents
             */

            #endregion

            // state determines what C&C bits to send, 0 = sampling rate & attenuator state 
            // 1 = frequency,  2 =  drive level   

            if ((Hermes_IP_address == null) || (Hermes_IP_address.Length == 0))
            {
                // avoid errors if a hermes device is not connected.  this could happen if not connected and you read a calibration file
                return;
            }

            socket.SendBufferSize = 1032;

            // create an endpoint for sending to Hermes
            IPEndPoint HermesEP = new IPEndPoint(IPAddress.Parse(Hermes_IP_address), 1024);

            short I_data = 0;
            short Q_data = 0;
            int frame_number = 0;
            int pntr; int x = 0;
            byte C0 = 0x00, C1 = 0x00, C2 = 0x00, C3 = 0x00, C4 = 0x00;
            const byte sync = 0x7F;
            int sequence_number = 0;

            byte[] to_Hermes = new byte[1024 + 8];       // array to send to Hermes via Ethernet, includes the 8 bytes before the data

            // Hermes uses Drive control - 0x00 to 0xFF

            // send 2 frames of 512 bytes for a total of 1024 bytes to Hermes via Ethernet
            for (frame_number = 0; frame_number < 2; frame_number++)
            {
                switch (state)
                {
                    case 0:
                        {
                            C0 = 0x00; C1 = 0x00; C2 = 0x00; C4 = 0x00;

                            // set sampling rate bits in C1
                            switch (SampleRate)
                            {
                                case 480000: break;
                                case 96000:
                                    C1 = (byte)(C1 | 0x01);
                                    break;
                                case 192000:
                                    C1 = (byte)(C1 | 0x02);
                                    break;
                            }

                            // select 20dB attenuator
                            C3 = Attenuator ? (byte)0x00 : (byte)0x04;

                            // Set Open Collector outputs as per selection
                            C2 = (byte)((int)OC_data << 1);  // Open Collector bits are  7... 1
                            break;
                        }
                    case 1:
                        {
                            // set CO  to  0x02 and send frequency for Hermes
                            C0 = 0x02; C1 = frequency[3]; C2 = frequency[2]; C3 = frequency[1]; C4 = frequency[0]; // send frequency data22
                            break;
                        }

                    case 2:
                        {
                            // set Drive Level and enable VNA 
                            C0 = 0x12;
                            C1 = Drive_Level;
                            C2 = run ? (byte)0x80 : (byte)0x00;              // 0x80 = VNA enabled, 0x00 = VNA disabled 
                            break;
                        }
                }


                pntr = (frame_number * 512) + 8;     // start past the 8 bytes header before the data
                to_Hermes[pntr] = sync; to_Hermes[++pntr] = sync; to_Hermes[++pntr] = sync;
                to_Hermes[++pntr] = C0; to_Hermes[++pntr] = C1; to_Hermes[++pntr] = C2;
                to_Hermes[++pntr] = C3; to_Hermes[++pntr] = C4;

                for (x = 8; x < 512; x += 8)        // fill out one 512-byte frame
                {
                    // send I & Q data to Hermes Q = 0 and I the Tx level  (0 to 2^15 - 1)
                    to_Hermes[++pntr] = (byte)(I_data >> 8);      // I_data[0];
                    to_Hermes[++pntr] = (byte)(I_data & 0xff);    // I_data[1];
                    to_Hermes[++pntr] = (byte)(Q_data >> 8);      // Q_data[0];
                    to_Hermes[++pntr] = (byte)(Q_data & 0xff);    // Q_data[1];  
                } // end for

            }

            if (true)  // send the frames to Hermes using UDP/IP
            {
                // put the header info into the start of the to_Hermes buffer
                to_Hermes[0] = 0xEF;   // first 2 bytes are ether type
                to_Hermes[1] = 0xFE;
                to_Hermes[2] = 0x01;   // frame type = 1
                to_Hermes[3] = 0x02;   // end point = EP2

                // insert sequence number.  It's in 'big-endian' order (MSByte first, LSByte last)
                to_Hermes[4] = (byte)(sequence_number >> 24);
                to_Hermes[5] = (byte)((sequence_number >> 16) & 0xff);
                to_Hermes[6] = (byte)((sequence_number >> 8) & 0xff);
                to_Hermes[7] = (byte)(sequence_number & 0xff);

                try
                {
                    //Send the UDP/IP packet out the network device
                    int rc = socket.SendTo(to_Hermes, HermesEP);
                }
                catch (Exception d)
                {
                    Debug.WriteLine("-- " + d.Message);   // *** need to warn user if this fails
                }

                // increment the sequence number for next time.  Make sure it's an unchecked operation, so that
                // no ArithmeticException is thrown when it wraps back to 0 (overflow.)
                unchecked
                {
                    sequence_number++;
                }
            }
        }
    }
}

